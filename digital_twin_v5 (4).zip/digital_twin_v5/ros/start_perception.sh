#!/usr/bin/env bash
# v4: perception into the twin in ONE window: table frame + WP3 scene bridge (+ mock blocks unless --live).
#   bash start_perception.sh            simulation: 3 fake (mock) blocks, clearly labelled as mock
#   bash start_perception.sh --wood     mock with the 45 mm wooden props
#   bash start_perception.sh --live     real WP3 node publishing /wp3_live/markers (no mock)
# Table frame: edit TABLE_XYZ / TABLE_YAW after the Step B fit (fit_table_tf.py prints the values).
TABLE_XYZ="${TABLE_XYZ:-0.30 0.00 -0.008}"
TABLE_YAW="${TABLE_YAW:-0}"
cd "$(dirname "$0")"
pids=()
cleanup() { kill "${pids[@]}" 2>/dev/null; wait 2>/dev/null; echo "perception stopped"; }
trap cleanup EXIT INT TERM
python3 wp3_table_tf.py --xyz $TABLE_XYZ --yaw $TABLE_YAW & pids+=($!)
sleep 1
python3 wp3_scene_bridge.py --remove-demo-block & pids+=($!)
if [[ "$1" != "--live" ]]; then
  sleep 2
  python3 mock_wp3_publisher.py "$@" & pids+=($!)
fi
echo "perception running (Ctrl+C stops all of it)"
wait
