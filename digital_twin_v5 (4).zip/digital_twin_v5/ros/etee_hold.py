#!/usr/bin/env python3
"""Hold-to-move jogging node. Works with ANY input that publishes sensor_msgs/Joy on /etee/joy (Etee trackpads via
etee_reader_windows.py, or the keyboard via keyboard_reader_windows.py, both through etee_bridge.py).

While you hold a direction the arm keeps moving at a constant slow speed; when you let go it stops at once.
Each hold is ONE straight-line MoveIt path (collision checked: table, block, power box, fence walls), sent
straight to the arm's trajectory controller so a release can cancel it immediately.

  Joy axes: [left x (left/right), left y (forward/back), right x (unused), right y (up/down)]
  Joy buttons: [left touched, right touched, close gripper, open gripper]

  python3 etee_hold.py                    constant 0.01 m/s (default)
  python3 etee_hold.py --speed 0.005      even slower
  python3 etee_hold.py --analog           speed follows how hard the pad is pushed (3 levels)
  python3 etee_hold.py --dry-run          read the input and print what would happen; the arm never moves

v4: closing the gripper on a scene object (perceived block or the demo block) attaches it automatically, so it
lifts with the arm; opening releases it and it drops onto the table or the block below. --no-auto-grasp turns this off.

Protection: nothing moves until both inputs have been at rest for 0.5 s ("armed"); stale input stops the arm;
the path is clipped to the table / fence / reach limits and the closed-loop check stops the arm within 1.5 mm of
a limit; paths with an IK flip are refused; a watchdog holds the arm if it keeps moving after a stop.
--deadzone / --curve tune the trackpad feel; --flip-x / --flip-y / --flip-z reverse a direction.
Real arm: supervisor present, E-stop in reach, simulate first.
"""
import argparse
import copy
import math
import time

import numpy as np
import rclpy
from control_msgs.action import FollowJointTrajectory, GripperCommand
from geometry_msgs.msg import Pose, TwistStamped
from rclpy.action import ActionClient, get_action_names_and_types
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from moveit_msgs.msg import MoveItErrorCodes
from moveit_msgs.msg import AttachedCollisionObject, CollisionObject, PlanningScene, PlanningSceneComponents, RobotState
from moveit_msgs.srv import GetCartesianPath, GetPlanningScene, GetStateValidity
from shape_msgs.msg import SolidPrimitive
from std_msgs.msg import String
import json
import twin_grasp as tg
from xarm_kin import fk_tcp
from rclpy.time import Time
from builtin_interfaces.msg import Duration
from sensor_msgs.msg import JointState, Joy

import build_scene as bs
import pick_place_sim as pp
import etee_input
from etee_input import describe_direction, pad_command, speed_fraction
from xarm_kin import fk_tcp

TOPIC = '/etee/joy'
STALE_S = 0.5
PLAN_LENGTH = 0.50           # m, longest single hold; it normally ends at a limit first
RAMP_M = 0.015               # m, eases in and out over this distance at the start and end of a path
MIN_SPEED_FRACTION = 0.35
JOINT_STEP_MAX = 0.30        # rad: the arm's measured start must match MoveIt's start state within this
MIN_CLEARANCE = 0.0015       # m above the MODELLED table top (fingertip height); v4: was 6 mm
_fx0, _fx1, _fy0, _fy1 = bs.fence_limits()     # fingertips stay inside the table-edge walls (see build_scene.py)
REACH_X = 0.65               # m: forward limit. Tool-down reach is ~0.70 m at table height, ~0.59 m at z=0.30 (v4: was 0.55)
LIMITS = {'x': (max(0.12, _fx0), min(REACH_X, _fx1)), 'y': (_fy0, _fy1), 'z_max': 0.40}
DIR_CHANGE_DEG = 25.0
LIMIT_STOP_M = 0.001         # stop when the fingertips are within this distance of a limit (v4: was 4 mm)
MIN_PATH_M = 0.002           # shortest path worth planning (v4: was 1 cm, which stopped holds 1 cm early)
MAX_STEP = 0.005            # m between planned points (smaller = safer joint steps, slower planning)
TCP_CLOSED_M = bs.FINGERTIP_CLOSED  # v4: flange to fingertips, gripper CLOSED (measured 24 Nov)
TCP_OPEN_M = bs.FINGERTIP_OPEN      # gripper fully OPEN (measured 24 Nov)
FINGER_LINKS = ['left_outer_knuckle', 'left_inner_knuckle', 'left_finger',
                'right_outer_knuckle', 'right_inner_knuckle', 'right_finger', 'link_tcp']
DRIVE_CLOSED = 0.85                # drive_joint value when fully closed
JS_GAP_STOP_S = 0.10          # v4: stop if the driver's joint states pause this long while moving (WSL stalls ~330 ms)
FAST_JS_TOPIC = '/xarm/joint_states'  # v4: driver's own joint states (~150 Hz on the real arm)
CMD_VEL_TOPIC = '/twin/cmd_vel'       # v4: velocity commands from other nodes (WP5); see INTERFACE.md
CMD_VEL_TIMEOUT = 0.3        # s: a velocity command older than this stops the arm
LEVEL_CHANGE_S = 0.2         # a speed level must hold this long before the path is restarted


def limit_reason(p, d):
    """Which limit stops a move from point p along d (for the message)."""
    zmin = bs.Z_FLOOR + bs.Z_MARGIN + MIN_CLEARANCE
    names = (('FORWARD', 'x', LIMITS['x'][1]), ('BACK', 'x', LIMITS['x'][0]),
             ('LEFT', 'y', LIMITS['y'][1]), ('RIGHT', 'y', LIMITS['y'][0]),
             ('UP', 'z', LIMITS['z_max']), ('DOWN (table)', 'z', zmin))
    for name, ax, lim in names:
        i = 'xyz'.index(ax)
        if (d[i] > 0.3 and p[i] >= lim - 0.005 and lim == (LIMITS['x'][1], LIMITS['y'][1], LIMITS['z_max'])[i]) or \
           (d[i] < -0.3 and p[i] <= lim + 0.005 and lim == (LIMITS['x'][0], LIMITS['y'][0], zmin)[i]):
            return f'{name} limit ({ax}={lim:.2f} m)'
    return 'workspace limit'


def max_length(p, d):
    """Longest distance along unit vector d that keeps the fingertips inside the limits."""
    zmin = bs.Z_FLOOR + bs.Z_MARGIN + MIN_CLEARANCE
    lo = (LIMITS['x'][0], LIMITS['y'][0], zmin)
    hi = (LIMITS['x'][1], LIMITS['y'][1], LIMITS['z_max'])
    L = PLAN_LENGTH
    for i in range(3):
        if d[i] > 1e-6:
            L = min(L, (hi[i] - p[i]) / d[i])
        elif d[i] < -1e-6:
            L = min(L, (lo[i] - p[i]) / d[i])
    return max(L, 0.0)


def joint_speed_cap(speed):
    """rad/s limit on any joint, tied to the tool speed (legit joint motion is about 4-10 rad per metre of tool travel)."""
    return max(0.15, speed * 14.0)


def max_joint_step(traj):
    q = [np.array(p.positions) for p in traj.joint_trajectory.points]
    return max((float(np.max(np.abs(q[i + 1] - q[i]))) for i in range(len(q) - 1)), default=0.0)


FLIP_STEP = 0.5          # rad: any neighbouring points this far apart in one joint are a flip, whatever the spacing
FLIP_MIN_STEP = 0.10     # rad: below this a step is never a flip
FLIP_RATIO = 20.0        # rad of joint motion per metre of fingertip travel; legit paths are about 4-10, flips 50+


def find_flip(traj, tcp_offset):
    """None if the path is smooth, otherwise a message. MoveIt returns points 2-3 cm apart, so a big joint step is
    only a flip if the fingertips barely moved for it."""
    pts = traj.joint_trajectory.points
    q = [np.array(p.positions) for p in pts]
    pos = [fk_tcp(qi, tcp_offset)[0] for qi in q]
    for i in range(len(q) - 1):
        step = float(np.max(np.abs(q[i + 1] - q[i])))
        ds = float(np.linalg.norm(pos[i + 1] - pos[i]))
        if step > FLIP_STEP:
            return f'IK flip: one joint jumps {step:.2f} rad between neighbouring path points'
        if step > FLIP_MIN_STEP and step / max(ds, 0.002) > FLIP_RATIO:
            return f'IK flip: joints moved {step:.2f} rad while the fingertips moved only {ds * 100:.1f} cm'
    return None


def time_parameterise(traj, speed, tcp_offset):
    """Give a MoveIt joint path timing: tool speed `speed` m/s with a gentle ease-in and ease-out."""
    pts = traj.joint_trajectory.points
    if len(pts) < 2:
        return
    q = [np.array(p.positions) for p in pts]
    pos = [fk_tcp(qi, tcp_offset)[0] for qi in q]
    ds = [float(np.linalg.norm(pos[i + 1] - pos[i])) for i in range(len(q) - 1)]
    total = sum(ds)
    t, s = 0.0, 0.0
    pts[0].time_from_start.sec, pts[0].time_from_start.nanosec = 0, 0
    pts[0].velocities, pts[0].accelerations = [], []
    for i in range(1, len(pts)):
        s_mid = s + ds[i - 1] / 2.0
        ramp = min(1.0, s_mid / RAMP_M, (total - s_mid) / RAMP_M)
        v = speed * max(MIN_SPEED_FRACTION, math.sqrt(max(ramp, 0.0)))
        dt = ds[i - 1] / v if v > 0 else 0.0
        dt = max(dt, float(np.max(np.abs(q[i] - q[i - 1]))) / joint_speed_cap(speed), 0.005)
        t += dt
        s += ds[i - 1]
        pts[i].time_from_start.sec = int(t)
        pts[i].time_from_start.nanosec = int((t - int(t)) * 1e9)
        pts[i].velocities, pts[i].accelerations = [], []
    # explicit velocities: zero at the first and last point, so the arm starts and stops smoothly
    n = len(pts)
    tt = [p.time_from_start.sec + p.time_from_start.nanosec * 1e-9 for p in pts]
    for i in range(n):
        if i == 0 or i == n - 1 or tt[i + 1] - tt[i - 1] <= 1e-6:
            v = np.zeros_like(q[i])
        else:
            v = (q[i + 1] - q[i - 1]) / (tt[i + 1] - tt[i - 1])
        pts[i].velocities = [float(x) for x in v]
        pts[i].accelerations = []


class EteeHold(pp.PickPlace):
    def __init__(self, args):
        super().__init__()
        self.speed = args.speed
        self.dry = args.dry_run
        self.analog = args.analog
        self.blocked = None                 # direction that hit a limit; ignored until the pad is released or moved elsewhere
        self.settle = args.settle
        self.flips = (-1.0 if args.flip_x else 1.0, -1.0 if args.flip_y else 1.0, -1.0 if args.flip_z else 1.0)
        self.armed = False
        self.rest_since = None
        self.grip_close = pp.GRIP_CLOSE
        self.joy = None
        self.joy_time = 0.0
        self.prev_buttons = []
        self.goal_handle = None
        self.result_future = None
        self.active_dir = None
        self.active_frac = None
        self.ref_orientation = None
        self.pending_level = (None, 0.0)
        self.cache, self.cache_pose = {}, None
        self.retry_after = 0.0
        self.info = {}
        self.max_step = args.max_step
        self.auto_grasp = not args.no_auto_grasp
        self.held = None                     # id of the object attached to the gripper
        self.validity = self.create_client(GetStateValidity, '/check_state_validity')
        self.events = self.create_publisher(String, '/twin/object_events', 10)
        self.explained = None
        self.length_cap = None               # v4: set only while lifting before a close
        self.cmd_vel, self.cmd_vel_time = None, 0.0
        self.grip_request = None
        self.last_reason = ''
        self.create_subscription(TwistStamped, CMD_VEL_TOPIC, self.on_cmd_vel, 10)
        self.create_subscription(String, '/twin/gripper_cmd', self.on_grip_cmd, 10)
        self.state_pub = self.create_publisher(String, '/twin/state', 10)
        self.last_state = 0.0
        self.create_subscription(Joy, TOPIC, self.on_joy, 10)
        self.js = None
        self.hist = []                       # (time, arm joint angles) for the watchdog
        self.pending = None                  # goal being sent to the controller
        self.to_cancel = []                  # goals to cancel as soon as the controller accepts them
        self.cancel_pending = False
        self.fjt = None
        self.grip_fjt = None                # the gripper's own trajectory controller (found on first use)
        self.grip_fjt_tried = False
        self.last_stop = 0.0
        self.motion_since = None
        self.create_subscription(JointState, '/joint_states', self.on_js, 10)
        # v4: the xArm driver publishes ~150 Hz on its own topic; /joint_states is a 10 Hz relay
        self.fast_q, self.fast_t = None, 0.0
        self.js_gap_stops = 0
        self.create_subscription(JointState, FAST_JS_TOPIC, self.on_fast_js, 50)

    def on_fast_js(self, msg):
        pos = dict(zip(msg.name, msg.position))
        names = ['joint%d' % i for i in range(1, 7)]
        if not all(n in pos for n in names):
            return
        t = time.monotonic()
        self.fast_q, self.fast_t = np.array([pos[n] for n in names]), t
        self.hist.append((t, self.fast_q))
        while self.hist and t - self.hist[0][0] > 1.0:
            self.hist.pop(0)

    def allow_fingers_near_table(self):
        """The robot model's finger shapes reach the table ~14 mm before the real open fingertips do, so MoveIt stopped
        the open gripper 16 mm up (too high to grip a 15 mm block). The fingers may touch the table in MoveIt's check;
        the fingertip limit (measured lengths, 2.5 to 3.5 mm above the real table) protects it instead."""
        req = GetPlanningScene.Request()
        req.components.components = PlanningSceneComponents.ALLOWED_COLLISION_MATRIX
        acm = self.call(self.get_scene, req).scene.allowed_collision_matrix
        scene = PlanningScene(is_diff=True)
        scene.allowed_collision_matrix = bs.add_acm_pairs(acm, 'table', FINGER_LINKS)
        if self.apply(scene):
            print('  fingers may come close to the table; the fingertip limit protects it')

    def tcp_off(self):
        """Flange-to-fingertip length for the gripper's current opening (fingertips rise as the gripper opens)."""
        if self.js is not None:
            pos = dict(zip(self.js.name, self.js.position))
            if pp.GRIPPER_JOINT in pos:
                c = max(0.0, min(1.0, pos[pp.GRIPPER_JOINT] / DRIVE_CLOSED))
                return TCP_OPEN_M + (TCP_CLOSED_M - TCP_OPEN_M) * c
        return TCP_CLOSED_M

    def fast_fresh(self):
        return self.fast_q is not None and time.monotonic() - self.fast_t < 0.1

    def on_js(self, msg):
        self.js = msg
        pos = dict(zip(msg.name, msg.position))
        names = ['joint%d' % i for i in range(1, 7)]
        if all(n in pos for n in names) and not self.fast_fresh():
            t = time.monotonic()
            self.hist.append((t, np.array([pos[n] for n in names])))
            while self.hist and t - self.hist[0][0] > 1.0:
                self.hist.pop(0)

    def arm_moved(self, window=0.3):
        """Largest joint change (rad) over the last `window` seconds, or None if there is not enough data yet."""
        if len(self.hist) < 2:
            return None
        t_now, q_now = self.hist[-1]
        old = [h for h in self.hist if t_now - h[0] >= window]
        if not old:
            return None
        return float(np.max(np.abs(q_now - old[-1][1])))

    def on_cmd_vel(self, msg):
        self.cmd_vel = msg
        self.cmd_vel_time = time.monotonic()

    def on_grip_cmd(self, msg):
        word = msg.data.strip().lower()
        if word in ('open', 'close'):
            self.grip_request = word

    def cmd_vel_command(self):
        """TwistStamped (world frame, m/s) -> (unit direction [forward, left, up], speed fraction) or (None, 0)."""
        v = self.cmd_vel.twist.linear
        vec = np.array([v.x, v.y, v.z], dtype=float)
        n = float(np.linalg.norm(vec))
        if n < 1e-4:
            return None, 0.0
        frac = min(1.0, n / self.speed)
        return vec / n, max(0.1, round(frac * 10.0) / 10.0)      # 10 % steps: small changes do not re-plan

    def publish_state(self, now, source, d, frac):
        if now - self.last_state < 0.2:
            return
        self.last_state = now
        tcp = self.tcp_now()
        self.state_pub.publish(String(data=json.dumps({
            'fingertips_m': None if tcp is None else [round(float(v), 4) for v in tcp],
            'moving': bool(self.moving()), 'source': source,
            'direction': None if d is None else [round(float(v), 3) for v in d],
            'speed_m_s': round(self.speed * frac, 4) if d is not None else 0.0,
            'held_object': self.held, 'armed': self.armed, 'last_refusal': self.last_reason,
            'speed_cap_m_s': round(self.speed, 4)})))

    def lift_before_close(self):
        """Closing swings the fingertips down by TCP_CLOSED_M - (current length). Near the table that would scrape it,
        so lift first by just enough that the CLOSED fingertips end at the table limit."""
        tip = self.tip_now()
        if tip is None:
            return
        zmin = bs.Z_FLOOR + bs.Z_MARGIN + MIN_CLEARANCE
        closed_tip = tip.position.z - TCP_CLOSED_M
        lift = zmin - closed_tip
        if lift < 0.0005:
            return
        print(f'  lifting {lift * 1000:.1f} mm before closing (the fingertips swing down as the gripper closes)')
        self.cache = {}
        self.length_cap = lift + 0.0005
        try:
            self.start_path(np.array([0.0, 0.0, 1.0]), 0.5)
        finally:
            self.length_cap = None
        end = time.monotonic() + 3.0 + lift / max(self.speed * 0.5, 1e-3)
        while time.monotonic() < end and self.moving():
            rclpy.spin_once(self, timeout_sec=0.02)
            self.service_goal()
        self.stop()
        self.settle_wait()

    def do_grip(self, close):
        self.stop()
        self.settle_wait()
        self.cache = {}                                   # the fingertip length changes with the opening
        if close and not self.dry:
            self.lift_before_close()
        ok = self.gripper(self.grip_close if close else pp.GRIP_OPEN)
        if not ok:
            self.settle_wait()
            ok = self.gripper(self.grip_close if close else pp.GRIP_OPEN)
        print('  gripper', 'closed' if close else 'opened', '' if ok else '(command failed)')
        if self.auto_grasp and not self.dry:
            if close and self.held is None:
                self.try_grasp()
            elif not close and self.held is not None:
                self.release()

    def on_joy(self, msg):
        self.joy = msg
        self.joy_time = time.monotonic()

    # ---- helpers
    def tip_now(self):
        try:
            t = self.tf_buffer.lookup_transform(bs.FRAME, pp.TIP_LINK, Time())
        except Exception:                                  # noqa: BLE001
            return None
        p = Pose()
        p.position.x, p.position.y, p.position.z = (t.transform.translation.x, t.transform.translation.y,
                                                    t.transform.translation.z)
        p.orientation = t.transform.rotation
        return p

    def tcp_now(self):
        if self.fast_fresh():                          # v4: 150 Hz joints + our own kinematics, not 10 Hz TF
            p, _ = fk_tcp(self.fast_q, self.tcp_off())
            return np.asarray(p, dtype=float)
        tip = self.tip_now()
        return None if tip is None else np.array([tip.position.x, tip.position.y, tip.position.z - self.tcp_off()])

    def find_controller(self):
        """Find the arm's trajectory controller action. Execution goes straight to it: it accepts a new goal at
        once and its cancel stops the arm (MoveIt's ExecuteTrajectory queues goals and can ignore a cancel)."""
        name = None
        for _ in range(60):
            rclpy.spin_once(self, timeout_sec=0.1)
            try:
                actions = get_action_names_and_types(self)
            except Exception:
                actions = []
            found = [n for n, types in actions
                     if n.endswith('follow_joint_trajectory') and 'gripper' not in n
                     and any('FollowJointTrajectory' in t for t in types)]
            if found:
                found.sort(key=lambda n: ('xarm6' not in n, len(n)))
                name = found[0]
                break
        if name is None:
            name = '/xarm6_traj_controller/follow_joint_trajectory'
            print(f'  could not list the controller actions; trying {name}')
        self.fjt = ActionClient(self, FollowJointTrajectory, name)
        ok = self.fjt.wait_for_server(timeout_sec=5.0)
        print(f'  arm controller: {name} ({"ready" if ok else "NOT answering"})')
        return ok

    def service_goal(self):
        """Non-blocking bookkeeping of the goal being sent and of goals that must be cancelled."""
        if self.pending is not None and self.pending.done():
            gh = self.pending.result()
            self.pending = None
            if gh is None or not gh.accepted:
                print('  the arm controller rejected the move')
                self.goal_handle, self.result_future, self.active_dir = None, None, None
            elif self.cancel_pending:
                gh.cancel_goal_async()
                self.cancel_pending = False
                self.goal_handle, self.result_future, self.active_dir = None, None, None
            else:
                self.goal_handle = gh
                self.result_future = gh.get_result_async()
        for fut in list(self.to_cancel):
            if fut.done():
                self.to_cancel.remove(fut)
                gh = fut.result()
                if gh is not None and gh.accepted:
                    gh.cancel_goal_async()

    def moving(self):
        if self.pending is not None:
            return True
        return self.goal_handle is not None and self.result_future is not None and not self.result_future.done()

    def send_trajectory(self, jt):
        goal = FollowJointTrajectory.Goal()
        goal.trajectory = jt
        self.cancel_pending = False
        self.pending = self.fjt.send_goal_async(goal)

    def stop(self):
        """Stop at once and never wait for anything."""
        if self.pending is not None:
            self.to_cancel.append(self.pending)      # cancel it the moment the controller accepts it
            self.pending = None
        if self.goal_handle is not None and self.result_future is not None and not self.result_future.done():
            self.goal_handle.cancel_goal_async()
        self.goal_handle, self.result_future = None, None
        self.active_dir, self.active_frac = None, None
        self.last_stop = time.monotonic()

    def hold_here(self):
        """Make the controller hold the arm where it is now (used by the watchdog)."""
        if self.js is None or self.fjt is None:
            return
        pos = dict(zip(self.js.name, self.js.position))
        names = ['joint%d' % i for i in range(1, 7)]
        if not all(n in pos for n in names):
            return
        jt = JointTrajectory()
        jt.joint_names = names
        p = JointTrajectoryPoint()
        p.positions = [float(pos[n]) for n in names]
        p.velocities = [0.0] * 6
        p.time_from_start.sec, p.time_from_start.nanosec = 0, 300_000_000
        jt.points = [p]
        self.send_trajectory(jt)
        self.goal_handle, self.result_future = None, None

    def watchdog(self, now):
        """Safety net: if the program thinks the arm is stopped but the joints keep moving, hold position."""
        if self.dry or self.moving() or now - self.last_stop < 0.5:
            self.motion_since = None
            return
        moved = self.arm_moved(0.3)
        if moved is not None and moved > 0.006:
            if self.motion_since is None:
                self.motion_since = now
            elif now - self.motion_since > 0.2:
                print('  SAFETY: the arm is still moving after stop; holding position')
                self.hold_here()
                self.last_stop = now
                self.motion_since = None
        else:
            self.motion_since = None

    def settle_wait(self):
        end = time.monotonic() + self.settle
        while time.monotonic() < end and rclpy.ok():
            rclpy.spin_once(self, timeout_sec=0.02)

    # ---- planning (the slow part), with a cache so a push can start at once
    AXES = [np.array(v, float) for v in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1))]

    @staticmethod
    def dir_key(d):
        return tuple(int(round(x * 100)) for x in d)

    def plan(self, d, quiet=False):
        """Plan one straight path from where the tool is now along unit vector d.
        Returns (solution, '') or (None, reason). Details of the last plan are kept in self.info."""
        self.info = {}
        tip = self.tip_now()
        if tip is None:
            return None, 'no TF yet (arm position unknown)'
        if self.ref_orientation is None:
            self.ref_orientation = tip.orientation
        tcp = np.array([tip.position.x, tip.position.y, tip.position.z - self.tcp_off()])
        L = max_length(tcp, d)
        if self.length_cap is not None:
            L = min(L, self.length_cap)
        if L < MIN_PATH_M:
            return None, f'at the {limit_reason(tcp, d)}'
        target = Pose()
        target.position.x, target.position.y, target.position.z = (tip.position.x + d[0] * L,
                                                                   tip.position.y + d[1] * L,
                                                                   tip.position.z + d[2] * L)
        target.orientation = self.ref_orientation
        req = GetCartesianPath.Request()
        req.header.frame_id = bs.FRAME
        req.start_state.is_diff = True
        if self.js is not None:                      # start from where the arm really is, not a stale state
            req.start_state.joint_state = self.js
        req.group_name = pp.ARM_GROUP
        req.link_name = pp.TIP_LINK
        req.waypoints = [target]
        req.max_step = self.max_step
        req.jump_threshold = 0.0
        req.avoid_collisions = True
        res = self.call(self.cart_srv, req)
        n = len(res.solution.joint_trajectory.points)
        self.info = {'fraction': res.fraction, 'points': n, 'length_m': L}
        if res.fraction < 0.98 and n:
            self.info['cut_state'] = res.solution.joint_trajectory
        if res.fraction < 0.03:
            return None, f'MoveIt found only {res.fraction * 100:.0f}% of a {L * 100:.0f} cm path (collision or no IK solution)'
        self.info['joint_step'] = max_joint_step(res.solution)
        flip = find_flip(res.solution, self.tcp_off())
        if flip:
            return None, flip
        return res.solution, ''

    def pose_key(self):
        tip = self.tip_now()
        return None if tip is None else (round(tip.position.x, 3), round(tip.position.y, 3), round(tip.position.z, 3))

    def precompute_one(self):
        """While idle, plan one of the six axis directions ahead of time (one per call)."""
        key = self.pose_key()
        if key is None:
            return
        if key != self.cache_pose:                    # the arm moved: old plans are void
            self.cache, self.cache_pose = {}, key
        for d in self.AXES:
            k = self.dir_key(d)
            if k not in self.cache:
                self.cache[k] = self.plan(d)           # (solution, reason); a failure is kept with its reason
                return

    def start_path(self, d, frac):
        t0 = time.monotonic()
        how = 'planned now'
        k = self.dir_key(d)
        if self.cache_pose == self.pose_key() and k in self.cache:
            sol, reason = self.cache[k]
            how = 'from the stored plan'
            if sol is not None:
                sol = copy.deepcopy(sol)
        else:
            sol, reason = self.plan(d)
        if sol is None:
            p = self.pose_key()
            self.last_reason = reason
            print(f'  not moving {describe_direction(d)}: {reason}; fingertips x={p[0]:.3f} y={p[1]:.3f}')
            return False
        if how == 'planned now' and self.info.get('fraction', 1.0) < 0.98:
            self.explain_cut(d)
        time_parameterise(sol, self.speed * frac, self.tcp_off())
        jt = sol.joint_trajectory
        if self.js is not None and jt.points:        # first point = measured joint angles, so no snap at the start
            pos = dict(zip(self.js.name, self.js.position))
            if all(n in pos for n in jt.joint_names):
                meas = np.array([float(pos[n]) for n in jt.joint_names])
                gap = float(np.max(np.abs(meas - np.array(jt.points[0].positions))))
                if gap > JOINT_STEP_MAX:
                    print(f'  refused: MoveIt start differs from the measured arm by {gap:.2f} rad. Not moving.')
                    return False
                jt.points[0].positions = [float(x) for x in meas]
        self.goal_handle, self.result_future = None, None
        self.send_trajectory(sol.joint_trajectory)
        self.active_dir, self.active_frac = d, frac
        print(f'  started in {(time.monotonic() - t0) * 1000:.0f} ms ({how})')
        return True

    def find_gripper_controller(self):
        """The xArm gripper is a GripperCommand action (e.g. /xarm_gripper/gripper_action), not a trajectory action."""
        self.grip_fjt_tried = True
        for _ in range(20):
            rclpy.spin_once(self, timeout_sec=0.1)
            try:
                actions = get_action_names_and_types(self)
            except Exception:
                actions = []
            found = [n for n, types in actions
                     if any('GripperCommand' in t for t in types) and 'bio' not in n]
            if found:
                found.sort(key=lambda n: ('xarm_gripper' not in n, len(n)))
                client = ActionClient(self, GripperCommand, found[0])
                if client.wait_for_server(timeout_sec=3.0):
                    self.grip_fjt = client
                    print(f'  gripper action: {found[0]}')
                    return True
        print('  no gripper action found; using MoveIt for the gripper')
        return False

    def gripper(self, value):
        """Open/close through the gripper's own action. MoveIt refuses with error -26 (start state invalid) here.
        Falls back to MoveIt if the action is missing or rejects the goal."""
        if self.grip_fjt is None and not self.grip_fjt_tried:
            self.find_gripper_controller()
        if self.grip_fjt is None:
            return super().gripper(value)
        goal = GripperCommand.Goal()
        goal.command.position = float(value)
        goal.command.max_effort = 20.0
        fut = self.grip_fjt.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, fut, timeout_sec=3.0)
        gh = fut.result() if fut.done() else None
        if gh is None or not gh.accepted:
            print('  the gripper action did not accept the command; trying MoveIt')
            return super().gripper(value)
        res = gh.get_result_async()
        rclpy.spin_until_future_complete(self, res, timeout_sec=5.0)
        return True


    # ---- v4: say WHY MoveIt cut a path short
    def explain_cut(self, d):
        """MoveIt stopped a straight path early: name the colliding bodies just past the cut."""
        jt = self.info.get('cut_state')
        if jt is None or not jt.points:
            return
        L, frac = self.info['length_m'], self.info['fraction']
        key = (self.dir_key(d), round(frac, 2))
        if self.explained == key:
            return
        self.explained = key
        # plan the same direction a few mm past the cut WITHOUT collision checking, and test that state
        tip = self.tip_now()
        if tip is None or not self.validity.service_is_ready():
            print(f'  MoveIt can only go {frac * L * 100:.1f} cm {describe_direction(d)} (collision in the model)')
            return
        extra = frac * L + 0.004
        target = Pose()
        target.position.x = tip.position.x + d[0] * extra
        target.position.y = tip.position.y + d[1] * extra
        target.position.z = tip.position.z + d[2] * extra
        target.orientation = self.ref_orientation
        req = GetCartesianPath.Request()
        req.header.frame_id = bs.FRAME
        req.start_state.is_diff = True
        if self.js is not None:
            req.start_state.joint_state = self.js
        req.group_name, req.link_name = pp.ARM_GROUP, pp.TIP_LINK
        req.waypoints, req.max_step, req.jump_threshold, req.avoid_collisions = [target], self.max_step, 0.0, False
        res = self.call(self.cart_srv, req)
        pts = res.solution.joint_trajectory.points
        if not pts:
            return
        vr = GetStateValidity.Request()
        vr.group_name = pp.ARM_GROUP
        vr.robot_state = RobotState(is_diff=True)
        vr.robot_state.joint_state.name = list(res.solution.joint_trajectory.joint_names)
        vr.robot_state.joint_state.position = list(pts[-1].positions)
        out = self.call(self.validity, vr)
        pairs = sorted({tuple(sorted((c.contact_body_1, c.contact_body_2))) for c in out.contacts})
        what = ', '.join(f'{a} <-> {b}' for a, b in pairs[:3]) or 'no contact reported (IK or joint limit)'
        print(f'  MoveIt can only go {frac * L * 100:.1f} cm {describe_direction(d)}: {what}')

    # ---- v4: automatic grasp / release of scene objects
    def world_boxes(self):
        """[(id, dims, xyz, quat)] for every box in the planning scene world, in the world frame."""
        req = GetPlanningScene.Request()
        req.components.components = (PlanningSceneComponents.WORLD_OBJECT_NAMES |
                                      PlanningSceneComponents.WORLD_OBJECT_GEOMETRY)
        scene = self.call(self.get_scene, req).scene
        out = []
        for obj in scene.world.collision_objects:
            if not obj.primitives or obj.primitives[0].type != SolidPrimitive.BOX or not obj.primitive_poses:
                continue
            op, pp0 = obj.pose, obj.primitive_poses[0]
            pose = ((op.position.x, op.position.y, op.position.z),
                    (op.orientation.x, op.orientation.y, op.orientation.z, op.orientation.w or 0.0))
            if pose[1] == (0.0, 0.0, 0.0, 0.0):
                pose = (pose[0], (0.0, 0.0, 0.0, 1.0))
            prim = ((pp0.position.x, pp0.position.y, pp0.position.z),
                    (pp0.orientation.x, pp0.orientation.y, pp0.orientation.z, pp0.orientation.w))
            xyz, quat = tg.compose(pose, prim)
            out.append((obj.id, tuple(obj.primitives[0].dimensions[:3]), xyz, quat))
        return out

    def publish_event(self, **kw):
        self.events.publish(String(data=json.dumps(kw)))

    def try_grasp(self):
        tip = self.tcp_now()
        if tip is None:
            return
        boxes = self.world_boxes()
        oid = tg.find_graspable(tip, boxes)
        if oid is None:
            print(f'  nothing between the fingers (fingertips x={tip[0]:.3f} y={tip[1]:.3f} z={tip[2]:.3f})')
            return
        # the fingers may touch it, then attach it to the gripper: it now moves with the tool
        req = GetPlanningScene.Request()
        req.components.components = PlanningSceneComponents.ALLOWED_COLLISION_MATRIX
        acm = self.call(self.get_scene, req).scene.allowed_collision_matrix
        aco = AttachedCollisionObject()
        aco.link_name = pp.ATTACH_LINK
        aco.object = CollisionObject(id=oid, operation=CollisionObject.ADD)
        aco.object.header.frame_id = bs.FRAME
        aco.touch_links = pp.GRIPPER_LINKS
        scene = PlanningScene(is_diff=True)
        scene.allowed_collision_matrix = bs.set_acm_entries(acm, {oid: pp.GRIPPER_LINKS})
        scene.robot_state.is_diff = True
        scene.robot_state.attached_collision_objects.append(aco)
        if self.apply(scene):
            self.held = oid
            self.cache = {}                                   # plans made without the object are void
            print(f'  grasped {oid}: it now moves with the gripper')
            self.publish_event(event='grasped', id=oid)
        else:
            print(f'  could not attach {oid}')

    def release(self):
        oid, self.held = self.held, None
        aco = AttachedCollisionObject()
        aco.link_name = pp.ATTACH_LINK
        aco.object = CollisionObject(id=oid, operation=CollisionObject.REMOVE)
        scene = PlanningScene(is_diff=True)
        scene.robot_state.is_diff = True
        scene.robot_state.attached_collision_objects.append(aco)
        if not self.apply(scene):                             # back into the world where it is now
            print(f'  could not release {oid}')
            return
        boxes = self.world_boxes()
        mine = [b for b in boxes if b[0] == oid]
        if not mine:
            print(f'  released {oid}')
            return
        _, dims, xyz, quat = mine[0]
        new_xyz, new_q = tg.drop_pose(xyz, quat, dims, boxes, bs.Z_FLOOR + bs.Z_MARGIN, oid)
        obj = CollisionObject(id=oid, operation=CollisionObject.ADD)
        obj.header.frame_id = bs.FRAME
        obj.pose.orientation.w = 1.0
        obj.primitives.append(SolidPrimitive(type=SolidPrimitive.BOX, dimensions=list(dims)))
        p = Pose()
        p.position.x, p.position.y, p.position.z = new_xyz
        p.orientation.x, p.orientation.y, p.orientation.z, p.orientation.w = new_q
        obj.primitive_poses.append(p)
        scene = PlanningScene(is_diff=True)
        scene.world.collision_objects.append(obj)
        self.apply(scene)
        self.cache = {}
        fell = xyz[2] - new_xyz[2]
        print(f'  released {oid}: dropped {fell * 100:.1f} cm onto z={new_xyz[2] - dims[2] / 2:.3f}')
        self.publish_event(event='released', id=oid, xyz=list(new_xyz), yaw=tg.yaw_of(new_q))

    def grip_events(self, msg):
        def edge(i):
            now = len(msg.buttons) > i and bool(msg.buttons[i])
            was = len(self.prev_buttons) > i and bool(self.prev_buttons[i])
            return now and not was
        close, opn = edge(2), edge(3)
        self.prev_buttons = list(msg.buttons)
        if close or opn:
            self.do_grip(close)

    # ---- main loop
    def run(self):
        if not self.dry:
            self.allow_gripper_contact()
            self.allow_fingers_near_table()
            if not self.find_controller():
                print('  Cannot reach the arm controller. Not starting.')
                return
        mode = 'Speed follows the push, max' if self.analog else 'Constant slow speed'
        print(f'Hold-to-move ready. {mode} {self.speed} m/s. Left pad: left/right + forward/back. '
              f'Right pad: up/down. Ctrl+C to stop.')
        last_report = 0.0
        while rclpy.ok():
            rclpy.spin_once(self, timeout_sec=0.02)
            now = time.monotonic()
            self.service_goal()
            self.watchdog(now)
            if self.fast_q is not None and self.moving() and now - self.fast_t > JS_GAP_STOP_S:
                self.js_gap_stops += 1
                print(f'  joint states paused for {(now - self.fast_t) * 1000:.0f} ms while moving: stopped '
                      f'(stall {self.js_gap_stops}). Push again to continue.')
                self.stop()
                self.blocked = None
                continue
            msg = self.joy
            fresh = msg is not None and now - self.joy_time <= STALE_S
            cv_fresh = self.cmd_vel is not None and now - self.cmd_vel_time <= CMD_VEL_TIMEOUT
            if self.grip_request is not None and not self.dry:
                req, self.grip_request = self.grip_request, None
                self.do_grip(req == 'close')
            if now - last_report > 1.0:
                last_report = now
                if cv_fresh and not fresh:
                    tip = self.tcp_now()
                    where = '' if tip is None else f' fingertips x={tip[0]:.3f} y={tip[1]:.3f} z={tip[2]:.3f}'
                    cd, cf = self.cmd_vel_command()
                    print(f'  [status]{where} | {"moving" if self.moving() else "stopped"} | {CMD_VEL_TOPIC}: '
                          f'{"nothing" if cd is None else describe_direction(cd) + f" {int(cf * 100)}%"}')
                elif msg is None:
                    print('  [status] no /etee/joy messages yet. Is etee_bridge.py running and the Windows reader connected?')
                elif not fresh:
                    print('  [status] /etee/joy has stopped arriving, stopping.')
                else:
                    tip = self.tip_now()
                    where = (f' fingertips x={tip.position.x:.3f} y={tip.position.y:.3f} '
                             f'z={tip.position.z - self.tcp_off():.3f}') if tip else ''
                    ax = list(msg.axes) + [0.0] * 4
                    bt = list(msg.buttons) + [0] * 4
                    dd, mm = pad_command(msg, self.flips)
                    cmd = 'nothing' if dd is None else f'{describe_direction(dd)} {int(speed_fraction(mm) * 100)}%'
                    print(f'  [status]{where} | {"moving" if self.moving() else "stopped"} | cmd: {cmd} | '
                          f'left pad x {ax[0]:+.2f} y {ax[1]:+.2f} touch {int(bt[0])} | '
                          f'right pad y {ax[3]:+.2f} touch {int(bt[1])}'
                          f'{"" if self.armed else " | NOT ARMED: release both pads"}')
            if not fresh and not cv_fresh:
                self.stop()
                self.publish_state(now, 'none', None, 0.0)
                if not self.dry and not self.moving():
                    self.precompute_one()               # v4: warm the plan cache before the first input arrives
                continue
            if fresh and not self.dry:
                self.grip_events(msg)
            d, mag = pad_command(msg, self.flips) if fresh else (None, 0.0)
            frac = speed_fraction(mag) if self.analog else 1.0
            source = 'operator'
            if d is None and cv_fresh:                     # the operator's pads always win (override)
                d, frac = self.cmd_vel_command()
                source = CMD_VEL_TOPIC
            self.publish_state(now, source if d is not None else 'none', d, frac)
            if not self.armed:                             # nothing moves until both pads have been seen at rest
                if d is None:
                    if not self.dry and not self.moving():
                        self.precompute_one()           # v4: plan ahead while waiting to arm
                    self.rest_since = self.rest_since or now
                    if now - self.rest_since > 0.5:
                        self.armed = True
                        print('  armed: inputs at rest, ready to move')
                else:
                    self.rest_since = None
                continue
            if d is None:                                  # pads released: stop
                self.blocked = None
                self.stop()
                self.pending_level = (None, 0.0)
                if not self.dry and not self.moving():
                    self.precompute_one()               # use the idle time to plan ahead
                continue
            if self.blocked is not None and float(np.dot(d, self.blocked)) > math.cos(math.radians(DIR_CHANGE_DEG)):
                continue                                   # still pushing into a limit: stay stopped until released
            self.blocked = None
            if self.moving():
                tcp = self.tcp_now()                       # closed loop: check where the fingertips REALLY are
                if tcp is not None and max_length(tcp, self.active_dir) < LIMIT_STOP_M:
                    print(f'  limit reached ({limit_reason(tcp, self.active_dir)}); stopped. Release, then push another way.')
                    self.blocked = self.active_dir
                    self.stop()
                    continue
                angle = math.degrees(math.acos(max(-1.0, min(1.0, float(np.dot(d, self.active_dir))))))
                changed = angle > DIR_CHANGE_DEG
                if frac != self.active_frac:
                    if self.pending_level[0] != frac:
                        self.pending_level = (frac, now)
                    elif now - self.pending_level[1] > LEVEL_CHANGE_S:
                        changed = True
                else:
                    self.pending_level = (None, 0.0)
                if changed:
                    self.stop()
                    self.settle_wait()
                    self.pending_level = (None, 0.0)
                else:
                    continue
            elif self.goal_handle is not None:                  # a path just finished (reached its end)
                self.goal_handle = None
                tcp = self.tcp_now()
                if tcp is not None and max_length(tcp, d) < 0.01:
                    print(f'  limit reached ({limit_reason(tcp, d)}); stopped. Release, then push another way.')
                    self.blocked = d
                    continue
                self.settle_wait()
            if self.dry:
                print(f'  [dry-run] would move {describe_direction(d)} at {int(frac * 100)}% speed')
                time.sleep(0.25)
                continue
            if not self.moving():
                if now < self.retry_after:                 # a refused push is not retried (and printed) every loop
                    continue
                if not self.start_path(d, frac):
                    self.retry_after = time.monotonic() + 1.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--speed', type=float, default=0.01, help='top tool speed in m/s with the pad fully pushed')
    ap.add_argument('--settle', type=float, default=0.1, help='pause (s) after stopping before planning again')
    ap.add_argument('--scale', type=float, default=pp.SCALE, help='gripper speed scaling')
    ap.add_argument('--flip-x', action='store_true', help='reverse forward/back')
    ap.add_argument('--flip-y', action='store_true', help='reverse left/right')
    ap.add_argument('--flip-z', action='store_true', help='reverse up/down')
    ap.add_argument('--deadzone', type=float, default=0.30, help='ignore pad movement below this (0-0.8). Raise it if the arm moves when you only rest your thumb')
    ap.add_argument('--curve', type=float, default=1.6, help='response curve, 1 = linear, 2 = much gentler light pushes')
    ap.add_argument('--max-step', type=float, default=MAX_STEP, help='metres between planned path points')
    ap.add_argument('--analog', action='store_true', help='speed follows how hard you push (3 levels). Default: one constant slow speed')
    ap.add_argument('--no-auto-grasp', action='store_true', help='v4: do not attach objects when the gripper closes')
    ap.add_argument('--reach', type=float, default=None, help='v4: forward limit in m (default 0.65)')
    ap.add_argument('--clearance-mm', type=float, default=None, help='v4: stop this far above the modelled table (default 1.5)')
    ap.add_argument('--dry-run', action='store_true', help='read the pads and print what would happen; the arm never moves')
    args = ap.parse_args()
    global MIN_CLEARANCE
    if args.reach is not None:
        LIMITS['x'] = (LIMITS['x'][0], min(args.reach, _fx1))
    if args.clearance_mm is not None:
        MIN_CLEARANCE = max(0.0, args.clearance_mm / 1000.0)
    print(f'  limits: x {LIMITS["x"][0]:.2f}..{LIMITS["x"][1]:.2f} m, y {LIMITS["y"][0]:.2f}..{LIMITS["y"][1]:.2f} m, '
          f'fingertips stop {(bs.Z_MARGIN + MIN_CLEARANCE) * 1000:.1f} mm above the real table')
    args.speed = min(args.speed, 0.15)
    etee_input.DEADZONE = max(0.05, min(0.8, args.deadzone))
    etee_input.CURVE = max(1.0, min(3.0, args.curve))
    pp.SCALE = args.scale
    rclpy.init()
    node = EteeHold(args)
    print('Fake hardware first. Real arm: supervisor present, E-stop in reach, --speed 0.02.')
    if args.dry_run or input('Type YES to start: ').strip() == 'YES':
        try:
            node.run()
        except KeyboardInterrupt:
            pass
        node.stop()
    node.destroy_node()
    if rclpy.ok():
        rclpy.shutdown()


if __name__ == '__main__':
    main()
