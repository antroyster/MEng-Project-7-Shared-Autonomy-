# digital_twin_v5: GUI (builds on v4)

- Etee motion view in the GUI: both controllers shown in 3D, turning exactly as you turn them (orientation from each
  controller's own motion sensor, /etee/orientation), swaying and leaving a trail when you move them (/etee/accel),
  with a ring that lights up while moving. Only the Etee dongle is needed: no SteamVR or other apps.
- Title screen: live start-up checklist (ROS link, twin, planning scene, robot model) and mode cards.
  Click the top-left logo to return to it. Keyboard commands are only sent after a mode is chosen.
- `gui/`: browser app with a live 3D view (robot from its URDF, MoveIt scene, fingertip marker), Keyboard mode
  (keycaps, hold to move, speed slider, STOP) and Etee mode (live controller view), status, limits and events.
  `twin.sh` starts the whole twin (arm or simulation, scene, hold node, perception, GUI) with no RViz and opens
  the GUI. Keyboard top speed now follows --speed (default 50 mm/s in simulation, 30 mm/s on the real arm).

# digital_twin_v4: perception-driven grasping (builds on v3)

- Automatic grasp: closing the gripper on any scene object (a WP3-perceived block or the demo block) attaches it,
  so it lifts with the arm. Opening releases it and it drops onto the table or the block underneath (`ros/twin_grasp.py`,
  tested by `ros/test_twin_grasp.py`). No more pressing g. `--no-auto-grasp` turns it off.
- WP3 bridge lets the fingers (not the gripper body or the arm) touch perceived blocks, so they can close around them.
- Mock WP3 publisher (`ros/mock_wp3_publisher.py`): fake blocks for testing without cameras; it follows blocks the twin moves.
- `ros/start_perception.sh`: table frame + bridge + mock in one window (`--live` for the real WP3 node).
- Limits: forward x 0.55 -> 0.65 m (`--reach`); fingertips now stop about 3.5 mm above the real table (was ~1 to 1.5 cm):
  clearance 6 -> 1.5 mm, stop margin 4 -> 1 mm, smallest planned path 10 -> 2 mm, modelled table margin 3 -> 1 mm
  (`--clearance-mm`). When MoveIt cuts a path short the node now prints which bodies collide.
- Fingertip length follows the gripper opening: measured 238 mm closed, 224 mm open (coin tests 24 Nov). The fingers
  may come close to the table in MoveIt's check, because the model's finger shapes reach it ~14 mm early; the fingertip
  limit (about 3 mm above the real table) protects it. Before this the open gripper stopped 16-24 mm up.
- Closing near the table first lifts the arm just enough (up to ~14 mm), because the fingertips swing down as the
  gripper closes; without it the closed fingers scraped the table.
- Joint states read from the driver's 146 Hz topic; the arm stops if they pause > 100 ms while moving.
- Velocity interface for WP5 (`INTERFACE.md`): `/twin/cmd_vel` (TwistStamped), `/twin/gripper_cmd`, `/twin/state`;
  operator pads always override. Example client `ros/cmd_vel_demo.py`.
- `ros/check_real_arm.py`: checks the real-arm link (network, driver, controller error/mode/motors, all-zero joints,
  twin vs controller joints); `--fix` clears errors and enables the motors.
- `ros/sync_eval.py`: synchronisation evaluation (rate/jitter/age, command-to-motion latency, twin vs controller
  and twin vs measured fingertip error), saved as CSV in ~/wp2_sync_results/.

# digital_twin_v3: tilt control (builds on v2)

v2 = trackpad + keyboard control. v3 adds Etee tilt steering and moves the gripper to trackpad presses. Tilt is experimental.

# Changes in this version

- `ros/etee_hold.py`: the gripper now opens and closes through the xArm gripper action
  (`/xarm_gripper/gripper_action`, GripperCommand). Going through MoveIt failed with error -26 (start state invalid)
  on the real arm. MoveIt is still the fallback if the action is missing.
- `ros/build_scene.py`: base plate thickness 8 mm (measured), so the table top is at z = -0.008 in the scene.
- `ros/wp3_*.py`, `fit_table_tf.py`, `start_wp3.sh`, `test_wp3_offline.py`, `add_camera.py`: WP3 perception link,
  written by Shadi (WP3). See WP3_HANDOFF.md.
- Keyboard hold-to-move (`keyboard/`) and Etee trackpad hold-to-move (`etee/`) are unchanged and tested on the real arm.

- `etee/etee_reader_windows.py`: gripper moved to trackpad presses (right press = close, left press = open) so the
  squeeze can be the tilt enable. `--tilt-enable` now defaults to `middle` (clicks when you squeeze). Use
  `--grip-source squeeze` for the old behaviour. Tilt steering is still experimental.
- `etee/etee_reader_windows.py`: with `--tilt`, squeeze the RIGHT controller and tilt it for forward/back/left/right, squeeze
  the LEFT controller and tilt it forward/back for up/down (`--no-tilt-z`, `--tilt-z-hand`, `--tilt-z-flip`, `--tilt-z-swap`).
  Tilt axes are built from the pose at the moment of the squeeze, so any grip works. Not yet validated on the real arm.
