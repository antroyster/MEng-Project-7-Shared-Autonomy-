// xArm digital twin GUI (v5). Talks to ROS through rosbridge (ws://<host>:9090).
// The GUI never moves the arm by itself: in Keyboard mode it publishes /twin/cmd_vel and /twin/gripper_cmd,
// which etee_hold.py checks against its limits; in Etee mode it only displays /etee/joy.

const $ = (id) => document.getElementById(id);
const HOST = location.hostname || 'localhost';
const RATE_MS = 50;                     // keyboard heartbeat: 20 commands per second
const STALE_MS = 600;                   // a topic quieter than this counts as lost

// ------------------------------------------------------------------ 3D view (loaded separately so the UI
// still works if the 3D libraries cannot be downloaded)
let view = null, motion = null;
import('./etee3d.js?v=6').then(({ EteeMotion }) => {
  const MODES = { orientation: ['m6', 'Live: orientation + movement'],
                  tilt: ['mt', 'Tilt + movement (no orientation from the sensor)'], none: ['', 'No motion data'] };
  motion = new EteeMotion($('etee-motion'), (m) => {
    const [cls, text] = MODES[m] || MODES.none;
    const el = $('motion-mode'); el.className = cls; el.innerHTML = `<i></i>${text}`;
    if (m !== 'none') log(`Etee motion: <b>${text}</b>`);
  });
  $('recentre').addEventListener('click', () => motion.recentre());
}).catch((e) => console.error('Etee motion view:', e));
import('./scene3d.js?v=6').then(async ({ TwinScene }) => {
  view = new TwinScene($('view'), (msg) => { $('view-msg').textContent = msg; });
  try {
    await view.loadRobot('/robot.urdf');
  } catch (e) {
    $('view-msg').textContent = 'Robot model not available yet: start the simulation or start_real.sh, then reload.';
    setTimeout(() => location.reload(), 5000);
  }
}).catch((e) => {
  $('view-msg').textContent = '3D view could not load (no internet for the 3D libraries?). Controls still work.';
  console.error(e);
});

// ------------------------------------------------------------------ ROS connection (reconnects by itself)
let ros = null, topics = {};
function connect() {
  ros = new ROSLIB.Ros({ url: `ws://${HOST}:9090` });
  ros.on('connection', () => { setPill('pill-ros', 'ok'); log('Connected to ROS'); subscribe(); });
  ros.on('error', () => setPill('pill-ros', 'bad'));
  ros.on('close', () => { setPill('pill-ros', 'bad'); setTimeout(connect, 2000); });
}
function topic(name, type) { return new ROSLIB.Topic({ ros, name, messageType: type, queue_length: 1 }); }

const last = { state: 0, joy: 0, scene: 0 };
let twin = null, joy = null, lastRefusal = '';

function subscribe() {
  topics.cmdVel = topic('/twin/cmd_vel', 'geometry_msgs/msg/TwistStamped');
  topics.grip = topic('/twin/gripper_cmd', 'std_msgs/msg/String');
  topic('/twin/state', 'std_msgs/msg/String').subscribe((m) => { twin = JSON.parse(m.data); last.state = Date.now(); showTwin(); });
  topic('/etee/joy', 'sensor_msgs/msg/Joy').subscribe((m) => { joy = m; last.joy = Date.now(); showEtee(); });
  topic('/etee/accel', 'std_msgs/msg/Float32MultiArray').subscribe((m) => { if (motion) motion.setAccel(m.data); });
  topic('/etee/orientation', 'std_msgs/msg/Float32MultiArray').subscribe((m) => { if (motion) motion.setOrientation(m.data); });
  topic('/twin/object_events', 'std_msgs/msg/String').subscribe((m) => {
    const e = JSON.parse(m.data);
    const name = niceName(e.id);
    if (e.event === 'grasped') { toast(`Picked up ${name}`, 'good'); log(`<b>Grasped</b> ${name}`); }
    if (e.event === 'released') { toast(`Released ${name}`, 'good'); log(`<b>Released</b> ${name}`); }
  });
  const js = topic('/joint_states', 'sensor_msgs/msg/JointState');
  js.subscribe((m) => { if (view) view.setJoints(m.name, m.position); });
}
connect();

// ------------------------------------------------------------------ scene objects (table, fence, blocks)
async function pollScene() {
  try {
    const s = await (await fetch('/scene.json', { cache: 'no-store' })).json();
    if (s.ok) { last.scene = Date.now(); if (view) view.setObjects(s.objects); }
  } catch (e) { /* server restarting */ }
}
setInterval(pollScene, 250);

// ------------------------------------------------------------------ modes
let mode = 'keyboard';
document.querySelectorAll('.mode').forEach((b) => b.addEventListener('click', () => setMode(b.dataset.mode)));
function setMode(m) {
  mode = m;
  held.clear(); showKeys();
  document.querySelectorAll('.mode').forEach((b) => b.classList.toggle('active', b.dataset.mode === m));
  $('panel-keyboard').classList.toggle('hidden', m !== 'keyboard');
  $('panel-etee').classList.toggle('hidden', m !== 'etee');
  $('stop').classList.toggle('hidden', m !== 'keyboard');
  log(`Mode: <b>${m === 'keyboard' ? 'Keyboard' : 'Etee controllers'}</b>`);
}

// ------------------------------------------------------------------ keyboard mode
const KEYMAP = { w: 'w', arrowup: 'w', s: 's', arrowdown: 's', a: 'a', arrowleft: 'a', d: 'd', arrowright: 'd',
                 r: 'r', pageup: 'r', f: 'f', pagedown: 'f', c: 'c', o: 'o' };
const held = new Set();
let focused = document.hasFocus();
let precise = false;
window.addEventListener('keydown', (e) => { if (e.key === 'Shift') { precise = true; $('precise').classList.add('on'); } });
window.addEventListener('keyup', (e) => { if (e.key === 'Shift') { precise = false; $('precise').classList.remove('on'); } });

function press(k) {
  if (mode !== 'keyboard') return;
  if (k === 'c' || k === 'o') {
    if (!held.has(k) && topics.grip) {
      topics.grip.publish({ data: k === 'c' ? 'close' : 'open' });
      log(`<b>${k === 'c' ? 'Close' : 'Open'}</b> gripper`);
    }
  }
  held.add(k); showKeys();
}
function release(k) { held.delete(k); showKeys(); }
function showKeys() { document.querySelectorAll('.key').forEach((el) => el.classList.toggle('on', held.has(el.dataset.key))); }

function setSpeed(v) {
  const sl = $('speed');
  sl.value = Math.max(1, Math.min(Number(sl.max), Math.round(v)));
  speedTouched = true;
  $('speed-out').textContent = sl.value;
}
window.addEventListener('keydown', (e) => {
  if (mode === 'keyboard' && /^[1-5]$/.test(e.key)) {           // 1..5 = 10 %, 25 %, 50 %, 75 %, 100 % of the top speed
    setSpeed(Number($('speed').max) * [0.1, 0.25, 0.5, 0.75, 1][Number(e.key) - 1]);
    toast(`Speed ${$('speed').value} mm/s`); return;
  }
  const k = KEYMAP[e.key.toLowerCase()];
  if (e.key.toLowerCase() === 'v' && view) { view.resetView(); return; }
  if (e.key === ' ' ) { stopAll(); e.preventDefault(); return; }
  if (!k) return;
  e.preventDefault();
  if (!e.repeat) press(k);
});
window.addEventListener('keyup', (e) => { const k = KEYMAP[e.key.toLowerCase()]; if (k) release(k); });
window.addEventListener('blur', () => { focused = false; precise = false; $('precise').classList.remove('on'); held.clear(); showKeys(); });
window.addEventListener('focus', () => { focused = true; });
document.querySelectorAll('.key').forEach((el) => {     // on-screen keys: press and hold with mouse or touch
  el.addEventListener('pointerdown', (e) => { el.setPointerCapture(e.pointerId); press(el.dataset.key); });
  el.addEventListener('pointerup', () => release(el.dataset.key));
  el.addEventListener('pointercancel', () => release(el.dataset.key));
});
let speedTouched = false;
$('speed').addEventListener('input', () => { speedTouched = true; $('speed-out').textContent = $('speed').value; });

function stopAll() {
  held.clear(); showKeys();
  if (topics.cmdVel) sendVel(0, 0, 0);
  toast('Stopped', 'warn'); log('<b>STOP</b> pressed');
}
$('stop').addEventListener('click', stopAll);

function sendVel(x, y, z) {
  topics.cmdVel.publish({ header: { frame_id: 'world' },
                          twist: { linear: { x, y, z }, angular: { x: 0, y: 0, z: 0 } } });
}

// the heartbeat: only in keyboard mode and only while this page has focus. If it stops (tab hidden,
// browser closed, Wi-Fi lost) the hold node stops the arm 0.3 s later: safety does not depend on the GUI.
setInterval(() => {
  if (!entered || mode !== 'keyboard' || !focused || !topics.cmdVel || !ros || !ros.isConnected) return;
  const v = Number($('speed').value) / 1000 * (precise ? 0.2 : 1);   // hold Shift for fine, slow moves
  sendVel((held.has('w') - held.has('s')) * v, (held.has('a') - held.has('d')) * v, (held.has('r') - held.has('f')) * v);
}, RATE_MS);

// ------------------------------------------------------------------ Etee mode display
function showEtee() {
  const a = joy.axes, b = joy.buttons;
  const side = (id, x, y, touch, grip) => {
    const el = $(id);
    el.classList.toggle('touch', !!touch);
    el.classList.toggle('grip', !!grip);
    el.classList.remove('off');
    const t = el.querySelector('.thumb');
    t.setAttribute('cx', 60 + 30 * x);
    t.setAttribute('cy', 60 - 30 * y);
  };
  side('etee-left', a[0] || 0, a[1] || 0, b[0], b[3]);
  side('etee-right', a[2] || 0, a[3] || 0, b[1], b[2]);
  if (motion) ['left', 'right'].forEach((h) => $(`etee-${h}`).classList.toggle('moving', motion.moving(h)));
}

// ------------------------------------------------------------------ status display
const SOURCE = { operator: 'Operator (Etee / keys)', '/twin/cmd_vel': 'GUI / velocity interface', none: 'Idle' };
function niceName(id) { return String(id).replace(/^(wp3_)+/, '').replace(/^blocks?_/, 'block ').replace(/_/g, ' '); }
function mm(v) { return (v * 1000).toFixed(1); }
function showTwin() {
  const t = twin;
  if (t.speed_cap_m_s) {                                // the slider can go as fast as the twin allows, no faster
    const cap = Math.round(t.speed_cap_m_s * 1000), sl = $('speed');
    if (Number(sl.max) !== cap) {
      sl.max = cap;
      if (!speedTouched) sl.value = Math.min(cap, 25);
      if (Number(sl.value) > cap) sl.value = cap;
      $('speed-out').textContent = sl.value;
      $('speed-cap').textContent = cap;
    }
  }
  if (view) view.setFingertip(t.fingertips_m);
  if (t.fingertips_m) {
    const [x, y, z] = t.fingertips_m;
    $('m-x').textContent = mm(x); $('m-y').textContent = mm(y); $('m-z').textContent = mm(z);
    const h = (z + 0.008) * 1000;                       // table top is 8 mm below the base plate
    $('m-h').textContent = `${h.toFixed(1)} mm`;
    const bar = $('m-hbar');
    bar.style.width = `${Math.max(2, Math.min(100, h / 4))}%`;   // full bar = 40 cm
    bar.style.background = h < 10 ? 'var(--warn)' : 'var(--accent)';
  }
  $('m-speed').textContent = t.moving ? `${(t.speed_m_s * 1000).toFixed(1)} mm/s` : '0';
  $('m-source').textContent = SOURCE[t.source] || t.source;
  $('m-held').textContent = t.held_object ? niceName(t.held_object) : 'nothing';
  $('m-refusal').textContent = t.last_refusal || '–';
  if (t.last_refusal && t.last_refusal !== lastRefusal) { toast(`Stopped: ${t.last_refusal}`, 'warn'); log(`<b>Limit</b> ${t.last_refusal}`); }
  lastRefusal = t.last_refusal;
  const banner = $('banner');
  if (!t.armed) { banner.textContent = 'Waiting: release all inputs to arm'; banner.className = 'state-banner limit'; }
  else if (t.moving) { banner.textContent = `Moving ${describe(t.direction)}`; banner.className = 'state-banner moving'; }
  else { banner.textContent = t.held_object ? 'Holding object, ready' : 'Ready'; banner.className = 'state-banner idle'; }
}
function describe(d) {
  if (!d) return '';
  const names = [['forward', 'back'], ['left', 'right'], ['up', 'down']];
  return d.map((v, i) => Math.abs(v) > 0.3 ? names[i][v > 0 ? 0 : 1] : null).filter(Boolean).join(' + ');
}

// health pills, the input pill and the Etee hint, once a second
setInterval(() => {
  const now = Date.now();
  setPill('pill-twin', now - last.state < STALE_MS ? 'ok' : 'bad');
  setPill('pill-scene', now - last.scene < 2000 ? 'ok' : 'bad');
  const joyOk = now - last.joy < STALE_MS;
  const input = $('pill-input');
  if (mode === 'keyboard') { input.querySelector('span').textContent = 'Keyboard'; setPill('pill-input', focused ? 'ok' : 'warn'); }
  else { input.querySelector('span').textContent = 'Etee'; setPill('pill-input', joyOk ? 'ok' : 'bad'); }
  $('etee-hint').textContent = joyOk ? 'Controllers connected. Touch a pad to move.'
    : 'No controller data. Start start_bridge.sh in Ubuntu and the Etee reader in Windows.';
  if (!joyOk) document.querySelectorAll('.etee').forEach((el) => el.classList.add('off'));
  if (mode === 'etee' && twin) $('etee-cmd').textContent = twin.moving ? describe(twin.direction) : 'nothing';
  if (now - last.state > STALE_MS) { const b = $('banner'); b.textContent = 'Twin not running (start etee_hold.py)'; b.className = 'state-banner down'; }
}, 1000);

// ------------------------------------------------------------------ helpers
function setPill(id, cls) { const p = $(id); p.classList.remove('ok', 'warn', 'bad'); p.classList.add(cls); }
function toast(text, cls = '') {
  const el = document.createElement('div');
  el.className = `toast ${cls}`; el.textContent = text;
  $('toasts').appendChild(el);
  setTimeout(() => el.remove(), 4000);
}
function log(html) {
  const li = document.createElement('li');
  li.innerHTML = `<span>${html}</span><time>${new Date().toLocaleTimeString()}</time>`;
  $('log').prepend(li);
  while ($('log').children.length > 40) $('log').lastChild.remove();
}
setMode('keyboard');

// ------------------------------------------------------------------ title screen: real start-up checks, then mode choice
let entered = false;
const splash = $('splash');
const bootItems = [...document.querySelectorAll('#boot li')];
bootItems.forEach((li, i) => setTimeout(() => li.classList.add('shown'), 350 + i * 220));
const CHECKS = {
  ros: () => ros && ros.isConnected,
  twin: () => Date.now() - last.state < STALE_MS,
  scene: () => Date.now() - last.scene < 2000,
  model: () => !!(view && view.robot && view.meshesLoaded),
};
const bootTimer = setInterval(() => {
  let ok = 0;
  bootItems.forEach((li) => {
    const good = CHECKS[li.dataset.check]();
    li.classList.toggle('ok', good);
    li.querySelector('em').textContent = good ? 'online' : 'waiting';
    ok += good ? 1 : 0;
  });
  const all = ok === bootItems.length;
  $('splash-modes').classList.add('ready');          // modes are always choosable; the checklist says what is missing
  $('splash-foot').textContent = all ? 'All systems online. Choose a mode, or press Enter for Keyboard.'
                                     : `${ok} of ${bootItems.length} systems online. You can start anyway.`;
}, 300);
function enter(m) {
  setMode(m);
  entered = true;
  splash.classList.add('gone');
  held.clear(); showKeys();
  log(`Session started in <b>${m === 'keyboard' ? 'Keyboard' : 'Etee'}</b> mode`);
  if (view) view.resize();
}
document.querySelectorAll('.mode-card').forEach((b) => b.addEventListener('click', () => enter(b.dataset.start)));
window.addEventListener('keydown', (e) => { if (!entered && e.key === 'Enter') enter('keyboard'); }, true);
$('brand').addEventListener('click', () => { entered = false; held.clear(); showKeys(); splash.classList.remove('gone'); });
