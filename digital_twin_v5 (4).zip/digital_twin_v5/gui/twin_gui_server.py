#!/usr/bin/env python3
"""Web server for the digital-twin GUI (v5). Run it with the 4 setup lines pasted, next to rosbridge:

    python3 twin_gui_server.py            then open http://localhost:8000 in the Windows browser

It serves:
  /                 the GUI (index.html, style.css, app.js, scene3d.js from this folder)
  /robot.urdf       the robot model, read from /robot_description (mesh paths as package://...)
  /pkg/<pkg>/<path> files from ROS packages (the robot meshes)
  /scene.json       MoveIt's planning scene as world-frame boxes (table, fence, power box, blocks from WP3,
                    and the object in the gripper), refreshed twice a second

Live data that changes fast (joint angles, /twin/state, /etee/joy) and the keyboard commands go through
rosbridge (port 9090), not through this server.
"""
import json
import math
import mimetypes
import os
import re
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

import rclpy
from ament_index_python.packages import get_package_share_directory, PackageNotFoundError
from moveit_msgs.msg import PlanningSceneComponents
from moveit_msgs.srv import GetPlanningScene
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from rclpy.time import Time
from shape_msgs.msg import SolidPrimitive
from std_msgs.msg import String
from tf2_ros import Buffer, TransformListener

HERE = os.path.dirname(os.path.abspath(__file__))
WORLD = 'world'


def quat_mul(a, b):
    ax, ay, az, aw = a
    bx, by, bz, bw = b
    return (aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw,
            aw * bw - ax * bx - ay * by - az * bz)


def quat_rotate(q, v):
    x, y, z, w = q
    vx, vy, vz = v
    # v' = q v q*
    tx = 2 * (y * vz - z * vy)
    ty = 2 * (z * vx - x * vz)
    tz = 2 * (x * vy - y * vx)
    return (vx + w * tx + (y * tz - z * ty),
            vy + w * ty + (z * tx - x * tz),
            vz + w * tz + (x * ty - y * tx))


def compose(p1, q1, p2, q2):
    """(p1, q1) then (p2, q2) relative to it."""
    r = quat_rotate(q1, p2)
    return (p1[0] + r[0], p1[1] + r[1], p1[2] + r[2]), quat_mul(q1, q2)


def pose_tuple(p):
    q = (p.orientation.x, p.orientation.y, p.orientation.z, p.orientation.w)
    if q == (0.0, 0.0, 0.0, 0.0):
        q = (0.0, 0.0, 0.0, 1.0)
    return (p.position.x, p.position.y, p.position.z), q


def rewrite_mesh_paths(urdf):
    """file:///.../share/pkg/x -> package://pkg/x, so the browser asks this server for /pkg/pkg/x"""
    return re.sub(r'file://[^"\']*?/share/([^/"\']+)/', r'package://\1/', urdf)


class SceneNode(Node):
    def __init__(self):
        super().__init__('twin_gui_server')
        self.urdf = None
        self.scene = {'objects': [], 'stamp': 0.0, 'ok': False}
        self.lock = threading.Lock()
        qos = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL, reliability=ReliabilityPolicy.RELIABLE)
        self.create_subscription(String, '/robot_description', self.on_description, qos)
        self.cli = self.create_client(GetPlanningScene, '/get_planning_scene')
        self.tf = Buffer()
        TransformListener(self.tf, self)
        self.pending = None
        self.create_timer(0.5, self.poll)

    def on_description(self, msg):
        with self.lock:
            self.urdf = rewrite_mesh_paths(msg.data)
        self.get_logger().info(f'robot model received ({len(msg.data)} characters)')

    def poll(self):
        if self.pending is not None and not self.pending.done():
            return
        if self.pending is not None:
            try:
                self.store(self.pending.result().scene)
            except Exception as e:                       # noqa: BLE001
                self.get_logger().warning(f'scene: {e}')
            self.pending = None
        if not self.cli.service_is_ready():
            return
        req = GetPlanningScene.Request()
        req.components.components = (PlanningSceneComponents.WORLD_OBJECT_NAMES |
                                      PlanningSceneComponents.WORLD_OBJECT_GEOMETRY |
                                      PlanningSceneComponents.ROBOT_STATE_ATTACHED_OBJECTS |
                                      PlanningSceneComponents.OBJECT_COLORS)
        self.pending = self.cli.call_async(req)

    def link_pose(self, frame):
        if frame in ('', WORLD):
            return (0.0, 0.0, 0.0), (0.0, 0.0, 0.0, 1.0)
        t = self.tf.lookup_transform(WORLD, frame, Time())
        tr, ro = t.transform.translation, t.transform.rotation
        return (tr.x, tr.y, tr.z), (ro.x, ro.y, ro.z, ro.w)

    def boxes(self, obj, attached_to=None):
        out = []
        try:
            base = self.link_pose(obj.header.frame_id or attached_to or WORLD)
        except Exception:                                # noqa: BLE001  (TF not ready yet)
            return out
        op = pose_tuple(obj.pose)
        p0, q0 = compose(base[0], base[1], op[0], op[1])
        for prim, pp in zip(obj.primitives, obj.primitive_poses):
            if prim.type != SolidPrimitive.BOX or len(prim.dimensions) < 3:
                continue
            p2, q2 = pose_tuple(pp)
            p, q = compose(p0, q0, p2, q2)
            out.append({'id': obj.id, 'size': list(prim.dimensions[:3]), 'pos': list(p), 'quat': list(q),
                        'held': attached_to is not None})
        return out

    def store(self, scene):
        colours = {c.id: [c.color.r, c.color.g, c.color.b, c.color.a] for c in scene.object_colors}
        objs = []
        for obj in scene.world.collision_objects:
            objs += self.boxes(obj)
        for aco in scene.robot_state.attached_collision_objects:
            objs += self.boxes(aco.object, attached_to=aco.link_name)
        for o in objs:
            if o['id'] in colours:
                o['colour'] = colours[o['id']]
        with self.lock:
            self.scene = {'objects': objs, 'stamp': self.get_clock().now().nanoseconds * 1e-9, 'ok': True}


NODE = None


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **k):
        super().__init__(*a, directory=HERE, **k)

    def end_headers(self):                               # never let the browser keep an old copy of the GUI files
        if not getattr(self, '_nocache', False):
            self.send_header('Cache-Control', 'no-store, must-revalidate')
        super().end_headers()

    def log_message(self, fmt, *args):                   # quiet: the mesh downloads would flood the window
        pass

    def send_bytes(self, data, ctype, code=200):
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self._nocache = True
        self.end_headers()
        self._nocache = False
        self.wfile.write(data)

    def do_GET(self):
        path = self.path.split('?')[0]
        if path == '/robot.urdf':
            with NODE.lock:
                urdf = NODE.urdf
            if urdf is None:
                return self.send_bytes(b'robot model not received yet (is the simulation or start_real.sh running?)',
                                       'text/plain', 503)
            return self.send_bytes(urdf.encode(), 'application/xml')
        if path == '/scene.json':
            with NODE.lock:
                data = json.dumps(NODE.scene)
            return self.send_bytes(data.encode(), 'application/json')
        if path.startswith('/pkg/'):
            parts = path[len('/pkg/'):].split('/', 1)
            if len(parts) != 2:
                return self.send_bytes(b'bad path', 'text/plain', 400)
            try:
                share = get_package_share_directory(parts[0])
            except PackageNotFoundError:
                return self.send_bytes(b'no such package', 'text/plain', 404)
            # normpath, not realpath: with colcon --symlink-install the files are symlinks into src/, which is fine;
            # only '..' tricks that leave the package folder are refused
            full = os.path.normpath(os.path.join(share, parts[1]))
            if not full.startswith(os.path.normpath(share) + os.sep) or not os.path.isfile(full):
                NODE.get_logger().warning(f'mesh not found: {path} -> {full}')
                return self.send_bytes(b'not found', 'text/plain', 404)
            with open(full, 'rb') as f:
                return self.send_bytes(f.read(), mimetypes.guess_type(full)[0] or 'application/octet-stream')
        return super().do_GET()


def main():
    global NODE
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--port', type=int, default=8000)
    args = ap.parse_args()
    mimetypes.add_type('application/javascript', '.js')
    mimetypes.add_type('model/stl', '.stl')
    rclpy.init()
    NODE = SceneNode()
    threading.Thread(target=rclpy.spin, args=(NODE,), daemon=True).start()
    server = ThreadingHTTPServer(('0.0.0.0', args.port), Handler)
    print(f'Twin GUI on http://localhost:{args.port}  (rosbridge must be running on port 9090). Ctrl+C to stop.')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()
    NODE.destroy_node()
    if rclpy.ok():
        rclpy.shutdown()


if __name__ == '__main__':
    main()
