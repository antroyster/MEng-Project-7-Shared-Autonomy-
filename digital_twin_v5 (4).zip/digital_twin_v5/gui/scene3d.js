// 3D view of the twin: the xArm from its URDF, the planning-scene objects, and the fingertip marker.
// ROS uses z-up metres; three.js uses y-up. Everything ROS-side lives in `ros`, a group turned -90 deg about x.
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import URDFLoader from 'urdf-loader';

const COLOURS = {
  table: 0x2b3440, base_plate: 0x8a96a6, power_box: 0x3a3f46, fence: 0xf85149,
  block: 0xf0883e, held: 0x3fb950, unseen: 0x8b98a8, other: 0x6e7781,
};

export class TwinScene {
  constructor(container, onStatus) {
    this.container = container;
    this.onStatus = onStatus || (() => {});
    this.objects = new Map();          // scene object id -> mesh
    this.robot = null;
    this.pendingJoints = null;

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0d1117);
    this.scene.fog = new THREE.Fog(0x0d1117, 4, 9);

    this.camera = new THREE.PerspectiveCamera(45, 1, 0.01, 50);
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.resetView();

    // lights
    this.scene.add(new THREE.HemisphereLight(0xdde8ff, 0x1a1f26, 0.9));
    const sun = new THREE.DirectionalLight(0xffffff, 1.6);
    sun.position.set(1.5, 3, 2);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    Object.assign(sun.shadow.camera, { left: -1.5, right: 1.5, top: 1.5, bottom: -1.5, near: 0.5, far: 8 });
    this.scene.add(sun);

    // floor grid far below the table, for depth
    const grid = new THREE.GridHelper(8, 32, 0x223040, 0x161d26);
    grid.position.y = -0.808;
    this.scene.add(grid);

    // everything in ROS coordinates goes in here
    this.ros = new THREE.Group();
    this.ros.rotation.x = -Math.PI / 2;
    this.scene.add(this.ros);

    // fingertip marker: a glowing dot and a dashed drop line to the table
    this.tip = new THREE.Mesh(new THREE.SphereGeometry(0.008, 24, 16),
      new THREE.MeshBasicMaterial({ color: 0x3ea6ff }));
    this.tip.visible = false;
    this.ros.add(this.tip);
    const lineGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
    this.drop = new THREE.Line(lineGeo, new THREE.LineDashedMaterial({ color: 0x3ea6ff, dashSize: 0.01, gapSize: 0.008 }));
    this.drop.visible = false;
    this.ros.add(this.drop);
    this.ring = new THREE.Mesh(new THREE.RingGeometry(0.012, 0.016, 32),
      new THREE.MeshBasicMaterial({ color: 0x3ea6ff, transparent: true, opacity: 0.8, side: THREE.DoubleSide }));
    this.ring.visible = false;
    this.ros.add(this.ring);
    this.tableTop = -0.008;

    window.addEventListener('resize', () => this.resize());
    this.resize();
    this.renderer.setAnimationLoop(() => { this.controls.update(); this.renderer.render(this.scene, this.camera); });
  }

  resetView() {
    // look at the work area from the front-right, a little above (three.js coordinates: x fwd, y up, z = -left)
    this.camera.position.set(1.25, 0.75, 0.95);
    this.controls.target.set(0.35, 0.05, 0);
    this.controls.update();
  }

  resize() {
    const w = this.container.clientWidth, h = this.container.clientHeight;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / Math.max(h, 1);
    this.camera.updateProjectionMatrix();
  }

  async loadRobot(url) {
    this.onStatus('loading robot model…');
    const text = await (await fetch(url, { cache: 'no-store' })).text();
    if (!text.trim().startsWith('<')) throw new Error(text);
    const manager = new THREE.LoadingManager();
    const loader = new URDFLoader(manager);
    loader.packages = (pkg) => `${location.origin}/pkg/${pkg}`;
    const robot = loader.parse(text);
    manager.onLoad = () => {
      this.meshesLoaded = true;
      const metal = new THREE.MeshStandardMaterial({ color: 0xd7dde5, metalness: 0.35, roughness: 0.45 });
      const dark = new THREE.MeshStandardMaterial({ color: 0x30363d, metalness: 0.2, roughness: 0.6 });
      robot.traverse(o => {
        if (o.isMesh) {
          const n = (o.parent && o.parent.name || '').toLowerCase() + (o.name || '').toLowerCase();
          o.material = /finger|knuckle|gripper/.test(n) ? dark : metal;
          o.castShadow = true;
          o.receiveShadow = true;
        }
      });
      this.onStatus('');
    };
    this.robot = robot;
    this.ros.add(robot);
    if (this.pendingJoints) this.setJoints(...this.pendingJoints);
    return robot;
  }

  setJoints(names, positions) {
    if (!this.robot) { this.pendingJoints = [names, positions]; return; }
    for (let i = 0; i < names.length; i++) {
      const j = this.robot.joints[names[i]];
      if (j) j.setJointValue(positions[i]);
    }
  }

  setFingertip(p) {
    const show = Array.isArray(p);
    this.tip.visible = this.drop.visible = this.ring.visible = show;
    if (!show) return;
    this.tip.position.set(p[0], p[1], p[2]);
    const pos = this.drop.geometry.attributes.position;
    pos.setXYZ(0, p[0], p[1], p[2]);
    pos.setXYZ(1, p[0], p[1], this.tableTop + 0.0005);
    pos.needsUpdate = true;
    this.drop.computeLineDistances();
    this.ring.position.set(p[0], p[1], this.tableTop + 0.0008);
  }

  colourFor(o) {
    if (o.held) return { c: COLOURS.held, a: 0.95 };
    const id = o.id;
    if (id === 'table') return { c: COLOURS.table, a: 1 };
    if (id.startsWith('fence')) return { c: COLOURS.fence, a: 0.16 };
    if (id === 'base_plate') return { c: COLOURS.base_plate, a: 1 };
    if (id === 'power_box') return { c: COLOURS.power_box, a: 1 };
    if (o.colour && o.colour[0] < 0.7 && Math.abs(o.colour[0] - o.colour[1]) < 0.05) return { c: COLOURS.unseen, a: 0.5 };
    if (id.startsWith('wp3') || id.includes('block')) return { c: COLOURS.block, a: 0.95 };
    return { c: COLOURS.other, a: 1 };
  }

  setObjects(list) {
    const seen = new Set();
    for (const o of list) {
      const key = o.id + (o.held ? '#held' : '');
      seen.add(key);
      let m = this.objects.get(key);
      const { c, a } = this.colourFor(o);
      if (!m) {
        m = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1),
          new THREE.MeshStandardMaterial({ roughness: 0.7, metalness: 0.05, transparent: a < 1 }));
        m.castShadow = !o.id.startsWith('fence');
        m.receiveShadow = true;
        if (o.id === 'table') {
          const edges = new THREE.LineSegments(new THREE.EdgesGeometry(m.geometry),
            new THREE.LineBasicMaterial({ color: 0x3ea6ff, transparent: true, opacity: 0.25 }));
          m.add(edges);
        }
        this.ros.add(m);
        this.objects.set(key, m);
      }
      m.material.color.setHex(c);
      m.material.opacity = a;
      m.material.transparent = a < 1;
      m.material.depthWrite = a >= 0.5;
      m.scale.set(o.size[0], o.size[1], o.size[2]);
      m.position.set(o.pos[0], o.pos[1], o.pos[2]);
      m.quaternion.set(o.quat[0], o.quat[1], o.quat[2], o.quat[3]);
      if (o.id === 'table') this.tableTop = o.pos[2] + o.size[2] / 2;
    }
    for (const [key, m] of this.objects) {
      if (!seen.has(key)) { this.ros.remove(m); m.geometry.dispose(); m.material.dispose(); this.objects.delete(key); }
    }
  }
}
