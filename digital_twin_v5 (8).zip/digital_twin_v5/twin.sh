#!/usr/bin/env bash
# ONE command for the whole digital twin, with the GUI as the only window (no RViz):
#
#   bash twin.sh                 simulation, 3 mock blocks, top speed 50 mm/s
#   bash twin.sh --speed 0.08    a different top speed (m/s, at most 0.15)
#   bash twin.sh --no-mock       simulation without the mock blocks
#   bash twin.sh --wp3           blocks from the live WP3 perception node instead of the mock
#   bash twin.sh --real          the REAL arm (asks YES first; top speed 30 mm/s unless --speed is given)
#   bash twin.sh --rviz          also show RViz (for debugging)
#   bash twin.sh --live          EVERYTHING on the lab PC: real arm + the 3 cameras + WP3 live perception + twin
#                                (add --wood for the 45 mm wooden props instead of the printed Jenga blocks)
#                                Calibration is built in: if there is none (or with --calibrate) a guided wizard runs first
#
# It starts, in order: the arm (simulated or real) with MoveIt, the scene, the Etee bridge, the hold node,
# perception, rosbridge and the GUI server, then opens http://localhost:8000 in Windows.
# Every part writes a log in ~/twin_logs/. Ctrl+C stops everything.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROS="$HERE/ros"
LOGS=~/twin_logs
REAL=0; SPEED=""; MOCK=1; WP3=0; RVIZ=0; LIVE=0; BLOCKS=printed; CALIBRATE=0
while [ $# -gt 0 ]; do
  case "$1" in
    --real) REAL=1 ;;
    --speed) SPEED="$2"; shift ;;
    --no-mock) MOCK=0 ;;
    --wp3) WP3=1; MOCK=0 ;;
    --rviz) RVIZ=1 ;;
    --live) LIVE=1; REAL=1; WP3=1; MOCK=0 ;;
    --wood) BLOCKS=wood ;;
    --calibrate) CALIBRATE=1; LIVE=1; REAL=1; WP3=1; MOCK=0 ;;
    -h|--help) sed -n '2,16p' "$0"; exit 0 ;;
    *) echo "unknown option $1 (try --help)"; exit 1 ;;
  esac
  shift
done
[ -z "$SPEED" ] && { [ $REAL = 1 ] && SPEED=0.03 || SPEED=0.05; }

source /opt/ros/jazzy/setup.bash
source ~/xarm_ws/install/setup.bash
export ROS_DOMAIN_ID=67 ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
mkdir -p "$LOGS"
say() { printf '\033[1;36m[twin]\033[0m %s\n' "$*"; }
die() { printf '\033[1;31m[twin] %s\033[0m\n' "$*"; exit 1; }

# ---------------------------------------------------------------- checks
NEED_CAL=0
if [ $LIVE = 1 ]; then
  # WP3's folder (Shadi's code), his board reference, the latest Step A camera calibration, our Step B table calibration
  WP3_DIR="${WP3_DIR:-$(find ~ -maxdepth 4 -type d -name 'WP3-Live-Implementation-v2-Three-View' 2>/dev/null | head -1)}"
  [ -n "$WP3_DIR" ] && [ -f "$WP3_DIR/scripts/launch_live.sh" ] || die "WP3 code not found. Run with WP3_DIR=/path/to/WP3-Live-Implementation-v2-Three-View bash twin.sh --live"
  REF="$WP3_DIR/../calibration/2026-11-19_board_orientation_reference.json"
  [ -f "$REF" ] || REF="$(find ~ -maxdepth 5 -name '*board_orientation_reference.json' 2>/dev/null | head -1)"
  CAL="${CAL:-$(ls -td ~/wp3_board_*/ 2>/dev/null | while read -r d; do [ -f "$d/current_board_tf.json" ] && { echo "${d%/}"; break; }; done)}"
  TF_YAML=""
  for f in ~/twin_calibration/wp3_table_tf.yaml "$ROS/wp3_table_tf.yaml"; do [ -f "$f" ] && { TF_YAML="$f"; break; }; done
  if [ $CALIBRATE = 1 ] || [ -z "$CAL" ] || [ -z "$TF_YAML" ]; then
    NEED_CAL=1
  else
    say "found a calibration: cameras $(basename "$CAL"), table $(date -r "$TF_YAML" '+%d %b %H:%M')"
    echo "  Use it? Only if the checkerboard position, the cameras and the table have NOT moved since."
    read -r -p "  Enter = use it,  r = calibrate again: " ans
    [ "$ans" = "r" ] && NEED_CAL=1
  fi
  if [ $NEED_CAL = 1 ]; then
    [ -f "$REF" ] || die "Board orientation reference (2026-11-19_board_orientation_reference.json) not found: it comes with WP3's handoff folder."
    say "calibration will run first (guided: follow the prompts in the app and here)"
  fi
  CONFIG="$WP3_DIR/ros2_ws/src/wp3_live_perception/config/$([ $BLOCKS = wood ] && echo historical_props_19nov_board.json || echo printed_jenga_live.json)"
  # same DDS settings as WP3 (shared memory + UDP), so every node sees every other
  export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
  export FASTRTPS_DEFAULT_PROFILES_FILE="$WP3_DIR/ros2_ws/src/wp3_live_perception/config/fastdds_shm_profile.xml"
  export WP3_DIR
  say "live perception: WP3 code $WP3_DIR, blocks: $BLOCKS"
fi
# A previous session left running (closed window, crash) is stopped automatically.
if ros2 node list 2>/dev/null | grep -q move_group || ss -ltn 2>/dev/null | grep -qE ":(8000|9090|5005) "; then
  say "Stopping a previous twin session that is still running ..."
  pkill -f "etee_hold.py|etee_bridge.py|twin_gui_server.py|rosbridge|mock_wp3_publisher.py|wp3_scene_bridge.py|wp3_table_tf.py|realsense2_camera|wp3_live|publish_board_tf.py" 2>/dev/null
  pkill -f "move_group|ros2_control_node|robot_state_publisher|xarm_driver|rviz2|ros2 launch" 2>/dev/null
  fuser -k 8000/tcp 9090/tcp 5005/tcp >/dev/null 2>&1
  for i in $(seq 1 20); do
    ss -ltn 2>/dev/null | grep -qE ":(8000|9090|5005) " || break
    sleep 0.5
  done
  ros2 daemon stop >/dev/null 2>&1
  ss -ltn 2>/dev/null | grep -qE ":(8000|9090|5005) " && die "Could not free ports 8000/9090/5005. Close the other Ubuntu windows and try again."
  say "Old session stopped."
fi
ros2 pkg prefix rosbridge_server >/dev/null 2>&1 || die "rosbridge is missing: sudo apt install -y ros-jazzy-rosbridge-suite"
if [ $REAL = 1 ]; then
  ping -c 1 -W 2 192.168.1.214 >/dev/null 2>&1 || die "Cannot reach the arm at 192.168.1.214 (cable, power, laptop IP 192.168.1.10)."
  echo "REAL ARM at up to $(python3 -c "print(round($SPEED*1000))") mm/s. Supervisor present, E-stop in reach, workspace clear?"
  read -r -p "Type YES to start: " ok; [ "$ok" = "YES" ] || exit 0
fi

# everything started below belongs to this script's process group: Ctrl+C stops all of it
trap 'trap - EXIT INT TERM; say "stopping everything ..."; kill 0 2>/dev/null; wait 2>/dev/null; say "stopped"' EXIT INT TERM

# ---------------------------------------------------------------- 0. cameras (live only): they start while the arm starts
if [ $LIVE = 1 ]; then
  for cam in wrist tripod third; do
    say "camera: $cam"
    (cd "$WP3_DIR" && exec bash scripts/start_camera.sh $cam) > "$LOGS/camera_$cam.log" 2>&1 &
  done
fi

# ---------------------------------------------------------------- 1. arm + MoveIt, RViz hidden
if [ $REAL = 1 ]; then
  LAUNCH=(xarm_moveit_config xarm6_moveit_realmove.launch.py robot_ip:=192.168.1.214 add_gripper:=true)
else
  LAUNCH=(xarm_moveit_config xarm6_moveit_fake.launch.py add_gripper:=true)
fi
RVIZ_ARG=""
if [ $RVIZ = 0 ]; then
  # the xArm launch files read "show_rviz" inside an included file, so it is not in --show-args: look for it there
  SHARE=$(ros2 pkg prefix xarm_moveit_config 2>/dev/null)/share/xarm_moveit_config/launch
  if grep -rqs "show_rviz" "$SHARE"; then
    RVIZ_ARG="show_rviz:=false"
  else
    say "this xArm version has no switch to hide RViz: it will open, just minimise it"
  fi
fi
say "starting the $([ $REAL = 1 ] && echo REAL || echo simulated) arm and MoveIt ${RVIZ_ARG:+($RVIZ_ARG)}"
ros2 launch "${LAUNCH[@]}" $RVIZ_ARG > "$LOGS/arm.log" 2>&1 &
ARM_PID=$!
ready=0
for i in $(seq 1 90); do
  kill -0 $ARM_PID 2>/dev/null || die "the arm launch stopped: see $LOGS/arm.log"
  ros2 service list 2>/dev/null | grep -q "^/get_planning_scene$" && ros2 topic list 2>/dev/null | grep -q "^/joint_states$" && { ready=1; break; }
  sleep 1
done
[ $ready = 1 ] || die "MoveIt did not come up in 90 s: see $LOGS/arm.log"
sleep 4
cd "$ROS"
if [ $REAL = 0 ]; then
  say "moving the simulated arm to the real home pose"
  echo YES | timeout 60 python3 go_home.py > "$LOGS/go_home.log" 2>&1 || die "moving home failed or took over 60 s: see $LOGS/go_home.log and $LOGS/arm.log"
fi
say "building the scene (table, base plate, fence, power box)"
kill -0 $ARM_PID 2>/dev/null || die "the arm launch stopped: see $LOGS/arm.log"
timeout 60 python3 build_scene.py > "$LOGS/scene.log" 2>&1 || die "build_scene failed: see $LOGS/scene.log"

# ---------------------------------------------------------------- 2. inputs, hold node, perception
say "Etee bridge (port 5005) for the Windows reader"
python3 etee_bridge.py > "$LOGS/etee_bridge.log" 2>&1 &
say "hold node, top speed $(python3 -c "print(round($SPEED*1000))") mm/s"
HOLD_ARGS="--speed $SPEED $([ $REAL = 0 ] && echo --sim) $([ $NEED_CAL = 1 ] && echo --clearance-mm 0)"
echo YES | python3 etee_hold.py $HOLD_ARGS > "$LOGS/etee_hold.log" 2>&1 &
HOLD_PID=$!
if [ $MOCK = 1 ]; then
  say "perception: 3 MOCK blocks"
  bash start_perception.sh > "$LOGS/perception.log" 2>&1 &
elif [ $WP3 = 1 ] && [ $LIVE = 0 ]; then
  say "perception: live WP3 blocks into the twin (WP3 node started separately)"
  bash start_perception.sh --live > "$LOGS/perception.log" 2>&1 &
fi

# ---------------------------------------------------------------- 3. GUI
say "rosbridge (port 9090) and the GUI server (port 8000)"
ros2 launch rosbridge_server rosbridge_websocket_launch.xml > "$LOGS/rosbridge.log" 2>&1 &
cd "$HERE/gui"
python3 twin_gui_server.py > "$LOGS/gui.log" 2>&1 &
for i in $(seq 1 20); do curl -s -o /dev/null http://localhost:8000/ && break; sleep 0.5; done
sleep 2
kill -0 $HOLD_PID 2>/dev/null || die "the hold node stopped: see $LOGS/etee_hold.log"
say "ready: http://localhost:8000"
if command -v cmd.exe >/dev/null 2>&1; then cmd.exe /c start http://localhost:8000 >/dev/null 2>&1
elif command -v xdg-open >/dev/null 2>&1; then xdg-open http://localhost:8000 >/dev/null 2>&1 & fi
if [ $LIVE = 1 ]; then
  for cam in wrist tripod third; do
    for i in $(seq 1 30); do ros2 topic list 2>/dev/null | grep -q "/perception/$cam/" && break; sleep 1; done
    ros2 topic list 2>/dev/null | grep -q "/perception/$cam/" || die "camera $cam did not start: see $LOGS/camera_$cam.log (USB cable?)"
  done
  say "all three cameras running"
  if [ $NEED_CAL = 1 ]; then
    say "CALIBRATION: follow the prompts (they also appear in the app). Ctrl+C aborts."
    (cd "$ROS" && python3 calib_wizard.py --wp3 "$WP3_DIR" --ref "$REF") || die "calibration not finished"
    CAL="$(cat ~/twin_calibration/last_camera_cal.txt)"
    TF_YAML=~/twin_calibration/wp3_table_tf.yaml
    say "restarting the hold node with the normal table clearance"
    kill $HOLD_PID 2>/dev/null; sleep 1
    cd "$ROS"
    echo YES | python3 etee_hold.py --speed "$SPEED" >> "$LOGS/etee_hold.log" 2>&1 &
    HOLD_PID=$!
  fi
  export TABLE_TF_FILE="$TF_YAML"
  say "camera positions (Step A): $CAL"
  (cd "$WP3_DIR" && source scripts/lab_env.sh && exec python3 scripts/publish_board_tf.py "$CAL/current_board_tf.json") > "$LOGS/board_tf.log" 2>&1 &
  say "table position (Step B): $TF_YAML"
  say "WP3 live perception ($BLOCKS blocks, 3 cameras)"
  (cd "$WP3_DIR" && exec bash scripts/launch_live.sh --policy whole_partition_mv --config "$CONFIG" \
      --third-ns /perception/third --save-dir "$CAL/live_$(date +%Y%m%d_%H%M%S)") > "$LOGS/wp3_live.log" 2>&1 &
  (cd "$ROS" && exec bash start_perception.sh --live) > "$LOGS/perception.log" 2>&1 &
  for i in $(seq 1 60); do ros2 topic list 2>/dev/null | grep -q /wp3_live/markers && break; sleep 1; done
  if ros2 topic list 2>/dev/null | grep -q /wp3_live/markers; then say "perception live: blocks are coming in"
  else say "WARNING: no /wp3_live/markers after 60 s: see $LOGS/wp3_live.log"; fi
fi
say "logs: $LOGS   (live hold-node output: tail -f $LOGS/etee_hold.log)"
say "Ctrl+C here stops everything."
while kill -0 $ARM_PID 2>/dev/null; do sleep 2; done
die "the arm launch stopped: see $LOGS/arm.log"
