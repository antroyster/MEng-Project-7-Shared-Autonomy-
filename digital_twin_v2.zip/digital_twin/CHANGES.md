# Changes in this version

- `ros/etee_hold.py`: the gripper now opens and closes through the xArm gripper action
  (`/xarm_gripper/gripper_action`, GripperCommand). Going through MoveIt failed with error -26 (start state invalid)
  on the real arm. MoveIt is still the fallback if the action is missing.
- `ros/build_scene.py`: base plate thickness 8 mm (measured), so the table top is at z = -0.008 in the scene.
- `ros/wp3_*.py`, `fit_table_tf.py`, `start_wp3.sh`, `test_wp3_offline.py`, `add_camera.py`: WP3 perception link,
  written by Shadi (WP3). See WP3_HANDOFF.md.
- Keyboard hold-to-move (`keyboard/`) and Etee trackpad hold-to-move (`etee/`) are unchanged and tested on the real arm.
- Etee tilt steering (`--tilt` in `etee/etee_reader_windows.py`) is experimental and not validated.
