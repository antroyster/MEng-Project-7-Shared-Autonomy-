# Etee trackpad control

| Input | Action |
|---|---|
| Left pad up / down | forward / back |
| Left pad left / right | left / right |
| Right pad up / down | up / down |
| Right squeeze / left squeeze | close / open gripper |

No enable button: the arm moves only while a thumb touches a pad. An untouched pad reads 0.

## One-time setup (Windows)
```powershell
git clone https://github.com/eteeXR/etee-Python-API
cd etee-Python-API
python -m pip install -r requirements.txt        # run scripts from this folder; do not pip install the package
copy <repo>\digital_twin\etee\etee_reader_windows.py .
copy <repo>\digital_twin\etee\etee_imu_probe.py .
```
Controllers connect over USB (the library finds the COM port); check Device Manager > Ports if not.

## Steps
1. **Ubuntu**: `bash start_sim.sh` (window 1), `bash start_bridge.sh` (window 2), then window 3:
   `source /opt/ros/jazzy/setup.bash; source ~/xarm_ws/install/setup.bash; python3 etee_check.py`.
2. **PowerShell** in `etee-Python-API`: `python etee_reader_windows.py` (keyboard reader must be off).
   `--print` shows the raw readings; `--flip-y` / `--swap-grips` fix reversed pads / hands.
3. In `etee_check.py` check: left pad up prints FORWARD, right pad up prints UP, a resting thumb prints `nothing`. Ctrl+C.
4. Window 3: `python3 etee_hold.py`, type `YES`, release both pads until `armed`, then push.
   Feel: `--deadzone 0.45` / `--curve 2.0` for less sensitive, `--deadzone 0.2 --curve 1.2` for more.

`etee_imu_probe.py` prints the controllers' tilt sensor values (used to explore tilt steering, `--tilt`, experimental).
