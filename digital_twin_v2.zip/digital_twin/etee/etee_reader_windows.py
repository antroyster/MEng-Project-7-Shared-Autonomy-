#!/usr/bin/env python3
"""Runs on WINDOWS (needs only the etee-api package, no ROS). Reads BOTH Etee controllers and streams them to
etee_bridge.py running in WSL over a local TCP connection.

  python etee_reader_windows.py             stream both controllers to WSL
  python etee_reader_windows.py --print     just print the readings (no WSL), to check directions
  python etee_reader_windows.py --flip-y    if pushing a pad up makes its y negative

Mapping to the robot (edit read_etee() below to change it):
  LEFT  trackpad  x : left / right      y : forward / back
  RIGHT trackpad  y : up / down
  RIGHT squeeze     closes the gripper
  LEFT  squeeze     opens the gripper
There is no enable button: the arm only moves while a thumb is touching a pad (an untouched pad reads 0).
"""
import argparse
import json
import math
import socket
import sys
import time

from etee import EteeController

CENTRE = 126.0           # raw pad value when not touched


class Tilt:
    """Steer by tilting one controller. Active only while the enable finger is clicked; tilt is measured from
    where you were holding it at that moment, so it does not matter how you hold it.
    Uses the accelerometer (the direction of gravity). It does not drift or wrap around like the Euler angles."""
    def __init__(self, hand, enable, rng, swap, flip_x, flip_y):
        self.hand, self.enable, self.rng = hand, enable, rng
        self.swap, self.fx, self.fy = swap, -1.0 if flip_x else 1.0, -1.0 if flip_y else 1.0
        self.ref = None
        self.smooth = None
        self.active = False
        self.last = (0.0, 0.0)
        self.deg = (0.0, 0.0)

    @staticmethod
    def wrap(a):
        return (a + math.pi) % (2 * math.pi) - math.pi

    @staticmethod
    def angles(v):
        """(roll, pitch) in radians from a gravity vector: roll from the x axis, pitch around it (y-z plane)."""
        n = math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2)
        if n < 1.0:
            return None
        return math.asin(max(-1.0, min(1.0, v[0] / n))), math.atan2(v[1], v[2])

    def read(self, etee):
        """(x, y) in -1..1 like a pad, or None when tilt is not enabled right now."""
        try:
            on = bool(getattr(etee, f'get_{self.enable}_clicked')(self.hand))
            acc = etee.get_accel(self.hand)
        except Exception:
            on, acc = False, None
        if not on or acc is None or len(acc) < 3:
            self.ref, self.smooth, self.active = None, None, False
            self.last = (0.0, 0.0)
            return None
        v = [float(acc[0]), float(acc[1]), float(acc[2])]
        self.smooth = v if self.smooth is None else [0.7 * s + 0.3 * c for s, c in zip(self.smooth, v)]
        ang = self.angles(self.smooth)
        if ang is None:
            return (0.0, 0.0)
        if self.ref is None:                       # press: this is the neutral position
            self.ref = ang
        self.active = True
        roll = self.wrap(ang[0] - self.ref[0])
        pitch = self.wrap(ang[1] - self.ref[1])
        self.deg = (math.degrees(roll), math.degrees(pitch))
        if self.swap:
            roll, pitch = pitch, roll
        clip = lambda x: max(-1.0, min(1.0, x / self.rng))
        self.last = (clip(roll) * self.fx, clip(pitch) * self.fy)    # x = left/right, y = forward/back
        return self.last


class Reader:
    def __init__(self, swap_grips, flip_y, tilt=None):
        self.swap_grips = swap_grips
        self.flip_y = flip_y
        self.tilt = tilt
        self.etee = EteeController()
        self.etee.connect()
        self.etee.start_data()
        self.etee.run()

    @staticmethod
    def norm(raw):
        if raw is None:
            return 0.0
        return max(-1.0, min(1.0, (raw - CENTRE) / CENTRE))

    def has_data(self, hand):
        """The API returns None until the first data packet arrives from that controller."""
        return self.etee.get_trackpad_x(hand) is not None

    def pad(self, hand):
        """(x, y, touched) for one trackpad. An untouched pad or a missing controller reads (0, 0, False)."""
        e = self.etee
        if not self.has_data(hand) or not e.get_trackpad_touched(hand):
            return 0.0, 0.0, False
        x = self.norm(e.get_trackpad_x(hand))
        y = self.norm(e.get_trackpad_y(hand))
        return x, (-y if self.flip_y else y), True

    def read_etee(self):
        """Returns a dict: lx, ly (left pad), rx, ry (right pad), lt, rt (touched), close, open."""
        lx, ly, lt = self.pad('left')
        rx, ry, rt = self.pad('right')
        if self.tilt is not None:
            t = self.tilt.read(self.etee)
            if t is not None and not lt:           # the left pad wins if a thumb is on it
                lx, ly, lt = t[0], t[1], True      # tilt takes the place of the left pad (x: left/right, y: fwd/back)
        close_hand, open_hand = ('left', 'right') if self.swap_grips else ('right', 'left')
        close = bool(self.has_data(close_hand) and self.etee.get_grip_clicked(close_hand))
        opn = bool(self.has_data(open_hand) and self.etee.get_grip_clicked(open_hand))
        return {'lx': lx, 'ly': ly, 'rx': rx, 'ry': ry, 'lt': lt, 'rt': rt, 'close': close, 'open': opn}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--swap-grips', action='store_true', help='left squeeze closes, right squeeze opens')
    ap.add_argument('--host', default='127.0.0.1', help='WSL is reachable on localhost')
    ap.add_argument('--port', type=int, default=5005)
    ap.add_argument('--rate', type=float, default=30.0)
    ap.add_argument('--flip-y', action='store_true')
    ap.add_argument('--print', dest='print_only', action='store_true')
    ap.add_argument('--tilt', action='store_true', help='also steer by tilting a controller (hold the enable finger)')
    ap.add_argument('--tilt-hand', default='right', choices=['left', 'right'], help='which controller is tilted (both report tilt)')
    ap.add_argument('--tilt-enable', default='index', choices=['index', 'middle', 'ring', 'pinky', 'thumb'], help='finger that must be clicked for tilt to count')
    ap.add_argument('--tilt-range', type=float, default=0.5, help='tilt in radians that counts as full push (0.5 = about 29 degrees)')
    ap.add_argument('--tilt-swap', action='store_true', help='swap which tilt is forward/back and which is left/right')
    ap.add_argument('--tilt-flip-x', action='store_true', help='reverse left/right tilt')
    ap.add_argument('--tilt-flip-y', action='store_true', help='reverse forward/back tilt')
    args = ap.parse_args()

    tilt = Tilt(args.tilt_hand, args.tilt_enable, args.tilt_range, args.tilt_swap, args.tilt_flip_x,
                args.tilt_flip_y) if args.tilt else None
    r = Reader(args.swap_grips, args.flip_y, tilt)
    period = 1.0 / args.rate
    sock = None
    print('Reading both controllers. Ctrl+C to stop.')
    t0 = time.time()
    while not (r.has_data('left') or r.has_data('right')):
        if time.time() - t0 > 10:
            print('No data from either controller after 10 s. Check they are switched on and paired '
                  '(dongle blinks pink-pink-blue).')
            break
        print('Waiting for the controllers ...', end='\r')
        time.sleep(0.2)
    for hand in ('left', 'right'):
        if not r.has_data(hand):
            print(f'Note: no data from the {hand} controller yet.')
    try:
        while True:
            d = r.read_etee()
            if args.print_only:
                print(f"LEFT x {d['lx']:+.2f} y {d['ly']:+.2f} touch {int(d['lt'])} | RIGHT y {d['ry']:+.2f} "
                      f"touch {int(d['rt'])} | close {int(d['close'])} open {int(d['open'])}"
                      + (f" | TILT {'ON ' if tilt.active else 'off'} x {tilt.last[0]:+.2f} y {tilt.last[1]:+.2f} ({tilt.deg[0]:+.0f} / {tilt.deg[1]:+.0f} deg)" if tilt else '')
                      + '   ', end='\r')
            else:
                if sock is None:
                    try:
                        sock = socket.create_connection((args.host, args.port), timeout=2)
                        print('Connected to the WSL bridge.')
                    except OSError:
                        print('Waiting for etee_bridge.py in WSL ...', end='\r')
                        time.sleep(1.0)
                        continue
                d['t'] = time.time()
                try:
                    sock.sendall((json.dumps(d) + '\n').encode())
                except OSError:
                    sock = None
                    print('Lost the bridge, reconnecting ...')
            time.sleep(period)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            r.etee.stop_data()
            r.etee.stop()
            r.etee.disconnect()
        except Exception as ex:
            print('cleanup:', ex, file=sys.stderr)


if __name__ == '__main__':
    main()
