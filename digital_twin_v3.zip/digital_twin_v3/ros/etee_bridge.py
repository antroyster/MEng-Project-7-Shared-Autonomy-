#!/usr/bin/env python3
"""Runs in WSL (ROS 2). Receives the Etee readings from etee_reader_windows.py over TCP and publishes them as
sensor_msgs/Joy on /etee/joy for etee_teleop.py.

  python3 etee_bridge.py            listens on port 5005

If the Windows reader stops or the connection drops, it publishes an all-zero message so the arm stops.
"""
import argparse
import json
import socket
import threading
import time

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Joy


class Bridge(Node):
    def __init__(self):
        super().__init__('etee_bridge')
        self.pub = self.create_publisher(Joy, '/etee/joy', 10)
        self.last = None
        self.last_rx = 0.0
        self.create_timer(1.0 / 30.0, self.tick)

    def on_message(self, d):
        self.last = d
        self.last_rx = time.monotonic()

    def publish(self, lx=0.0, ly=0.0, rx=0.0, ry=0.0, lt=0, rt=0, close=0, opn=0):
        # axes: left pad x, left pad y, right pad x, right pad y   buttons: left touched, right touched, close, open
        m = Joy()
        m.header.stamp = self.get_clock().now().to_msg()
        m.axes = [float(lx), float(ly), float(rx), float(ry)]
        m.buttons = [int(lt), int(rt), int(close), int(opn)]
        self.pub.publish(m)

    def tick(self):
        if self.last is None or time.monotonic() - self.last_rx > 0.5:
            self.publish()                          # no fresh data: all zero, the arm stops
            return
        d = self.last
        self.publish(d['lx'], d['ly'], d['rx'], d['ry'], d['lt'], d['rt'], d['close'], d['open'])


def serve(node, port):
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(('0.0.0.0', port))
    srv.listen(1)
    node.get_logger().info(f'Waiting for the Windows reader on port {port} ...')
    while rclpy.ok():
        conn, addr = srv.accept()
        node.get_logger().info(f'Etee reader connected from {addr[0]}')
        buf = b''
        try:
            while rclpy.ok():
                data = conn.recv(4096)
                if not data:
                    break
                buf += data
                while b'\n' in buf:
                    line, buf = buf.split(b'\n', 1)
                    try:
                        node.on_message(json.loads(line))
                    except (ValueError, KeyError):
                        pass
        except OSError:
            pass
        node.last = None
        node.get_logger().warn('Etee reader disconnected, arm commands stopped.')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--port', type=int, default=5005)
    args = ap.parse_args()
    rclpy.init()
    node = Bridge()
    threading.Thread(target=serve, args=(node, args.port), daemon=True).start()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
