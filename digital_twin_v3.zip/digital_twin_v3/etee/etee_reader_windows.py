#!/usr/bin/env python3
"""Runs on WINDOWS (needs only the etee-api package, no ROS). Reads BOTH Etee controllers and streams them to
etee_bridge.py running in WSL over a local TCP connection.

  python etee_reader_windows.py             stream both controllers to WSL
  python etee_reader_windows.py --print     just print the readings (no WSL), to check directions
  python etee_reader_windows.py --flip-y    if pushing a pad up makes its y negative

Mapping to the robot (edit read_etee() below to change it):
  LEFT  trackpad  x : left / right      y : forward / back
  RIGHT trackpad  y : up / down
  RIGHT trackpad PRESS (click down)  closes the gripper
  LEFT  trackpad PRESS (click down)  opens the gripper      (--grip-source squeeze: the old squeeze buttons)
There is no enable button: the arm only moves while a thumb is touching a pad (an untouched pad reads 0).
With --tilt: squeeze the RIGHT controller and tilt it to move forward/back/left/right;
              squeeze the LEFT controller and tilt it forward/back to move UP/DOWN. Release = stop.
"""
import argparse
import json
import math
import socket
import sys
import time

from etee import EteeController

CENTRE = 126.0           # raw pad value when not touched


class Tilt:
    """Steer by tilting one controller. Active only while the enable finger is clicked (squeezing clicks it); tilt is
    measured from where you were holding it at that moment, so it does not matter how you hold it.
    Uses the accelerometer (the direction of gravity), so it does not drift. At the moment of the press it builds two
    horizontal tilt axes from the controller's own axes (u ~ the controller x axis unless gravity runs along it),
    so any grip works. Use the swap / flip options if a direction comes out wrong."""
    def __init__(self, hand, enable, rng, swap, flip_x, flip_y):
        self.hand, self.enable, self.rng = hand, enable, rng
        self.swap, self.fx, self.fy = swap, -1.0 if flip_x else 1.0, -1.0 if flip_y else 1.0
        self.ref = None
        self.smooth = None
        self.active = False
        self.last = (0.0, 0.0)
        self.deg = (0.0, 0.0)

    @staticmethod
    def unit(v):
        n = math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2)
        return None if n < 1.0 else [c / n for c in v]

    @staticmethod
    def dot(a, b):
        return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]

    @staticmethod
    def cross(a, b):
        return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]

    def basis(self, g0):
        """Two horizontal axes (u, v) perpendicular to the neutral gravity direction g0."""
        axes = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]
        if abs(g0[0]) > 0.8:                       # gravity runs along x: use the axis that is most horizontal
            axes = [axes[1], axes[2]] if abs(g0[1]) < abs(g0[2]) else [axes[2], axes[1]]
        e = axes[0]
        d = self.dot(e, g0)
        u = self.unit([(e[i] - d * g0[i]) * 1000.0 for i in range(3)])
        v = self.cross(g0, u)
        return u, v

    def read(self, etee):
        """(x, y) in -1..1 like a pad, or None when tilt is not enabled right now."""
        try:
            on = bool(getattr(etee, f'get_{self.enable}_clicked')(self.hand))
            acc = etee.get_accel(self.hand)
        except Exception:
            on, acc = False, None
        if not on or acc is None or len(acc) < 3:
            self.ref, self.smooth, self.active = None, None, False
            self.last = (0.0, 0.0)
            return None
        v = [float(acc[0]), float(acc[1]), float(acc[2])]
        self.smooth = v if self.smooth is None else [0.7 * s + 0.3 * c for s, c in zip(self.smooth, v)]
        g = self.unit(self.smooth)
        if g is None:
            return (0.0, 0.0)
        if self.ref is None:                       # press: this is the neutral position
            self.ref = (g, *self.basis(g))
        self.active = True
        g0, u, w = self.ref
        sa = max(-1.0, min(1.0, self.dot(g, u)))
        sb = max(-1.0, min(1.0, self.dot(g, w)))
        roll, pitch = math.asin(sa), math.asin(sb)
        self.deg = (math.degrees(roll), math.degrees(pitch))
        if self.swap:
            roll, pitch = pitch, roll
        clip = lambda x: max(-1.0, min(1.0, x / self.rng))
        self.last = (clip(roll) * self.fx, clip(pitch) * self.fy)    # x = left/right, y = forward/back
        return self.last


class Reader:
    def __init__(self, swap_grips, flip_y, tilt=None, grip_source='pad', tilt_z=None):
        self.tilt_z = tilt_z
        self.grip_source = grip_source
        self.swap_grips = swap_grips
        self.flip_y = flip_y
        self.tilt = tilt
        self.etee = EteeController()
        self.etee.connect()
        self.etee.start_data()
        self.etee.run()

    @staticmethod
    def norm(raw):
        if raw is None:
            return 0.0
        return max(-1.0, min(1.0, (raw - CENTRE) / CENTRE))

    def has_data(self, hand):
        """The API returns None until the first data packet arrives from that controller."""
        return self.etee.get_trackpad_x(hand) is not None

    def pad(self, hand):
        """(x, y, touched) for one trackpad. An untouched pad or a missing controller reads (0, 0, False)."""
        e = self.etee
        if not self.has_data(hand) or not e.get_trackpad_touched(hand):
            return 0.0, 0.0, False
        x = self.norm(e.get_trackpad_x(hand))
        y = self.norm(e.get_trackpad_y(hand))
        return x, (-y if self.flip_y else y), True

    PAD_CLICK_NAMES = ('get_trackpad_clicked', 'get_thumb_clicked', 'get_trackpad_click', 'get_trackpad_pressed')

    def pad_click(self, hand):
        """True while that trackpad is pressed down. Tries the likely getter names of the etee API once."""
        if not hasattr(self, '_click_fn'):
            self._click_fn = None
            for name in self.PAD_CLICK_NAMES:
                if hasattr(self.etee, name):
                    self._click_fn = getattr(self.etee, name)
                    print(f'Pad press is read with {name}.')
                    break
            if self._click_fn is None:
                names = [m for m in dir(self.etee) if 'click' in m or 'press' in m]
                print('No pad-press getter found. Getters with click/press in the name:', names)
        if self._click_fn is None or not self.has_data(hand):
            return False
        try:
            return bool(self._click_fn(hand))
        except Exception:
            return False

    def read_etee(self):
        """Returns a dict: lx, ly (left pad), rx, ry (right pad), lt, rt (touched), close, open."""
        lx, ly, lt = self.pad('left')
        rx, ry, rt = self.pad('right')
        if self.tilt is not None:
            t = self.tilt.read(self.etee)
            if t is not None and not lt:           # the left pad wins if a thumb is on it
                lx, ly, lt = t[0], t[1], True      # tilt takes the place of the left pad (x: left/right, y: fwd/back)
        if self.tilt_z is not None:
            tz = self.tilt_z.read(self.etee)
            if tz is not None and not rt:          # the right pad wins if a thumb is on it
                ry, rt = tz[1], True               # forward/back tilt of the up/down controller = up/down
        close_hand, open_hand = ('left', 'right') if self.swap_grips else ('right', 'left')
        if self.grip_source == 'squeeze':
            close = bool(self.has_data(close_hand) and self.etee.get_grip_clicked(close_hand))
            opn = bool(self.has_data(open_hand) and self.etee.get_grip_clicked(open_hand))
        else:
            close, opn = self.pad_click(close_hand), self.pad_click(open_hand)
        return {'lx': lx, 'ly': ly, 'rx': rx, 'ry': ry, 'lt': lt, 'rt': rt, 'close': close, 'open': opn}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--swap-grips', action='store_true', help='left controller closes, right controller opens')
    ap.add_argument('--grip-source', default='pad', choices=['pad', 'squeeze'],
                    help='pad (default): press a trackpad down to close (right) / open (left). squeeze: the old squeeze buttons')
    ap.add_argument('--host', default='127.0.0.1', help='WSL is reachable on localhost')
    ap.add_argument('--port', type=int, default=5005)
    ap.add_argument('--rate', type=float, default=30.0)
    ap.add_argument('--flip-y', action='store_true')
    ap.add_argument('--print', dest='print_only', action='store_true')
    ap.add_argument('--tilt', action='store_true', help='also steer by tilting a controller (hold the enable finger)')
    ap.add_argument('--tilt-hand', default='right', choices=['left', 'right'], help='which controller is tilted (both report tilt)')
    ap.add_argument('--tilt-enable', default='middle', choices=['index', 'middle', 'ring', 'pinky', 'thumb'], help='finger that must be clicked for tilt to count (default middle: it clicks when you squeeze)')
    ap.add_argument('--tilt-range', type=float, default=0.5, help='tilt in radians that counts as full push (0.5 = about 29 degrees)')
    ap.add_argument('--tilt-swap', action='store_true', help='swap which tilt is forward/back and which is left/right')
    ap.add_argument('--tilt-flip-x', action='store_true', help='reverse left/right tilt')
    ap.add_argument('--tilt-flip-y', action='store_true', help='reverse forward/back tilt')
    ap.add_argument('--tilt-z-hand', default='left', choices=['left', 'right'], help='controller whose forward/back tilt moves the arm UP/DOWN (with --tilt)')
    ap.add_argument('--no-tilt-z', action='store_true', help='do not use a controller for up/down (use the right pad)')
    ap.add_argument('--tilt-z-flip', action='store_true', help='reverse up/down tilt')
    ap.add_argument('--tilt-z-swap', action='store_true', help='use the sideways tilt of that controller for up/down instead')
    args = ap.parse_args()

    tilt = Tilt(args.tilt_hand, args.tilt_enable, args.tilt_range, args.tilt_swap, args.tilt_flip_x,
                args.tilt_flip_y) if args.tilt else None
    tilt_z = None
    if args.tilt and not args.no_tilt_z:
        tilt_z = Tilt(args.tilt_z_hand, args.tilt_enable, args.tilt_range, args.tilt_z_swap, False, args.tilt_z_flip)
    r = Reader(args.swap_grips, args.flip_y, tilt, args.grip_source, tilt_z)
    period = 1.0 / args.rate
    sock = None
    print('Reading both controllers. Ctrl+C to stop.')
    t0 = time.time()
    while not (r.has_data('left') or r.has_data('right')):
        if time.time() - t0 > 10:
            print('No data from either controller after 10 s. Check they are switched on and paired '
                  '(dongle blinks pink-pink-blue).')
            break
        print('Waiting for the controllers ...', end='\r')
        time.sleep(0.2)
    for hand in ('left', 'right'):
        if not r.has_data(hand):
            print(f'Note: no data from the {hand} controller yet.')
    try:
        while True:
            d = r.read_etee()
            if args.print_only:
                print(f"LEFT x {d['lx']:+.2f} y {d['ly']:+.2f} touch {int(d['lt'])} | RIGHT y {d['ry']:+.2f} "
                      f"touch {int(d['rt'])} | close {int(d['close'])} open {int(d['open'])}"
                      + (f" | TILT {'ON ' if tilt.active else 'off'} x {tilt.last[0]:+.2f} y {tilt.last[1]:+.2f} ({tilt.deg[0]:+.0f} / {tilt.deg[1]:+.0f} deg)" if tilt else '')
                      + (f" | UPDOWN {'ON ' if tilt_z.active else 'off'} {tilt_z.last[1]:+.2f} ({tilt_z.deg[1]:+.0f} deg)" if tilt_z else '')
                      + '   ', end='\r')
            else:
                if sock is None:
                    try:
                        sock = socket.create_connection((args.host, args.port), timeout=2)
                        print('Connected to the WSL bridge.')
                    except OSError:
                        print('Waiting for etee_bridge.py in WSL ...', end='\r')
                        time.sleep(1.0)
                        continue
                d['t'] = time.time()
                try:
                    sock.sendall((json.dumps(d) + '\n').encode())
                except OSError:
                    sock = None
                    print('Lost the bridge, reconnecting ...')
            time.sleep(period)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            r.etee.stop_data()
            r.etee.stop()
            r.etee.disconnect()
        except Exception as ex:
            print('cleanup:', ex, file=sys.stderr)


if __name__ == '__main__':
    main()
