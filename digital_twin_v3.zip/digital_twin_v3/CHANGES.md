# digital_twin_v3: tilt control (builds on v2)

v2 = trackpad + keyboard control. v3 adds Etee tilt steering and moves the gripper to trackpad presses. Tilt is experimental.

# Changes in this version

- `ros/etee_hold.py`: the gripper now opens and closes through the xArm gripper action
  (`/xarm_gripper/gripper_action`, GripperCommand). Going through MoveIt failed with error -26 (start state invalid)
  on the real arm. MoveIt is still the fallback if the action is missing.
- `ros/build_scene.py`: base plate thickness 8 mm (measured), so the table top is at z = -0.008 in the scene.
- `ros/wp3_*.py`, `fit_table_tf.py`, `start_wp3.sh`, `test_wp3_offline.py`, `add_camera.py`: WP3 perception link,
  written by Shadi (WP3). See WP3_HANDOFF.md.
- Keyboard hold-to-move (`keyboard/`) and Etee trackpad hold-to-move (`etee/`) are unchanged and tested on the real arm.

- `etee/etee_reader_windows.py`: gripper moved to trackpad presses (right press = close, left press = open) so the
  squeeze can be the tilt enable. `--tilt-enable` now defaults to `middle` (clicks when you squeeze). Use
  `--grip-source squeeze` for the old behaviour. Tilt steering is still experimental.
- `etee/etee_reader_windows.py`: with `--tilt`, squeeze the RIGHT controller and tilt it for forward/back/left/right, squeeze
  the LEFT controller and tilt it forward/back for up/down (`--no-tilt-z`, `--tilt-z-hand`, `--tilt-z-flip`, `--tilt-z-swap`).
  Tilt axes are built from the pose at the moment of the squeeze, so any grip works. Not yet validated on the real arm.
