# Digital twin interface for other work packages (WP2, v4)

The twin's hold node (`ros/etee_hold.py`) is the only node that commands the arm. Other nodes (for example the WP5
command node) talk to it through these topics. All positions and velocities are in the `world` frame: origin at the
robot base, x forward, y left, z up, metres and m/s.

## Inputs

| Topic | Type | Meaning |
| --- | --- | --- |
| `/twin/cmd_vel` | `geometry_msgs/msg/TwistStamped` | Fingertip linear velocity. Only `twist.linear` is used (no rotation; the tool stays pointing down). |
| `/twin/gripper_cmd` | `std_msgs/msg/String` | `"close"` or `"open"`. Closing on an object attaches it in the twin; opening drops it. |
| `/etee/joy` | `sensor_msgs/msg/Joy` | The operator (keyboard or Etee through `etee_bridge.py`). |

Rules for `/twin/cmd_vel`:
- Publish at 10 Hz or more. If no message arrives for **0.3 s**, the arm stops.
- Speed is capped at the `--speed` the hold node was started with (default 0.01 m/s). Speed is applied in 10 % steps.
- The direction is followed in a straight line until it changes by more than 25 degrees, the speed step changes,
  or a limit is reached.
- The node only starts after seeing **zero** velocity (and untouched pads) for 0.5 s. Send zeros first.
- **Operator override:** while the operator touches a pad or holds a key, `/twin/cmd_vel` is ignored.
- Workspace limits, the table fence, the 3.5 mm table clearance, collision checking (table, blocks, power box) and
  the watchdog all still apply. A refused move is reported in `/twin/state` (`last_refusal`).

## Output

| Topic | Type | Meaning |
| --- | --- | --- |
| `/twin/state` | `std_msgs/msg/String` (JSON, 5 Hz) | `fingertips_m` [x, y, z], `moving`, `source` (`operator`, `/twin/cmd_vel` or `none`), `direction`, `speed_m_s`, `held_object`, `armed`, `last_refusal` |
| `/twin/object_events` | `std_msgs/msg/String` (JSON) | `{"event": "grasped" or "released", "id": ..., "xyz": [...], "yaw": ...}` |
| `/joint_states` | `sensor_msgs/msg/JointState` | Arm joint angles (real or simulated) |

## Try it (simulation)

```
bash start_sim.sh                              # window 1
python3 etee_hold.py --speed 0.01              # window 2, type YES
python3 cmd_vel_demo.py                        # window 3: a 15 mm square at 5 mm/s
ros2 topic echo /twin/state                    # window 4
```
Or by hand: `ros2 topic pub -r 20 /twin/cmd_vel geometry_msgs/msg/TwistStamped "{header: {frame_id: world}, twist: {linear: {x: 0.005}}}"` (Ctrl+C stops it, and the arm stops 0.3 s later).

## v6: gripper angle and single-joint motion (for WP5 too)

- `/twin/cmd_vel` **angular** part (rad/s, world frame: x forward, y left, z up) turns the gripper **about the
  fingertip**, which stays where it is. One axis at a time: `angular.z` = twist (+ = anticlockwise seen from above),
  `angular.y` = tilt forward (−) / back (+), `angular.x` = tilt left (+) / right (−). Tilt is limited to 50° from
  straight down. Linear commands win over angular ones. Speed fraction = |ω| / `ang_cap_rad_s` (in `/twin/state`).
- `header.frame_id = "level"` (any twist values) turns the gripper back to straight down, keeping its twist.
- `/twin/joint_jog` (`std_msgs/Float32MultiArray`): `[joint 1..6, rad/s signed]`, same 0.3 s timeout. Every state
  on the way is collision-checked and kept inside the fingertip workspace before the arm moves. Send `[j, 0]` to stop.
- `/twin/state` adds `special` (what is turning, e.g. "twist gripper left"), `tilt_deg` and `ang_cap_rad_s`.
