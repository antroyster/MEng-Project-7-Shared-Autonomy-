# Keyboard control

Hold a key and the arm moves slowly; let go and it stops. Uses real key-down / key-up events from the Windows console,
so release is instant. It only reads keys while its own window is in front, and a key silent for 0.8 s counts as released.

| Key | Action |
|---|---|
| `W` / `S` (or up / down arrows) | forward / back |
| `A` / `D` (or left / right arrows) | left / right |
| `R` / `F` (or PageUp / PageDown) | up / down |
| `C` / `O` | close / open gripper (once per press) |
| `Space` | stop everything now |
| `Q` or `Esc` | quit |

## Steps
1. **Ubuntu** (see the main README for the `cd`): `bash start_sim.sh` (window 1), `bash start_bridge.sh` (window 2),
   then in window 3 `source /opt/ros/jazzy/setup.bash; source ~/xarm_ws/install/setup.bash; python3 etee_hold.py`, type `YES`.
2. **Windows PowerShell** (Etee reader must be off):
   ```powershell
   python keyboard_reader_windows.py            # add --print to just see the keys
   ```
   Wait for `Connected to the WSL bridge`, click that window, wait for `armed` in window 3, then hold `W`.

Step-based keyboard teaching (save waypoints, pick/place) is `ros/teach_keyboard.py` and does not need the Windows reader.
