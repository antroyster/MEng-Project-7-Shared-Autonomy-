#!/usr/bin/env python3
r"""WINDOWS. Hold a key and the arm moves, let go and it stops. Replaces etee_reader_windows.py while you use it
(the bridge takes one Windows sender at a time).

  cd <folder that holds this file>
  python keyboard_reader_windows.py

Everything after this is the same as with the Etee: etee_bridge.py -> /etee/joy -> etee_hold.py
(same slow constant speed, table boundary, limits, instant stop and watchdog).

KEYS (hold them; click on THIS window first, it only reads keys while it is in front)
  W / S   forward / back        A / D   left / right        R / F   up / down
  arrows  forward, back, left, right      PageUp / PageDown   up / down
  C       close gripper (once per press)   O   open gripper (once per press)
  SPACE   stop everything now (all keys released)           Q or Esc   quit

Safety: a key counts as held only while Windows keeps sending its key-down events (or until its key-up), and a key
that goes quiet for 0.8 s is treated as released. Losing focus releases everything.
"""
import argparse
import json
import socket
import sys
import time

HOLD_TIMEOUT = 0.8          # s: a key with no event for this long is treated as released (safety net)

VK = {'W': 0x57, 'A': 0x41, 'S': 0x53, 'D': 0x44, 'R': 0x52, 'F': 0x46, 'C': 0x43, 'O': 0x4F, 'Q': 0x51,
      'UP': 0x26, 'DOWN': 0x28, 'LEFT': 0x25, 'RIGHT': 0x27, 'PGUP': 0x21, 'PGDN': 0x22,
      'SPACE': 0x20, 'ESC': 0x1B}
VK_NAME = {v: k for k, v in VK.items()}


class KeyState:
    """Which keys are held, from key-down / key-up / focus events. No Windows code in here, so it can be tested."""

    def __init__(self):
        self.last = {}                      # key name -> time of its last key-down event

    def event(self, name, down, now):
        if down:
            self.last[name] = now
        else:
            self.last.pop(name, None)

    def focus_lost(self):
        self.last.clear()

    def clear(self):
        self.last.clear()

    def held(self, now):
        for k in [k for k, t in self.last.items() if now - t > HOLD_TIMEOUT]:
            del self.last[k]
        return set(self.last)

    def command(self, now):
        """The dict the bridge expects. Opposite keys cancel."""
        h = self.held(now)
        fwd = (('W' in h or 'UP' in h) - ('S' in h or 'DOWN' in h))
        right = (('D' in h or 'RIGHT' in h) - ('A' in h or 'LEFT' in h))
        up = (('R' in h or 'PGUP' in h) - ('F' in h or 'PGDN' in h))
        return {'lx': float(right), 'ly': float(fwd), 'rx': 0.0, 'ry': float(up),
                'lt': int(bool(fwd or right)), 'rt': int(bool(up)),
                'close': int('C' in h), 'open': int('O' in h)}


# ------------------------------------------------------------------ Windows console input
def open_console():
    import ctypes
    from ctypes import wintypes
    k32 = ctypes.windll.kernel32

    class KEY_EVENT_RECORD(ctypes.Structure):
        _fields_ = [('bKeyDown', wintypes.BOOL), ('wRepeatCount', wintypes.WORD),
                    ('wVirtualKeyCode', wintypes.WORD), ('wVirtualScanCode', wintypes.WORD),
                    ('uChar', wintypes.WCHAR), ('dwControlKeyState', wintypes.DWORD)]

    class EVENT_UNION(ctypes.Union):
        _fields_ = [('KeyEvent', KEY_EVENT_RECORD), ('pad', ctypes.c_byte * 16)]

    class INPUT_RECORD(ctypes.Structure):
        _fields_ = [('EventType', wintypes.WORD), ('Event', EVENT_UNION)]

    k32.GetStdHandle.restype = wintypes.HANDLE
    handle = k32.GetStdHandle(-10)                      # STD_INPUT_HANDLE
    old_mode = wintypes.DWORD()
    if not k32.GetConsoleMode(handle, ctypes.byref(old_mode)):
        raise RuntimeError('Run this in a normal PowerShell window (it needs a console).')
    # processed input (Ctrl+C works) + window/focus events. No line input, no echo, no VT input.
    k32.SetConsoleMode(handle, wintypes.DWORD(0x0001 | 0x0008))

    def poll(timeout_ms):
        """Yield ('key', name, down) / ('focus', gained) for the events waiting."""
        out = []
        if k32.WaitForSingleObject(handle, timeout_ms) != 0:
            return out
        buf = (INPUT_RECORD * 64)()
        n = wintypes.DWORD()
        k32.ReadConsoleInputW(handle, buf, 64, ctypes.byref(n))
        for i in range(n.value):
            rec = buf[i]
            if rec.EventType == 0x0001:                  # KEY_EVENT
                ke = rec.Event.KeyEvent
                out.append(('key', VK_NAME.get(ke.wVirtualKeyCode), bool(ke.bKeyDown)))
            elif rec.EventType == 0x0010:                # FOCUS_EVENT
                out.append(('focus', bool(rec.Event.pad[0])))
        return out

    def restore():
        k32.SetConsoleMode(handle, old_mode)

    return poll, restore


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--host', default='127.0.0.1')
    ap.add_argument('--port', type=int, default=5005)
    ap.add_argument('--rate', type=float, default=50.0, help='messages per second')
    ap.add_argument('--print', dest='print_only', action='store_true', help='show the keys only, send nothing')
    args = ap.parse_args()
    if sys.platform != 'win32':
        sys.exit('This script is for Windows PowerShell (it reads the Windows console).')
    poll, restore = open_console()
    keys, sock = KeyState(), None
    period = 1.0 / args.rate
    print(__doc__.split('KEYS')[1].split('Safety')[0].strip('\n'))
    print('\nClick this window and hold a key. Ctrl+C to stop.\n')
    try:
        while True:
            for ev in poll(int(period * 1000)):
                now = time.monotonic()
                if ev[0] == 'focus':
                    if not ev[1]:
                        keys.focus_lost()
                    continue
                _, name, down = ev
                if name is None:
                    continue
                if down and name in ('Q', 'ESC'):
                    raise KeyboardInterrupt
                if down and name == 'SPACE':
                    keys.clear()
                    continue
                keys.event(name, down, now)
            d = keys.command(time.monotonic())
            if args.print_only:
                print(f"fwd/back {d['ly']:+.0f}  left/right {d['lx']:+.0f}  up/down {d['ry']:+.0f}  "
                      f"close {d['close']} open {d['open']}   ", end='\r')
                continue
            if sock is None:
                try:
                    sock = socket.create_connection((args.host, args.port), timeout=2)
                    print('Connected to the WSL bridge.            ')
                except OSError:
                    print('Waiting for etee_bridge.py in WSL ...   ', end='\r')
                    time.sleep(1.0)
                    continue
            d['t'] = time.time()
            try:
                sock.sendall((json.dumps(d) + '\n').encode())
            except OSError:
                sock = None
                print('Lost the bridge, reconnecting ...')
    except KeyboardInterrupt:
        pass
    finally:
        try:
            if sock:
                zero = {'lx': 0.0, 'ly': 0.0, 'rx': 0.0, 'ry': 0.0, 'lt': 0, 'rt': 0, 'close': 0, 'open': 0, 't': time.time()}
                sock.sendall((json.dumps(zero) + '\n').encode())
        except OSError:
            pass
        restore()
        print('\nStopped.')


if __name__ == '__main__':
    main()
