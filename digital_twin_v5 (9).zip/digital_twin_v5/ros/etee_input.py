"""Etee pad input -> jog command. No ROS needed: works on anything with .axes and .buttons (sensor_msgs/Joy).

Joy layout (published by etee_bridge.py):
  axes[0], axes[1]   LEFT pad  x (left/right), y (forward/back)
  axes[2], axes[3]   RIGHT pad x (unused),     y (up/down)
  buttons[0], [1]    left / right pad touched
  buttons[2]         close gripper (right squeeze)
  buttons[3]         open gripper  (left squeeze)

Direction convention (robot base frame): x forward, y left, z up.
"""
import numpy as np

DEADZONE = 0.30      # pad movement below this is ignored; above it the push is rescaled from 0 to 1
CURVE = 1.6          # response curve: above 1 makes light pushes gentler (finer control at low speed)
LEVELS = ((0.30, 0.20), (0.65, 0.50), (1.01, 1.00))   # (upper pad deflection, fraction of the top speed)


def _axis(msg, i, touched):
    if len(msg.axes) <= i or len(msg.buttons) <= touched or not msg.buttons[touched]:
        return 0.0
    a = max(-1.0, min(1.0, msg.axes[i]))
    if abs(a) < DEADZONE:
        return 0.0
    r = (abs(a) - DEADZONE) / (1.0 - DEADZONE)      # 0 just past the dead zone, 1 fully pushed
    return (1.0 if a > 0 else -1.0) * (r ** CURVE)


def pad_command(msg, flips=(1.0, 1.0, 1.0)):
    """Joy -> (unit direction [forward, left, up], deflection 0..1), or (None, 0.0) when nothing is pushed.

    Only the strongest direction is used (a weaker one under half its size is ignored), so a little noise
    on the other pad cannot add a drift, for example down into the table."""
    lx, ly, ry = _axis(msg, 0, 0), _axis(msg, 1, 0), _axis(msg, 3, 1)
    d = np.array([ly * flips[0], -lx * flips[1], ry * flips[2]])
    mag = float(np.max(np.abs(d)))
    if mag == 0.0:
        return None, 0.0
    d[np.abs(d) < 0.5 * mag] = 0.0
    return d / np.linalg.norm(d), mag


def speed_fraction(deflection):
    for upper, frac in LEVELS:
        if deflection < upper:
            return frac
    return 1.0


def describe_direction(d):
    if d is None:
        return 'nothing'
    names = []
    for value, plus, minus in ((d[0], 'FORWARD', 'BACK'), (d[1], 'LEFT', 'RIGHT'), (d[2], 'UP', 'DOWN')):
        if value > 0.2:
            names.append(plus)
        elif value < -0.2:
            names.append(minus)
    return ' + '.join(names) if names else 'nothing'
