#!/usr/bin/env python3
"""Add the 7 cm extension cylinder between the arm flange and the xArm gripper in the robot MODEL.

  python3 add_extension.py            edits the files in ~/xarm_ws/src/xarm_ros2 (makes .bak copies first)
  python3 add_extension.py --undo     restores the .bak copies
  python3 add_extension.py --length 0.07 --diameter 0.075

What it changes:
  1. xarm_description/urdf/gripper/xarm_gripper.urdf.xacro
       new link 'tool_extension' (a cylinder) fixed to the arm's last link, and the gripper base now hangs
       off that link, LENGTH below it. So the gripper and fingertips move down by LENGTH.
  2. xarm_moveit_config/srdf/_xarm6_macro.srdf.xacro
       tells MoveIt the new link may touch its neighbours (otherwise MoveIt sees the arm in collision with
       itself and refuses to plan).
Then rebuild:  cd ~/xarm_ws && colcon build --packages-select xarm_description xarm_moveit_config && source install/setup.bash
"""
import argparse
import os
import re
import shutil
import sys

WS = os.path.expanduser('~/xarm_ws/src/xarm_ros2')
URDF = os.path.join(WS, 'xarm_description/urdf/gripper/xarm_gripper.urdf.xacro')
SRDF = os.path.join(WS, 'xarm_moveit_config/srdf/_xarm6_macro.srdf.xacro')
MARK = 'tool_extension'

OLD_JOINT = """      <joint name="${prefix}gripper_fix" type="fixed">
        <parent link="${attach_to}"/>
        <child link="${prefix}xarm_gripper_base_link"/>
        <origin xyz="${attach_xyz}" rpy="${attach_rpy}"/>
      </joint>"""

NEW_JOINT = """      <!-- tool_extension: the {l_cm:g} cm cylinder fitted between the flange and the gripper on the real robot -->
      <link name="${{prefix}}tool_extension">
        <inertial>
          <origin xyz="0 0 {half}" rpy="0 0 0"/>
          <mass value="0.3"/>
          <inertia ixx="0.0002" ixy="0" ixz="0" iyy="0.0002" iyz="0" izz="0.0002"/>
        </inertial>
        <visual>
          <origin xyz="0 0 {half}" rpy="0 0 0"/>
          <geometry><cylinder radius="{r}" length="{l}"/></geometry>
          <material name="${{prefix}}ToolExtensionGrey"><color rgba="0.55 0.55 0.60 1"/></material>
        </visual>
        <collision>
          <origin xyz="0 0 {half}" rpy="0 0 0"/>
          <geometry><cylinder radius="{r}" length="{l}"/></geometry>
        </collision>
      </link>
      <joint name="${{prefix}}tool_extension_fix" type="fixed">
        <parent link="${{attach_to}}"/>
        <child link="${{prefix}}tool_extension"/>
        <origin xyz="${{attach_xyz}}" rpy="${{attach_rpy}}"/>
      </joint>
      <joint name="${{prefix}}gripper_fix" type="fixed">
        <parent link="${{prefix}}tool_extension"/>
        <child link="${{prefix}}xarm_gripper_base_link"/>
        <origin xyz="0 0 {l}" rpy="0 0 0"/>
      </joint>"""

NEIGHBOURS = ['link5', 'link6', 'link_eef', 'xarm_gripper_base_link']


def backup(path):
    if not os.path.exists(path + '.bak'):
        shutil.copy2(path, path + '.bak')


def edit_urdf(length, diameter):
    s = open(URDF).read()
    if MARK in s:
        print('URDF already has the extension, skipping.'); return True
    if OLD_JOINT not in s:
        print('Could not find the gripper_fix joint exactly as expected in', URDF)
        print('Nothing was changed. Send me lines 100-120 of that file.'); return False
    backup(URDF)
    new = NEW_JOINT.format(l=f'{length:g}', l_cm=length * 100, half=f'{length / 2:g}', r=f'{diameter / 2:g}')
    open(URDF, 'w').write(s.replace(OLD_JOINT, new))
    print('URDF edited:', URDF); return True


def edit_srdf():
    s = open(SRDF).read()
    if MARK in s:
        print('SRDF already has the extension, skipping.'); return True
    lines = s.split('\n')
    idx = next((i for i, ln in enumerate(lines) if 'disable_collisions' in ln and 'xarm_gripper_base_link' in ln), None)
    if idx is None:
        print('Could not find a disable_collisions line for xarm_gripper_base_link in', SRDF)
        print('Nothing was changed in the SRDF. Send me the output of:  grep -n "gripper" ' + SRDF); return False
    indent = re.match(r'\s*', lines[idx]).group(0)
    add = [indent + f'<disable_collisions link1="${{prefix}}tool_extension" link2="${{prefix}}{n}" reason="Adjacent"/>'
           for n in NEIGHBOURS]
    backup(SRDF)
    lines[idx + 1:idx + 1] = add
    open(SRDF, 'w').write('\n'.join(lines))
    print('SRDF edited:', SRDF); return True


def undo():
    for p in (URDF, SRDF):
        if os.path.exists(p + '.bak'):
            shutil.copy2(p + '.bak', p); print('restored', p)
        else:
            print('no backup for', p)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--undo', action='store_true')
    ap.add_argument('--length', type=float, default=0.07)
    ap.add_argument('--diameter', type=float, default=0.075)
    a = ap.parse_args()
    if a.undo:
        undo(); return 0
    for p in (URDF, SRDF):
        if not os.path.exists(p):
            print('missing file:', p); return 1
    ok = edit_urdf(a.length, a.diameter) and edit_srdf()
    if ok:
        print('\nNow rebuild:\n  cd ~/xarm_ws && colcon build --packages-select xarm_description xarm_moveit_config && source install/setup.bash')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
