"""xArm 6 forward kinematics (standard DH, metres/radians), used to time the straight-line moves.
Base frame = the robot base, z up. fk_tcp gives the fingertip position and the tool rotation."""
import math

import numpy as np

DH = [  # theta_offset, d, a, alpha
    (0.0, 0.267, 0.0, -math.pi / 2),
    (-1.3849, 0.0, 0.2894888, 0.0),
    (1.3849, 0.0, 0.0775, -math.pi / 2),
    (0.0, 0.3425, 0.0, math.pi / 2),
    (0.0, 0.0, 0.076, -math.pi / 2),
    (0.0, 0.097, 0.0, 0.0),
]


def _T(theta, d, a, al):
    ct, st, ca, sa = math.cos(theta), math.sin(theta), math.cos(al), math.sin(al)
    return np.array([[ct, -st * ca, st * sa, a * ct],
                     [st, ct * ca, -ct * sa, a * st],
                     [0, sa, ca, d],
                     [0, 0, 0, 1]])


def fk_tcp(q, tcp_offset):
    """Fingertip position (3,) and tool rotation (3x3) for joint angles q (6,)."""
    M = np.eye(4)
    for (off, d, a, al), qi in zip(DH, q):
        M = M @ _T(qi + off, d, a, al)
    R = M[:3, :3]
    return M[:3, 3] + R[:, 2] * tcp_offset, R
