#!/usr/bin/env python3
"""Perception -> digital twin: keep the Jenga block in MoveIt's scene where perception sees it.

INTERFACE TO AGREE WITH WP3 (put it in the interface specification):
  topic  /perception/block_pose        type  geometry_msgs/msg/PoseStamped
  frame  the robot base frame (link_base), metres, quaternion orientation
  rate   5 Hz or faster; the block lies flat so only its yaw matters

  python3 perception_bridge.py                       listen to the real perception output
  python3 perception_bridge.py --fake --x 0.30 --y 0.05 --yaw 20
                                                     also publish a made-up detection (about +-1 mm
                                                     and +-0.5 deg of noise) to test the chain
Start MoveIt and build_scene.py first. Updates are skipped while the block is attached to the
gripper. pick_place_sim.py reads the block position from the scene, so it follows the detection.
"""
import argparse
import math
import random
import time

import rclpy
from geometry_msgs.msg import Pose, PoseStamped
from moveit_msgs.msg import CollisionObject, ObjectColor, PlanningScene, PlanningSceneComponents
from moveit_msgs.srv import ApplyPlanningScene, GetPlanningScene
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from shape_msgs.msg import SolidPrimitive
from std_msgs.msg import ColorRGBA

import build_scene as bs

TOPIC = '/perception/block_pose'
SNAP_TO_TABLE = True      # depth noise in z is ignored: the block is placed flat on the table
MOVE_TOL = 0.003          # m: only update the scene if the block moved more than this
YAW_TOL = 2.0             # deg
MAX_AGE = 1.0             # s: ignore detections older than this
ALLOWED_FRAMES = (bs.FRAME, 'link_base', 'world')


class Bridge(Node):
    def __init__(self, fake, fx, fy, fyaw):
        super().__init__('perception_bridge')
        self.get_scene = self.create_client(GetPlanningScene, '/get_planning_scene')
        self.apply_scene = self.create_client(ApplyPlanningScene, '/apply_planning_scene')
        self.latest = None        # (x, y, z, yaw_deg)
        self.applied = None
        self.last_warn = 0.0
        self.create_subscription(PoseStamped, TOPIC, self.on_pose, qos_profile_sensor_data)
        if fake:
            self.fx, self.fy, self.fyaw = fx, fy, fyaw
            self.pub = self.create_publisher(PoseStamped, TOPIC, 10)
            self.create_timer(0.1, self.publish_fake)
            self.get_logger().info(f'FAKE detection on {TOPIC} at ({fx:.3f}, {fy:.3f}) yaw {fyaw:.0f} deg')

    def publish_fake(self):
        m = PoseStamped()
        m.header.frame_id = bs.FRAME
        m.header.stamp = self.get_clock().now().to_msg()
        m.pose.position.x = self.fx + random.gauss(0.0, 0.001)
        m.pose.position.y = self.fy + random.gauss(0.0, 0.001)
        m.pose.position.z = bs.Z_FLOOR + bs.JENGA[2] / 2.0
        h = math.radians(self.fyaw + random.gauss(0.0, 0.5)) / 2.0
        m.pose.orientation.z, m.pose.orientation.w = math.sin(h), math.cos(h)
        self.pub.publish(m)

    def on_pose(self, m):
        if m.header.frame_id not in ALLOWED_FRAMES:
            if time.time() - self.last_warn > 5.0:
                self.get_logger().error(f'detection is in frame "{m.header.frame_id}", expected '
                                        f'{ALLOWED_FRAMES[0]}. WP3 must publish in the robot base frame '
                                        f'(or we add a TF transform).')
                self.last_warn = time.time()
            return
        stamp = m.header.stamp.sec + m.header.stamp.nanosec * 1e-9
        if stamp and self.get_clock().now().nanoseconds * 1e-9 - stamp > MAX_AGE:
            return                                          # stale
        q = m.pose.orientation
        yaw = math.degrees(math.atan2(2.0 * (q.w * q.z + q.x * q.y), 1.0 - 2.0 * (q.y * q.y + q.z * q.z)))
        self.latest = (m.pose.position.x, m.pose.position.y, m.pose.position.z, yaw)

    def call(self, client, request):
        while not client.wait_for_service(timeout_sec=2.0):
            self.get_logger().info(f'waiting for {client.srv_name} (is move_group up?)')
        future = client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
        return future.result()

    def block_is_attached(self):
        req = GetPlanningScene.Request()
        req.components.components = PlanningSceneComponents.ROBOT_STATE_ATTACHED_OBJECTS
        scene = self.call(self.get_scene, req).scene
        return any(a.object.id == 'jenga_block' for a in scene.robot_state.attached_collision_objects)

    def maybe_update(self):
        if self.latest is None:
            return
        x, y, z, yaw = self.latest
        if self.applied:
            ax, ay, ayaw = self.applied
            dyaw = abs(((yaw - ayaw + 90.0) % 180.0) - 90.0)          # block looks the same turned 180 deg
            if math.hypot(x - ax, y - ay) < MOVE_TOL and dyaw < YAW_TOL:
                return
        if self.block_is_attached():
            return
        obj = CollisionObject(id='jenga_block', operation=CollisionObject.ADD)
        obj.header.frame_id = bs.FRAME
        obj.primitives.append(SolidPrimitive(type=SolidPrimitive.BOX, dimensions=list(bs.JENGA)))
        p = Pose()
        p.position.x, p.position.y = x, y
        p.position.z = bs.Z_FLOOR + bs.JENGA[2] / 2.0 if SNAP_TO_TABLE else z
        h = math.radians(yaw) / 2.0
        p.orientation.z, p.orientation.w = math.sin(h), math.cos(h)
        obj.primitive_poses.append(p)
        scene = PlanningScene(is_diff=True)
        scene.world.collision_objects.append(obj)
        r, g, b, a = bs.COLOURS['jenga_block']
        scene.object_colors.append(ObjectColor(id='jenga_block', color=ColorRGBA(r=r, g=g, b=b, a=a)))
        if self.call(self.apply_scene, ApplyPlanningScene.Request(scene=scene)).success:
            self.applied = (x, y, yaw)
            self.get_logger().info(f'block updated: x={x:.3f} y={y:.3f} yaw={yaw:.1f} deg')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--fake', action='store_true', help='also publish a made-up detection')
    ap.add_argument('--x', type=float, default=bs.JENGA_XY[0])
    ap.add_argument('--y', type=float, default=bs.JENGA_XY[1])
    ap.add_argument('--yaw', type=float, default=0.0, help='degrees')
    args = ap.parse_args()
    rclpy.init()
    node = Bridge(args.fake, args.x, args.y, args.yaw)
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
            node.maybe_update()
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
