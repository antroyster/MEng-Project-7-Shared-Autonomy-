#!/usr/bin/env bash
# WP3 link, run AFTER start_sim.sh or start_real.sh is up (Window 1).
#   bash start_wp3.sh              table TF from wp3_table_tf.yaml + multi-block scene bridge
#   bash start_wp3.sh --tf-only    only the table TF (display WP3's markers in RViz, no scene changes)
# Extra arguments after --tf-only / on their own are passed to wp3_scene_bridge.py.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source /opt/ros/jazzy/setup.bash
if [ -f ~/xarm_ws/install/setup.bash ]; then
  source ~/xarm_ws/install/setup.bash
fi
export ROS_DOMAIN_ID="${ROS_DOMAIN_ID:-67}"
export ROS_AUTOMATIC_DISCOVERY_RANGE="${ROS_AUTOMATIC_DISCOVERY_RANGE:-LOCALHOST}"
if [ -f "$HERE/../../WP3-Live-Implementation-v2-Three-View/ros2_ws/src/wp3_live_perception/config/fastdds_shm_profile.xml" ]; then
  export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
  export FASTRTPS_DEFAULT_PROFILES_FILE="$(cd "$HERE/../../WP3-Live-Implementation-v2-Three-View/ros2_ws/src/wp3_live_perception/config" && pwd)/fastdds_shm_profile.xml"
fi
cd "$HERE"

if [ ! -f wp3_table_tf.yaml ]; then
  echo "wp3_table_tf.yaml missing: measure it first (python3 fit_table_tf.py points.csv). See WP3_HANDOFF.md."; exit 1
fi
if ! ros2 topic list 2>/dev/null | grep -q "^/wp3_live/markers$"; then
  echo "WARNING: /wp3_live/markers not visible yet. Check ROS_DOMAIN_ID matches the WP3 machine and the WP3 node or bag replay is running."
fi

python3 wp3_table_tf.py &
TF_PID=$!
trap 'kill $TF_PID 2>/dev/null; wait $TF_PID 2>/dev/null' EXIT INT TERM
sleep 1

if [ "$1" == "--tf-only" ]; then
  echo "TF published. In RViz: Add > By topic > /wp3_live/markers (MarkerArray). Ctrl+C to stop."
  wait $TF_PID
else
  python3 wp3_scene_bridge.py "$@"
fi
