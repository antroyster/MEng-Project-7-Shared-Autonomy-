#!/usr/bin/env python3
"""Check the Etee controls WITHOUT moving the robot. Prints what etee_hold.py would do with your input.

  python3 etee_check.py            (needs etee_bridge.py and the Windows reader running; MoveIt is NOT needed)
  python3 etee_check.py --flip-z   to test a reversed direction

Touch a pad and push: you should read FORWARD / BACK / LEFT / RIGHT for the left pad and UP / DOWN for the
right pad. Squeeze the right controller: CLOSE. Squeeze the left one: OPEN. Do this BEFORE moving the arm.
"""
import argparse
import time

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Joy

from etee_input import describe_direction, pad_command, speed_fraction


class Check(Node):
    def __init__(self, flips):
        super().__init__('etee_check')
        self.flips = flips
        self.msg = None
        self.rx = 0.0
        self.prev = []
        self.create_subscription(Joy, '/etee/joy', self.on_joy, 10)

    def on_joy(self, m):
        self.msg, self.rx = m, time.monotonic()
        for i, name in ((2, 'CLOSE gripper (right squeeze)'), (3, 'OPEN gripper (left squeeze)')):
            now = len(m.buttons) > i and m.buttons[i]
            was = len(self.prev) > i and self.prev[i]
            if now and not was:
                print(f'\n>>> {name}')
        self.prev = list(m.buttons)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--flip-x', action='store_true')
    ap.add_argument('--flip-y', action='store_true')
    ap.add_argument('--flip-z', action='store_true')
    ap.add_argument('--deadzone', type=float, default=0.30)
    ap.add_argument('--curve', type=float, default=1.6)
    a = ap.parse_args()
    import etee_input
    etee_input.DEADZONE = a.deadzone
    etee_input.CURVE = a.curve
    flips = (-1.0 if a.flip_x else 1.0, -1.0 if a.flip_y else 1.0, -1.0 if a.flip_z else 1.0)
    rclpy.init()
    node = Check(flips)
    print('Listening on /etee/joy. Ctrl+C to stop. Nothing moves.')
    last = 0.0
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.05)
            now = time.monotonic()
            if now - last < 0.25:
                continue
            last = now
            m = node.msg
            if m is None or now - node.rx > 0.5:
                print('no data from /etee/joy (bridge or Windows reader not running?)      ', end='\r')
                continue
            ax = list(m.axes) + [0.0] * 4
            bt = list(m.buttons) + [0] * 4
            d, mag = pad_command(m, flips)
            say = 'nothing' if d is None else f'{describe_direction(d)} at {int(speed_fraction(mag) * 100)}% speed'
            print(f'left pad ({ax[0]:+.2f},{ax[1]:+.2f}) touch {int(bt[0])} | right pad y {ax[3]:+.2f} touch {int(bt[1])}'
                  f'  ->  {say:<32}', end='\r')
    except KeyboardInterrupt:
        print()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
