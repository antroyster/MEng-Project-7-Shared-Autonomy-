#!/usr/bin/env python3
"""Example client of the twin's velocity interface (INTERFACE.md), for WP5 tests. Simulation first.

  python3 cmd_vel_demo.py              5 mm/s: forward 3 s, left 3 s, back 3 s, right 3 s (a 15 mm square), then stop
  python3 cmd_vel_demo.py --speed 0.003
  python3 cmd_vel_demo.py --grip       also closes the gripper at the end and opens it again

Run etee_hold.py first. It must be started with --speed at or above the speed asked here, or the twin caps it.
"""
import argparse
import time

import rclpy
from geometry_msgs.msg import TwistStamped
from rclpy.node import Node
from std_msgs.msg import String


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--speed', type=float, default=0.005)
    ap.add_argument('--leg', type=float, default=3.0, help='seconds per side')
    ap.add_argument('--grip', action='store_true')
    args = ap.parse_args()
    rclpy.init()
    node = Node('cmd_vel_demo')
    pub = node.create_publisher(TwistStamped, '/twin/cmd_vel', 10)
    grip = node.create_publisher(String, '/twin/gripper_cmd', 10)
    last = {'state': ''}
    node.create_subscription(String, '/twin/state', lambda m: last.update(state=m.data), 10)

    def send(vx, vy, vz, seconds):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            msg = TwistStamped()
            msg.header.stamp = node.get_clock().now().to_msg()
            msg.header.frame_id = 'world'
            msg.twist.linear.x, msg.twist.linear.y, msg.twist.linear.z = float(vx), float(vy), float(vz)
            pub.publish(msg)                         # 20 Hz; the twin stops if this pauses for 0.3 s
            rclpy.spin_once(node, timeout_sec=0.05)

    v = args.speed
    print('zero for 1 s (the twin arms only after seeing the inputs at rest)')
    send(0, 0, 0, 1.0)
    for name, vel in (('forward', (v, 0, 0)), ('left', (0, v, 0)), ('back', (-v, 0, 0)), ('right', (0, -v, 0))):
        print(name)
        send(*vel, args.leg)
        send(0, 0, 0, 0.6)
    print('last /twin/state:', last['state'])
    if args.grip:
        for word in ('close', 'open'):
            grip.publish(String(data=word))
            print('gripper', word)
            send(0, 0, 0, 2.0)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
