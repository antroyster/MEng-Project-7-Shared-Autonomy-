#!/usr/bin/env python3
"""Guided calibration for live perception (started by `twin.sh --live` when needed, or with --calibrate).

Step A  cameras -> checkerboard   runs WP3's register_board.py, shows the corner images, re-runs with --flip if needed
Step B  checkerboard -> robot     you put the fingertip on corners 0, 7, 40, 47 using the app; press Capture each time
        then fit_table_tf.py checks the fit (RMS < 3 mm, max < 5 mm) and saves wp3_table_tf.yaml

Needs the twin running (arm, hold node, GUI) and the three cameras publishing. Prompts appear here AND in the app;
Capture works from the app button, the P key in the app, or Enter here.

Writes the Step A folder to ~/twin_calibration/last_camera_cal.txt (twin.sh reads it).
"""
import argparse
import datetime
import glob
import json
import math
import os
import shutil
import subprocess
import sys
import threading
import time

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

HERE = os.path.dirname(os.path.abspath(__file__))
SAVE = os.path.expanduser('~/twin_calibration')
CORNERS = [(0, 'top-left'), (7, 'top-right'), (40, 'bottom-left'), (47, 'bottom-right')]
PITCH = 0.020
GRID = {0: (0, 0), 7: (7, 0), 40: (0, 5), 47: (7, 5)}        # corner -> (col, row)


def corner_distance(a, b):
    (ca, ra), (cb, rb) = GRID[a], GRID[b]
    return math.hypot(ca - cb, ra - rb) * PITCH


class Wizard(Node):
    def __init__(self):
        super().__init__('twin_calib_wizard')
        self.prompt_pub = self.create_publisher(String, '/twin/calib_prompt', 10)
        self.home_pub = self.create_publisher(String, '/twin/home', 10)
        self.state = None
        self.capture = threading.Event()
        self.create_subscription(String, '/twin/state', self.on_state, 10)
        self.create_subscription(String, '/twin/calib', self.on_calib, 10)

    def on_state(self, msg):
        try:
            self.state = json.loads(msg.data)
        except ValueError:
            pass

    def on_calib(self, msg):
        if msg.data.strip().lower() in ('capture', 'next', 'ok'):
            self.capture.set()

    def show(self, title, text, capture=False, button='Continue'):
        """Prompt in the terminal and in the app."""
        print(f'\n=== {title} ===\n{text}')
        self.prompt_pub.publish(String(data=json.dumps(
            {'title': title, 'text': text, 'capture': capture, 'button': button})))

    def clear(self):
        self.prompt_pub.publish(String(data=json.dumps({'title': ''})))

    def wait(self, hint='Press Enter here, or the button in the app'):
        """Wait for Enter (terminal) or the app's button. Returns what was typed (empty from the app)."""
        self.capture.clear()
        typed = {}

        def read():
            try:
                typed['v'] = input(f'  [{hint}] > ')
            except EOFError:
                typed['v'] = ''
            self.capture.set()
        threading.Thread(target=read, daemon=True).start()
        self.capture.wait()
        return typed.get('v', '').strip()

    def fingertip(self):
        s = self.state or {}
        return s.get('fingertips_m')


def run_wp3(wp3_dir, cmd):
    """Run a WP3 command with WP3's environment (lab_env.sh). Returns (exit code, output)."""
    full = f'cd "{wp3_dir}" && source scripts/lab_env.sh && {cmd}'
    p = subprocess.run(['bash', '-c', full], capture_output=True, text=True)
    return p.returncode, (p.stdout or '') + (p.stderr or '')


def open_images(paths):
    for p in paths:
        if os.path.exists(p):
            for viewer in ('xdg-open', 'eog'):
                if shutil.which(viewer):
                    subprocess.Popen([viewer, p], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    break


def step_a(w, wp3_dir, ref):
    w.show('Calibration 1 of 2: cameras',
           '1. Lay the 8x6 checkerboard flat on the table, inside the cameras\' view. Do not move it again until '
           'calibration is finished.\n'
           '2. The arm goes to its home pose now (the wrist camera is calibrated from there, and must be back '
           'there for live perception).\n'
           '3. Keep hands and the arm out of the cameras\' view.\nThen continue.')
    w.home_pub.publish(String(data='go'))
    w.wait()
    flips = []
    while True:
        out = os.path.expanduser('~/wp3_board_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
        flag = ''.join(f' --flip {f}' for f in flips)
        w.show('Calibration 1 of 2: cameras', f'Measuring the board with all three cameras (about 20 s) ...')
        code, text = run_wp3(wp3_dir, f'python3 scripts/register_board.py "{out}" "{ref}" --pitch-mm 20{flag}')
        print(text[-3000:])
        pngs = [os.path.join(out, f'{r}_board.png') for r in ('wrist', 'tripod', 'third')]
        if not os.path.exists(os.path.join(out, 'current_board_tf.json')):
            w.show('Camera calibration failed', 'register_board.py did not finish (see above: a camera missing, '
                   'or the board not fully visible). Fix it, then continue to try again.')
            w.wait()
            continue
        open_images(pngs)
        w.show('Check corner 0 in the three pictures',
               'Three pictures have opened (also saved in ' + out + ').\n'
               'Each shows red numbers 0, 7, 40, 47 on the board corners.\n'
               'Is corner 0 on the SAME physical corner in all three?\n'
               '  - yes: press Enter (or the button)\n'
               '  - no: type the camera(s) where it is on the opposite corner, e.g.  third   or   wrist tripod',
               button='Yes, all the same')
        answer = w.wait('Enter = yes, or type camera names').lower().split()
        wrong = [a for a in answer if a in ('wrist', 'tripod', 'third')]
        if wrong:
            flips = sorted(set(flips) ^ set(wrong))
            print(f'  re-measuring with --flip {" ".join(flips)}')
            continue
        fit = json.load(open(os.path.join(out, 'current_board_tf.json')))
        if not fit.get('passed_stationary_smoke_gate'):
            w.show('Camera calibration not good enough',
                   'The board checks did not pass (numbers above: reprojection, drift, depth). Usually: board not '
                   'flat, partly hidden, glare, or something moved. Fix it, then continue to measure again.')
            w.wait()
            continue
        print(f'  Step A passed: {out}')
        return out


def step_b(w, pitch_mm):
    points = {}
    order = [c for c, _ in CORNERS]
    i = 0
    while i < len(order):
        c = order[i]
        name = dict(CORNERS)[c]
        w.show(f'Calibration 2 of 2: corner {c} ({i + 1} of 4)',
               f'Close the gripper (C). Using the app (keyboard or Etee), move the fingertip SLOWLY onto inner '
               f'corner {c} ({name} in the pictures) until it just touches the paper, or the twin stops it at the '
               f'table.\nLook from the side and from above: the tip must be exactly on the corner.\n'
               f'Then press Capture.', capture=True, button='Capture point')
        typed = w.wait('Enter or the app\'s Capture button = capture this corner; b = go back one corner')
        if typed.lower() == 'b' and i > 0:
            i -= 1
            continue
        tip = w.fingertip()
        if not tip:
            print('  no fingertip position from the twin yet; try again')
            continue
        points[c] = tip
        print(f'  corner {c}: x={tip[0]:.4f} y={tip[1]:.4f} z={tip[2]:.4f}')
        # catch a wrong corner straight away: distances to the corners already captured must match the board
        bad = []
        for o in order[:i]:
            want = corner_distance(c, o) * pitch_mm / 20.0
            got = math.dist(points[c][:2], points[o][:2])
            if abs(got - want) > 0.006:
                bad.append(f'{o}: {got * 1000:.0f} mm apart, should be {want * 1000:.0f} mm')
        if bad:
            w.show('That does not look like the right corner',
                   'Distance check failed (' + '; '.join(bad) + ').\nType r to redo this corner, or press Enter to '
                   'keep it anyway.', button='Keep it')
            if w.wait('r = redo, Enter = keep').lower() == 'r':
                continue
        i += 1
    os.makedirs(SAVE, exist_ok=True)
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    csv = os.path.join(SAVE, f'points_{stamp}.csv')
    with open(csv, 'w') as f:
        f.write('# corner_idx, world_x, world_y, world_z   (fingertip, from calib_wizard.py)\n')
        for c in order:
            f.write(f'{c}, {points[c][0]:.5f}, {points[c][1]:.5f}, {points[c][2]:.5f}\n')
    out = os.path.join(SAVE, f'wp3_table_tf_{stamp}.yaml')
    p = subprocess.run([sys.executable, os.path.join(HERE, 'fit_table_tf.py'), csv, '--pitch-mm', str(pitch_mm),
                        '--out', out], capture_output=True, text=True, cwd=HERE)
    print(p.stdout, p.stderr)
    ok = 'ACCEPT' in p.stdout and os.path.exists(out)
    return ok, out, p.stdout


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--wp3', required=True, help='WP3-Live-Implementation-v2-Three-View folder')
    ap.add_argument('--ref', required=True, help='board orientation reference JSON')
    ap.add_argument('--pitch-mm', type=float, default=20.0)
    ap.add_argument('--skip-a', default=None, help='use this Step A folder and only do Step B')
    args = ap.parse_args()
    rclpy.init()
    w = Wizard()
    threading.Thread(target=rclpy.spin, args=(w,), daemon=True).start()
    time.sleep(1.0)
    try:
        cal = args.skip_a or step_a(w, args.wp3, args.ref)
        while True:
            ok, out, report = step_b(w, args.pitch_mm)
            if ok:
                break
            w.show('Table calibration not good enough',
                   'The four corners do not fit well (see the residuals above: RMS must be < 3 mm, every point '
                   '< 5 mm). Usually one corner was touched in the wrong place. Continue to touch all four again.')
            w.wait()
        final = os.path.join(SAVE, 'wp3_table_tf.yaml')
        shutil.copy(out, final)
        shutil.copy(out, os.path.join(HERE, 'wp3_table_tf.yaml'))
        w.show('Calibration done',
               'Both calibrations passed and are saved. The arm goes back to its home pose (where the wrist camera '
               'was calibrated); keep it there while perception is running. You can remove the checkerboard now.',
               button='Start perception')
        w.home_pub.publish(String(data='go'))
        w.wait()
        w.clear()
        os.makedirs(SAVE, exist_ok=True)
        open(os.path.join(SAVE, 'last_camera_cal.txt'), 'w').write(cal + '\n')
        return 0
    except KeyboardInterrupt:
        w.clear()
        return 1
    finally:
        w.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    sys.exit(main())
