#!/usr/bin/env python3
"""Records /joint_states for a few seconds and reports whether the arm REALLY jumps (not just RViz drawing).

  python3 joint_watch.py            then, within 3 s, tap the pad (with etee_hold.py running in another window)
Prints a timeline of the biggest joint change per sample. A jump shows as a big number in one or two rows.
"""
import sys, time
import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState


class W(Node):
    def __init__(self):
        super().__init__('joint_watch')
        self.rows, self.last = [], None
        self.create_subscription(JointState, '/joint_states', self.cb, 50)

    def cb(self, m):
        pos = dict(zip(m.name, m.position))
        names = [n for n in pos if n.startswith('joint') and n[5:].isdigit()]
        q = np.array([pos[n] for n in sorted(names)])
        t = time.monotonic()
        if self.last is not None:
            self.rows.append((t, float(np.max(np.abs(q - self.last[1]))), t - self.last[0], q.copy()))
        self.last = (t, q)


rclpy.init()
n = W()
dur = float(sys.argv[1]) if len(sys.argv) > 1 else 8.0
print(f'Recording {dur:.0f} s. Tap the pad now (etee_hold.py must be running and armed)...')
end = time.monotonic() + dur
while time.monotonic() < end:
    rclpy.spin_once(n, timeout_sec=0.05)
rows = n.rows
if not rows:
    print('No /joint_states received. Is the simulation running and sourced in this terminal?')
else:
    t0 = rows[0][0]
    steps = np.array([r[1] for r in rows])
    moving = [(r[0] - t0, r[1], r[2]) for r in rows if r[1] > 1e-4]
    print(f'{len(rows)} samples, about {len(rows) / dur:.0f}/s. Biggest single-sample joint change: {steps.max():.4f} rad')
    if moving:
        print('time(s)  change(rad)  gap(s)   (only samples where the arm moved)')
        for t, c, g in moving[:60]:
            print(f'{t:6.2f}  {c:10.4f}  {g:6.3f}' + ('   <-- JUMP' if c > 0.02 else ''))
        print('A jump means the joints really jumped. No jump means the swing was only drawn by RViz.')
    else:
        print('The arm never moved while recording.')
n.destroy_node(); rclpy.shutdown()
