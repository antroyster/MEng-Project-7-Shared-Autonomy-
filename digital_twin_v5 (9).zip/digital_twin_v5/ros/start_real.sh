#!/usr/bin/env bash
# REAL ARM, terminal 1. Connects to the arm, opens MoveIt + RViz (shows the real pose), builds the scene.
#   bash start_real.sh          Ctrl+C stops everything.
ARM_IP=192.168.1.214
WS=~/xarm_ws
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

source /opt/ros/jazzy/setup.bash
source $WS/install/setup.bash

if ros2 node list 2>/dev/null | grep -q move_group; then
  echo "A MoveIt launch is already running. Stop it first (Ctrl+C there, or: pkill -f ros2; wsl --shutdown from PowerShell)."; exit 1
fi
echo "Checking the arm at $ARM_IP ..."
if ! ping -c 1 -W 2 $ARM_IP > /dev/null 2>&1; then
  echo "Cannot reach $ARM_IP. Check the Ethernet cable, control box power, and the laptop static IP 192.168.1.10."; exit 1
fi

ros2 launch xarm_moveit_config xarm6_moveit_realmove.launch.py robot_ip:=$ARM_IP add_gripper:=true &
LAUNCH_PID=$!
trap 'kill $LAUNCH_PID 2>/dev/null; wait $LAUNCH_PID 2>/dev/null' EXIT INT TERM

echo "Waiting for MoveIt ..."
for i in $(seq 1 90); do
  ros2 service list 2>/dev/null | grep -q "^/get_planning_scene$" && ros2 topic list 2>/dev/null | grep -q "^/joint_states$" && break
  sleep 1
done
sleep 5
cd "$HERE" && python3 build_scene.py
echo "Scene loaded. Leave this terminal running. Other terminals: etee_bridge.py, then etee_hold.py (see RUNBOOK.md)."
wait $LAUNCH_PID
