#!/usr/bin/env python3
"""Add the wrist RealSense D435i and its bracket to the arm MODEL (run AFTER add_extension.py).

  python3 add_camera.py                              edits the files in ~/xarm_ws/src/xarm_ros2 (makes .cam.bak copies first)
  python3 add_camera.py --undo                       restores the .cam.bak copies (the tool extension stays)
  python3 add_camera.py --camera-name wrist_camera   must match the RealSense driver's camera_name (frame = <name>_link)
  python3 add_camera.py --xyz 0.0675 -0.0175 0.0207 --rpy 3.14159 -1.5708 0   override with the hand-eye result

Where the numbers come from: the CAD assembly 'UFACTORY xArm 6 & RealSense D435i CAD Assembly.html'.
  Stack along the tool axis, flange first: tool extension (Hazem's measured 7 cm, read from the URDF) -> 4 mm bracket plate
  -> gripper. The bracket tab carries the D435i beside the gripper on the link_eef +x side, lenses pointing along the tool
  axis (down at home), USB end towards link_eef +y.
  Camera body centre 67.5 mm from the tool axis (flange OD 76 mm, 42 mm from the flange edge to the camera's outer edge).
  camera_link = left IR / depth origin, 17.5 mm off the body centre and 4.3 mm behind the glass (realsense2_description).
  This is the NOMINAL CAD pose (unverified on the real arm). Replace it with the measured hand-eye transform when you have one.

What it changes:
  1. xarm_description/urdf/gripper/xarm_gripper.urdf.xacro
       new link 'd435i_bracket' fixed to 'tool_extension' at the gripper end of the extension, and new link
       '<camera-name>_link' (D435i body as a 90 x 25 x 25 mm box, visual + collision) fixed to the bracket.
       The gripper is NOT moved, so TCP_OFFSET_Z in build_scene.py stays 0.242 m.
  2. xarm_moveit_config/srdf/_xarm6_macro.srdf.xacro
       lets the new links touch the wrist, extension and gripper (otherwise MoveIt sees self-collision and refuses to plan).
       They still collide with link1..link4, the table, the walls and the block, so MoveIt now protects the camera.
The RealSense driver publishes <camera-name>_link -> optical frames itself (publish_tf), so only <camera-name>_link is added here.
Then rebuild:  cd ~/xarm_ws && colcon build --packages-select xarm_description xarm_moveit_config && source install/setup.bash
"""
import argparse
import math
import os
import re
import shutil
import sys

WS = os.path.expanduser('~/xarm_ws/src/xarm_ros2')
URDF = os.path.join(WS, 'xarm_description/urdf/gripper/xarm_gripper.urdf.xacro')
SRDF = os.path.join(WS, 'xarm_moveit_config/srdf/_xarm6_macro.srdf.xacro')
MARK = 'd435i_bracket'
BAK = '.cam.bak'

# ---- CAD assembly defaults (mm), same names as the HTML sliders ------------------------------------------
FLANGE_OD = 76.0       # wrist / extension outer diameter
EDGE_DIST = 42.0       # flange edge to the D435i OUTER edge
TAB_WIDTH = 61.0       # bracket tab width
THICKNESS = 4.0        # bracket plate thickness
D435I = (90.0, 25.0, 25.0)   # length, depth (lens axis), height
GLASS_TO_DEPTH_ORIGIN = 4.3  # realsense2_description: zero-depth plane 4.2 mm + glass 0.1 mm behind the front
DEPTH_ORIGIN_OFFSET = 17.5   # left IR (depth origin) from the body centre, towards the camera's left
CAMERA_MASS = 0.072          # kg, Intel datasheet
BRACKET_MASS = 0.03          # kg, 4 mm printed plate (estimate)


def nominal_pose():
    """camera_link pose in the bracket frame (origin on the tool axis at the bracket's gripper-side face, z along the tool)."""
    r = FLANGE_OD / 2
    cam_centre_x = r + EDGE_DIST - D435I[1] / 2              # 67.5 mm
    z = D435I[2] - GLASS_TO_DEPTH_ORIGIN                     # body hangs 25 mm below the face, lenses at +z
    xyz = (cam_centre_x / 1000, -DEPTH_ORIGIN_OFFSET / 1000, z / 1000)
    rpy = (math.pi, -math.pi / 2, 0.0)                       # camera x = tool +z, camera y = link_eef -y, camera z = +x (out)
    return xyz, rpy


def f(v, p=5):
    return ' '.join(f'{x:.{p}g}' for x in v)


def block(cam, ext_len, xyz, rpy):
    r = FLANGE_OD / 2000
    t = THICKNESS / 1000
    tab_end = (FLANGE_OD / 2 + EDGE_DIST - D435I[1] / 2 + 10.0) / 1000   # tab ends 10 mm past the camera centre (CAD)
    L, D, H = (v / 1000 for v in D435I)
    # body centre relative to camera_link along the lens axis: centre is D/2 behind the glass, camera_link 4.3 mm behind it
    body = (-(D / 2 - GLASS_TO_DEPTH_ORIGIN / 1000), -DEPTH_ORIGIN_OFFSET / 1000, 0.0)
    cam_box = f'<box size="{D:g} {L:g} {H:g}"/>'
    return f"""      <!-- {MARK}: wrist RealSense D435i on its bracket (CAD assembly), added by add_camera.py. NOMINAL pose, unverified -->
      <link name="${{prefix}}{MARK}">
        <inertial>
          <origin xyz="{tab_end / 2:.5g} 0 {-t / 2:g}" rpy="0 0 0"/>
          <mass value="{BRACKET_MASS:g}"/>
          <inertia ixx="0.00001" ixy="0" ixz="0" iyy="0.00002" iyz="0" izz="0.00003"/>
        </inertial>
        <visual>
          <origin xyz="0 0 {-t / 2:g}" rpy="0 0 0"/>
          <geometry><cylinder radius="{r:g}" length="{t:g}"/></geometry>
          <material name="${{prefix}}BracketBlack"><color rgba="0.08 0.08 0.09 1"/></material>
        </visual>
        <visual>
          <origin xyz="{tab_end / 2:.5g} 0 {-t / 2:g}" rpy="0 0 0"/>
          <geometry><box size="{tab_end:.5g} {TAB_WIDTH / 1000:g} {t:g}"/></geometry>
          <material name="${{prefix}}BracketBlack"/>
        </visual>
        <collision>
          <origin xyz="{tab_end / 2:.5g} 0 {-t / 2:g}" rpy="0 0 0"/>
          <geometry><box size="{tab_end:.5g} {TAB_WIDTH / 1000:g} {t:g}"/></geometry>
        </collision>
      </link>
      <joint name="${{prefix}}{MARK}_fix" type="fixed">
        <parent link="${{prefix}}tool_extension"/>
        <child link="${{prefix}}{MARK}"/>
        <origin xyz="0 0 {ext_len:g}" rpy="0 0 0"/>
      </joint>
      <link name="${{prefix}}{cam}_link">
        <inertial>
          <origin xyz="{f(body)}" rpy="0 0 0"/>
          <mass value="{CAMERA_MASS:g}"/>
          <inertia ixx="0.00005" ixy="0" ixz="0" iyy="0.00001" iyz="0" izz="0.00005"/>
        </inertial>
        <visual>
          <origin xyz="{f(body)}" rpy="0 0 0"/>
          <geometry>{cam_box}</geometry>
          <material name="${{prefix}}RealSenseSilver"><color rgba="0.72 0.73 0.76 1"/></material>
        </visual>
        <collision>
          <origin xyz="{f(body)}" rpy="0 0 0"/>
          <geometry>{cam_box}</geometry>
        </collision>
      </link>
      <joint name="${{prefix}}{cam}_mount_joint" type="fixed">
        <parent link="${{prefix}}{MARK}"/>
        <child link="${{prefix}}{cam}_link"/>
        <origin xyz="{f(xyz)}" rpy="{f(rpy, 7)}"/>
      </joint>
"""


NEIGHBOURS = ['link5', 'link6', 'link_eef', 'tool_extension', 'xarm_gripper_base_link',
              'left_outer_knuckle', 'left_inner_knuckle', 'left_finger',
              'right_outer_knuckle', 'right_inner_knuckle', 'right_finger']


def backup(path):
    if not os.path.exists(path + BAK):
        shutil.copy2(path, path + BAK)


def extension_length(s):
    """Length of Hazem's tool extension, read from the gripper_fix joint that add_extension.py wrote."""
    m = re.search(r'<joint name="\$\{prefix\}gripper_fix" type="fixed">\s*<parent link="\$\{prefix\}tool_extension"/>'
                  r'\s*<child link="\$\{prefix\}xarm_gripper_base_link"/>\s*<origin xyz="0 0 ([0-9.eE+-]+)"', s)
    return float(m.group(1)) if m else None


def edit_urdf(cam, xyz, rpy):
    s = open(URDF).read()
    if MARK in s:
        print('URDF already has the camera, skipping (use --undo first to change it).'); return True
    ext = extension_length(s)
    if ext is None:
        print('No tool_extension in', URDF, '- run  python3 add_extension.py  first. Nothing was changed.'); return False
    anchor = '      <joint name="${prefix}gripper_fix" type="fixed">'
    if s.count(anchor) != 1:
        print('Could not find the gripper_fix joint exactly once in', URDF, '- nothing was changed.'); return False
    backup(URDF)
    open(URDF, 'w').write(s.replace(anchor, block(cam, ext, xyz, rpy) + anchor))
    print(f'URDF edited: {URDF}\n  bracket at {ext * 1000:g} mm from the flange, {cam}_link xyz={f(xyz)} rpy={f(rpy)} (bracket frame)')
    return True


def edit_srdf(cam):
    s = open(SRDF).read()
    if MARK in s:
        print('SRDF already has the camera, skipping.'); return True
    lines = s.split('\n')
    idx = next((i for i, ln in enumerate(lines) if 'disable_collisions' in ln and 'tool_extension' in ln), None)
    if idx is None:
        print('No tool_extension lines in', SRDF, '- run add_extension.py first. Nothing was changed in the SRDF.'); return False
    while idx + 1 < len(lines) and 'tool_extension' in lines[idx + 1]:
        idx += 1                                             # after the last tool_extension line
    indent = re.match(r'\s*', lines[idx]).group(0)
    add = [indent + f'<disable_collisions link1="${{prefix}}{MARK}" link2="${{prefix}}{cam}_link" reason="Adjacent"/>']
    for new in (MARK, f'{cam}_link'):
        add += [indent + f'<disable_collisions link1="${{prefix}}{new}" link2="${{prefix}}{n}" reason="Adjacent"/>'
                for n in NEIGHBOURS]
    backup(SRDF)
    lines[idx + 1:idx + 1] = add
    open(SRDF, 'w').write('\n'.join(lines))
    print('SRDF edited:', SRDF); return True


def undo():
    for p in (URDF, SRDF):
        if os.path.exists(p + BAK):
            shutil.copy2(p + BAK, p); os.remove(p + BAK); print('restored', p)
        else:
            print('no camera backup for', p)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--undo', action='store_true')
    ap.add_argument('--camera-name', default='wrist_camera', help='RealSense camera_name; the link is <name>_link')
    ap.add_argument('--xyz', type=float, nargs=3, help='camera_link position in the bracket frame (m)')
    ap.add_argument('--rpy', type=float, nargs=3, help='camera_link orientation in the bracket frame (rad)')
    a = ap.parse_args()
    if a.undo:
        undo(); return 0
    for p in (URDF, SRDF):
        if not os.path.exists(p):
            print('missing file:', p); return 1
    xyz, rpy = nominal_pose()
    xyz, rpy = tuple(a.xyz or xyz), tuple(a.rpy or rpy)
    ok = edit_urdf(a.camera_name, xyz, rpy) and edit_srdf(a.camera_name)
    if ok:
        print('\nNow rebuild:\n  cd ~/xarm_ws && colcon build --packages-select xarm_description xarm_moveit_config && source install/setup.bash'
              f'\nStart the wrist camera with  camera_name:={a.camera_name}  so its TF hangs off {a.camera_name}_link.')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
