#!/usr/bin/env python3
"""Send the arm back to the real 'home' pose (the joint angles read from your arm, not the all-zeros SRDF pose).

  python3 go_home.py                 plan and run a joint-space move to home
  python3 go_home.py --scale 0.05    slower (use this on the real arm)
  python3 go_home.py --open-gripper  also open the gripper afterwards

Needs MoveIt running and pick_place_sim.py in the same folder. MoveIt will only plan to a
pose that does not collide with the scene, so if the scene thinks home is inside the table
(wrong Z_FLOOR in build_scene.py, or wrong TCP_OFFSET_Z), this refuses. Fix the numbers first.
"""
import argparse
import sys

import rclpy
from moveit_msgs.msg import Constraints, JointConstraint

import pick_place_sim as pp

# The real arm's home pose, read from /xarm/joint_states (radians). NOT the all-zeros SRDF 'home'.
HOME_Q = [-0.0086, -0.9809, -0.9284, 0.0141, 1.9111, -0.0140]
HOME = {f'joint{i}': q for i, q in enumerate(HOME_Q, start=1)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--scale', type=float, default=pp.SCALE, help='speed scaling 0-1')
    ap.add_argument('--open-gripper', action='store_true')
    args = ap.parse_args()
    pp.SCALE = args.scale

    rclpy.init()
    node = pp.PickPlace()
    print(f'Moving to the real home pose at speed scaling {pp.SCALE}.')
    print('Real arm: supervisor present, E-stop in reach, area clear.')
    if input('Type YES to continue: ').strip() != 'YES':
        node.destroy_node(); rclpy.shutdown(); return 1

    req = node.base_request(pp.ARM_GROUP)
    c = Constraints()
    for name, value in HOME.items():
        c.joint_constraints.append(JointConstraint(
            joint_name=name, position=value, tolerance_above=0.005, tolerance_below=0.005, weight=1.0))
    req.goal_constraints.append(c)
    ok = node.plan_and_execute(req)
    if ok and args.open_gripper:
        ok = node.gripper(pp.GRIP_OPEN)
    print('At home.' if ok else 'Could not get to home (see the error above).')
    node.destroy_node()
    rclpy.shutdown()
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
