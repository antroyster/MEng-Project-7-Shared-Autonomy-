#!/usr/bin/env python3
"""WP2 2.3.1: is the twin really connected to the real xArm? Run it after start_real.sh, BEFORE moving anything.

  python3 check_real_arm.py            diagnose only (never moves the arm)
  python3 check_real_arm.py --fix      also clear errors and re-enable the motors (asks YES first), then
                                       tells you to restart start_real.sh

What it checks, in order:
  1. the control box answers on the network (ping 192.168.1.214)
  2. the xArm driver is running and publishes the controller's own state (/xarm/robot_states)
  3. the controller state: error code, warning code, motors enabled, mode and state
  4. /joint_states is fresh AND not all zeros (all zeros = the twin is showing a default pose, not the real arm)
  5. the twin's joint angles agree with the controller's own joint angles
"""
import argparse
import math
import subprocess
import sys
import time

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState

ROBOT_IP = '192.168.1.214'
STATE_NAMES = {1: 'moving', 2: 'ready (sleeping)', 3: 'paused', 4: 'stopped', 5: 'stopped'}
MODE_NAMES = {0: 'position', 1: 'servo (needed by ROS control)', 2: 'joint teaching (free drive)', 4: 'joint velocity',
              5: 'cartesian velocity'}


def ok(text):
    print(f'  OK    {text}')


def bad(text):
    print(f'  FAIL  {text}')


def info(text):
    print(f'        {text}')


class Checker(Node):
    def __init__(self):
        super().__init__('check_real_arm')
        self.js = None
        self.js_t = None
        self.rs = None
        self.create_subscription(JointState, '/joint_states', self.on_js, 10)

    def on_js(self, msg):
        self.js, self.js_t = msg, time.monotonic()

    def find_robot_states(self):
        for name, types in self.get_topic_names_and_types():
            if any(t == 'xarm_msgs/msg/RobotMsg' for t in types):
                return name
        return None

    def wait_for(self, attr, seconds):
        end = time.monotonic() + seconds
        while time.monotonic() < end and getattr(self, attr) is None:
            rclpy.spin_once(self, timeout_sec=0.1)
        return getattr(self, attr)


def call(service, srv_type, request='{}'):
    cmd = ['ros2', 'service', 'call', service, srv_type, request]
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
    except subprocess.TimeoutExpired:
        return False, 'timed out'
    text = (out.stdout + out.stderr).strip().splitlines()
    return out.returncode == 0, text[-1] if text else ''


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--fix', action='store_true', help='clear errors and enable the motors (asks first)')
    ap.add_argument('--ns', default='/xarm', help='driver namespace (default /xarm)')
    args = ap.parse_args()
    problems = 0

    print('1. Network')
    r = subprocess.run(['ping', '-c', '2', '-W', '1', ROBOT_IP], capture_output=True, text=True)
    if r.returncode == 0:
        ok(f'{ROBOT_IP} answers')
    else:
        bad(f'{ROBOT_IP} does not answer: check the Ethernet cable, the control box power and the laptop IP '
            '(192.168.1.10 / 255.255.255.0)')
        sys.exit(1)

    rclpy.init()
    node = Checker()
    for _ in range(20):
        rclpy.spin_once(node, timeout_sec=0.1)

    print('2. Driver')
    topic = node.find_robot_states()
    if topic is None:
        bad('no xarm_msgs/RobotMsg topic: the xArm driver is not running or not connected. '
            'Look in the start_real.sh window for "connect" or "error" lines.')
        problems += 1
    else:
        ok(f'driver publishes {topic}')
        from rosidl_runtime_py.utilities import get_message
        node.create_subscription(get_message('xarm_msgs/msg/RobotMsg'), topic, lambda m: setattr(node, 'rs', m), 10)
        rs = node.wait_for('rs', 3.0)
        print('3. Controller state')
        if rs is None:
            bad(f'{topic} exists but nothing arrives')
            problems += 1
        else:
            err, warn = int(getattr(rs, 'err', 0)), int(getattr(rs, 'warn', 0))
            state, mode = int(getattr(rs, 'state', -1)), int(getattr(rs, 'mode', -1))
            raw = getattr(rs, 'mt_able', None)
            if isinstance(raw, int):                   # a bitmask: bit i = joint i+1 enabled
                able = [bool(raw >> i & 1) for i in range(6)]
            else:
                able = list(raw or [])
            (ok if err == 0 else bad)(f'error code {err}' + ('' if err == 0 else
                ' : clear it (--fix, or UFactory Studio), and look the code up in the xArm manual'))
            (ok if warn == 0 else info)(f'warning code {warn}')
            (ok if state in (1, 2) else bad)(f'state {state} ({STATE_NAMES.get(state, "unknown")})')
            (ok if mode == 1 else bad)(f'mode {mode} ({MODE_NAMES.get(mode, "unknown")})' +
                                      ('' if mode == 1 else ': ROS control needs mode 1; restart start_real.sh after --fix'))
            if able:
                (ok if all(able[:6]) else bad)('motors enabled: ' + ' '.join(f'J{i + 1}:{"on" if v else "OFF"}' for i, v in enumerate(able[:6])))
            problems += (err != 0) + (state not in (1, 2)) + (mode != 1) + (bool(able) and not all(able[:6]))
            angle = list(getattr(rs, 'angle', []))

    print('4. Joint states (what the twin shows)')
    js = node.wait_for('js', 3.0)
    if js is None:
        bad('no /joint_states at all')
        problems += 1
    else:
        pos = dict(zip(js.name, js.position))
        arm = [pos.get(f'joint{i}', float('nan')) for i in range(1, 7)]
        t0 = node.js_t
        n0 = 0
        while time.monotonic() - t0 < 1.0:
            rclpy.spin_once(node, timeout_sec=0.05)
            n0 += 1
        info('joints (rad): ' + ', '.join(f'{v:+.3f}' for v in arm))
        if all(abs(v) < 1e-6 for v in arm):
            bad('ALL ZERO: the twin is not getting the real arm. Usually the controller is in error, the motors are '
                'off, or UFactory Studio holds the connection. Fix step 3, close Studio, restart start_real.sh.')
            problems += 1
        else:
            ok('joint angles are live values')
        if topic is not None and node.rs is not None and angle:
            diff = max(abs(a - b) for a, b in zip(arm, angle[:6]))
            (ok if diff < 0.01 else bad)(f'twin vs controller joint angles differ by at most {math.degrees(diff):.2f} deg')
            problems += diff >= 0.01

    if args.fix:
        print('\nFIX: clears errors and switches the motors ON (the arm will hold its pose; it will not move).')
        if input('Supervisor present, E-stop in reach? Type YES: ').strip() != 'YES':
            print('Not changed.')
        else:
            ns = args.ns.rstrip('/')
            for service, srv_type, req in ((f'{ns}/clean_error', 'xarm_msgs/srv/Call', '{}'),
                                           (f'{ns}/clean_warn', 'xarm_msgs/srv/Call', '{}'),
                                           (f'{ns}/motion_enable', 'xarm_msgs/srv/SetInt16ById', '{id: 8, data: 1}'),
                                           (f'{ns}/set_mode', 'xarm_msgs/srv/SetInt16', '{data: 1}'),
                                           (f'{ns}/set_state', 'xarm_msgs/srv/SetInt16', '{data: 0}')):
                good, last = call(service, srv_type, req)
                (ok if good else bad)(f'{service}: {last}')
            print('Now Ctrl+C start_real.sh, start it again, and rerun this check.')

    print('\nRESULT:', 'twin is connected to the real arm' if problems == 0 else f'{problems} problem(s), see FAIL lines')
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
