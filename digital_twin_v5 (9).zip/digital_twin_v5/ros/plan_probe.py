#!/usr/bin/env python3
"""Asks MoveIt to plan each of the six jog directions from where the arm is NOW, and says why any fail.
The arm NEVER moves. MoveIt (start_sim.sh or start_real.sh) must be running; the Etee is not needed.

  source /opt/ros/jazzy/setup.bash; source ~/xarm_ws/install/setup.bash
  cd <repo>/digital_twin/ros && python3 plan_probe.py
"""
import types

import rclpy

import etee_hold as eh


def main():
    rclpy.init()
    args = types.SimpleNamespace(speed=0.02, dry_run=True, settle=0.1, flip_x=False, flip_y=False, flip_z=False,
                                 max_step=eh.MAX_STEP, deadzone=0.3, curve=1.6, analog=False)
    node = eh.EteeHold(args)
    for _ in range(40):                                  # let TF and /joint_states arrive
        rclpy.spin_once(node, timeout_sec=0.05)
    p = node.pose_key()
    print(f'\nFingertips now: x={p[0]:.3f} y={p[1]:.3f}' if p else '\nNo TF yet')
    tip = node.tip_now()
    if tip:
        print(f'Fingertip height z={tip.position.z - eh.pp.TCP_OFFSET_Z:.3f}   '
              f'limits x {eh.LIMITS["x"]}, y {eh.LIMITS["y"]}, z_max {eh.LIMITS["z_max"]}\n')
    names = ['FORWARD', 'BACK', 'LEFT', 'RIGHT', 'UP', 'DOWN']
    for name, d in zip(names, node.AXES):
        sol, reason = node.plan(d)
        i = node.info
        extra = (f"  [fraction {i.get('fraction', 0) * 100:.0f}%, {i.get('points', 0)} points, "
                 f"biggest joint step {i.get('joint_step', float('nan')):.3f} rad]") if i else ''
        print(f'{name:8s} ' + ('OK' if sol is not None else 'FAILS: ' + reason) + extra)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
