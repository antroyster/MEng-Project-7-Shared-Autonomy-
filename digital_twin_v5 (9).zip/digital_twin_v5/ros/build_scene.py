#!/usr/bin/env python3
"""Build the ENGR7001 test environment in MoveIt's planning scene.

Adds the table, robot base plate, controller (power) box and the Jenga block, plus an
optional 'safety floor' that stops any plan taking the arm below the table-top height.

FRAME AND AXES (check against the TF display in RViz before trusting the numbers):
  origin = centre of the robot base on its mounting plane (link_base)
  +x = along the 1.40 m table length, away from the robot's edge
  +y = robot's left, +z = up.   All lengths in metres.

Run with MoveIt already running (the real-arm launch):
  python3 build_scene.py
"""
import rclpy
from geometry_msgs.msg import Pose
from moveit_msgs.msg import (AllowedCollisionEntry, CollisionObject, ObjectColor,
                             PlanningScene, PlanningSceneComponents)
from moveit_msgs.srv import ApplyPlanningScene, GetPlanningScene
from rclpy.node import Node
from shape_msgs.msg import SolidPrimitive
from std_msgs.msg import ColorRGBA

# ------------------------------------------------------------------ EDIT THESE
FRAME = 'world'            # the Planning Frame shown in RViz > MotionPlanning > Context

BASE_PLATE = (0.14, 0.18, 0.008)   # x (length), y (width), z (thickness = 8 mm measured clamp plate),
                                   # directly under the robot's base plane (z = 0)

# --- The table height is tied to the HOME pose, so home never collides with the table ---
HOME_FLANGE_Z = 0.112      # flange height at home (all joints 0); matches what RViz/teach_keyboard show
GRIPPER_LEN = 0.172        # flange to fingertips for the bare xArm gripper (m), as in the URDF
EXTENSION_LEN = 0.07       # flange-to-gripper cylinder (~7 cm); closed-gripper tool length 242 mm confirmed to ~2 mm by the coin test, 24 Nov
FINGERTIP_CLOSED = 0.238   # flange to real fingertips, gripper CLOSED (coin test 24 Nov: 2.8 mm gap where the 242 mm model read -1 mm)
FINGERTIP_OPEN = 0.224     # gripper fully OPEN: the fingertips rise ~14 mm (coin test 24 Nov: 16 mm gap)
TCP_OFFSET_Z = FINGERTIP_CLOSED   # flange to fingertips used by tools that do not track the gripper (GRIPPER_LEN + EXTENSION_LEN = 0.242 nominal)
HOME_FINGER_GAP = 0.05     # MEASURE THIS: with the arm at home, the vertical gap (m) from the fingertips
                           # straight down to the table surface. 0.05 is a PLACEHOLDER.
HOME_FINGER_GAP_MEASURED = True    # set to True once HOME_FINGER_GAP is a real measurement
Z_FLOOR = -BASE_PLATE[2]   # table top = underside of the base plate (the plate sits flat on the table). Real geometry, not a guess.
Z_MARGIN = 0.001           # modelled table top this far above the real surface (v4: was 3 mm)

TABLE_LEN, TABLE_WID = 1.40, 0.70   # x, y
TABLE_THICK = 0.02         # 2 cm table top
TABLE_H = 0.80             # floor to table top
TABLE_SOLID = True         # True: model everything under the top as solid (nothing should go there);
                           # False: model only the 2 cm top slab
BASE_INSET = 0.07          # base centre to the short table edge it is clamped to (= half the plate length)
Y_OFFSET = 0.0             # table centre line relative to the robot (0 = robot centred on the 70 cm edge)

POWER_BOX = (0.29, 0.14, 0.11)     # length along x, width along y, height
POWER_BOX_XY = (0.25, -0.26)       # PLACEHOLDER: centre of the power box on the table. MEASURE IT.
JENGA = (0.045, 0.045, 0.04)      # the test block: 4.5 x 4.5 cm footprint, 4 cm tall (id stays 'jenga_block')
JENGA_XY = (0.26, 0.0)             # block centre: 26 cm out from the base centre, on the gripper's centre line (y = 0)

FLOOR_GUARD = True         # big slab at table-top height; stops the arm dipping below it beside the table
FLOOR_GUARD_SIZE = 3.0     # metres, square
FLOOR_EXEMPT_LINKS = []    # links allowed to sit below the table-top height. Your original script used
                           # ['link_base', 'link1', 'link2'] because in that setup they were below it.
MOUNT_EXEMPT_LINKS = ['link_base']   # links allowed to touch the table and base plate at the mount

# --- Keep-in boundary around the table: invisible walls the arm may not cross -----------------------------
FENCE = True               # True: add red see-through walls along the table edges (collision objects)
FENCE_MARGIN = 0.04        # wall sits this far INSIDE the table edge (m)
FENCE_HEIGHT = 0.60        # wall height above the table (m)
FENCE_THICK = 0.01         # wall thickness (m)
GRIPPER_RADIUS = 0.05      # half-width of the gripper + extension: the fingertips stay this far inside the walls
# Colours as (red, green, blue, alpha), each 0.0 to 1.0. Alpha 1.0 = solid, lower = see-through.
COLOURS = {
    'table':        (0.55, 0.35, 0.17, 1.00),   # brown
    'base_plate':   (0.65, 0.65, 0.72, 1.00),   # steel grey
    'power_box':    (0.90, 0.15, 0.15, 1.00),   # red
    'jenga_block':  (1.00, 0.85, 0.00, 1.00),   # yellow
    'safety_floor': (0.20, 0.45, 0.95, 0.12),   # faint blue, mostly see-through
    'fence_left':   (0.95, 0.20, 0.20, 0.18),   # faint red walls round the table
    'fence_right':  (0.95, 0.20, 0.20, 0.18),
    'fence_far':    (0.95, 0.20, 0.20, 0.18),
}
# ----------------------------------------------------------------------------


def fence_rect():
    """Walls' keep-in rectangle (xmin, xmax, ymin, ymax) in the robot frame: the table footprint pulled in by FENCE_MARGIN."""
    x0, x1 = -BASE_INSET, TABLE_LEN - BASE_INSET
    return (x0 + FENCE_MARGIN, x1 - FENCE_MARGIN,
            Y_OFFSET - TABLE_WID / 2.0 + FENCE_MARGIN, Y_OFFSET + TABLE_WID / 2.0 - FENCE_MARGIN)


def fence_limits():
    """Where the FINGERTIPS may go (xmin, xmax, ymin, ymax): the walls pulled in by the gripper half-width.
    The wall on the robot's own short edge is not built (the base is clamped there), x min is the reach limit."""
    xmin, xmax, ymin, ymax = fence_rect()
    g = GRIPPER_RADIUS
    return (xmin + g, xmax - g, ymin + g, ymax - g)


def scene_boxes():
    """Return (id, size_xyz, centre_xyz, links_allowed_to_touch) for every box."""
    tx = TABLE_LEN / 2.0 - BASE_INSET                     # table centre x
    top = Z_FLOOR + Z_MARGIN                              # modelled table-top height
    table_h = TABLE_H if TABLE_SOLID else TABLE_THICK
    boxes = [
        ('table', (TABLE_LEN, TABLE_WID, table_h),
         (tx, Y_OFFSET, top - table_h / 2.0), MOUNT_EXEMPT_LINKS),
        ('base_plate', BASE_PLATE,
         (0.0, 0.0, -BASE_PLATE[2] / 2.0), MOUNT_EXEMPT_LINKS),
        ('power_box', POWER_BOX,
         (POWER_BOX_XY[0], POWER_BOX_XY[1], Z_FLOOR + POWER_BOX[2] / 2.0), []),
        ('jenga_block', JENGA,
         (JENGA_XY[0], JENGA_XY[1], Z_FLOOR + JENGA[2] / 2.0), []),
    ]
    if FENCE:
        xmin, xmax, ymin, ymax = fence_rect()
        zc = Z_FLOOR + FENCE_HEIGHT / 2.0
        t = FENCE_THICK
        boxes += [
            ('fence_left',  (xmax - xmin, t, FENCE_HEIGHT), ((xmin + xmax) / 2.0, ymax + t / 2.0, zc), []),
            ('fence_right', (xmax - xmin, t, FENCE_HEIGHT), ((xmin + xmax) / 2.0, ymin - t / 2.0, zc), []),
            ('fence_far',   (t, ymax - ymin, FENCE_HEIGHT), (xmax + t / 2.0, (ymin + ymax) / 2.0, zc), []),
        ]
    if FLOOR_GUARD:
        thick = 1.0
        boxes.append(('safety_floor', (FLOOR_GUARD_SIZE, FLOOR_GUARD_SIZE, thick),
                      (tx, Y_OFFSET, top - thick / 2.0), FLOOR_EXEMPT_LINKS))
    return boxes


def set_acm_entries(acm, allowed):
    """allowed = {object_id: [robot links that may touch it]}. True in the matrix = collision allowed."""
    for oid in allowed:                                   # drop old rows/columns for our ids
        if oid in acm.entry_names:
            i = acm.entry_names.index(oid)
            for row in acm.entry_values:
                del row.enabled[i]
            del acm.entry_values[i]
            del acm.entry_names[i]
    for oid, links in allowed.items():                    # append fresh ones
        for name, row in zip(acm.entry_names, acm.entry_values):
            row.enabled.append(name in links)
        acm.entry_names.append(oid)
        acm.entry_values.append(AllowedCollisionEntry(
            enabled=[name in links for name in acm.entry_names[:-1]] + [False]))
    return acm


def add_acm_pairs(acm, obj, links):
    """Allow obj to touch each of links, KEEPING everything obj may already touch (set_acm_entries replaces a row)."""
    if obj not in acm.entry_names:
        return set_acm_entries(acm, {obj: list(links)})
    i = acm.entry_names.index(obj)
    for j, name in enumerate(acm.entry_names):
        if name in links:
            acm.entry_values[i].enabled[j] = True
            acm.entry_values[j].enabled[i] = True
    missing = [l for l in links if l not in acm.entry_names]
    for link in missing:                                   # a link with no row yet: add one, allowed only with obj
        for row in acm.entry_values:
            row.enabled.append(False)
        acm.entry_names.append(link)
        acm.entry_values.append(AllowedCollisionEntry(enabled=[False] * len(acm.entry_names)))
        k = len(acm.entry_names) - 1
        acm.entry_values[i].enabled[k] = True
        acm.entry_values[k].enabled[i] = True
    return acm


class SceneBuilder(Node):
    def __init__(self):
        super().__init__('scene_builder')
        self.get_scene = self.create_client(GetPlanningScene, '/get_planning_scene')
        self.apply_scene = self.create_client(ApplyPlanningScene, '/apply_planning_scene')

    def call(self, client, request):
        while not client.wait_for_service(timeout_sec=2.0):
            self.get_logger().info(f'waiting for {client.srv_name} (is move_group up?)')
        future = client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
        return future.result()

    @staticmethod
    def make_object(oid, size, centre):
        pose = Pose()
        pose.position.x, pose.position.y, pose.position.z = centre
        pose.orientation.w = 1.0
        obj = CollisionObject(id=oid, operation=CollisionObject.ADD)
        obj.header.frame_id = FRAME
        obj.primitives.append(SolidPrimitive(type=SolidPrimitive.BOX, dimensions=list(size)))
        obj.primitive_poses.append(pose)
        return obj

    def run(self):
        req = GetPlanningScene.Request()
        req.components.components = PlanningSceneComponents.ALLOWED_COLLISION_MATRIX
        acm = self.call(self.get_scene, req).scene.allowed_collision_matrix

        scene = PlanningScene(is_diff=True)
        allowed = {}
        for oid, size, centre, links in scene_boxes():
            scene.world.collision_objects.append(self.make_object(oid, size, centre))
            allowed[oid] = links
        scene.allowed_collision_matrix = set_acm_entries(acm, allowed)
        for oid, (red, green, blue, alpha) in COLOURS.items():
            scene.object_colors.append(ObjectColor(
                id=oid, color=ColorRGBA(r=red, g=green, b=blue, a=alpha)))

        ok = self.call(self.apply_scene, ApplyPlanningScene.Request(scene=scene)).success
        if ok:
            self.get_logger().info(
                f'Scene applied ({len(allowed)} objects). Model table top at '
                f'z = {Z_FLOOR + Z_MARGIN:.3f} m in "{FRAME}" '
                f'({Z_MARGIN * 1000:.0f} mm above the real surface).')
            if not HOME_FINGER_GAP_MEASURED:
                self.get_logger().warn(
                    'HOME_FINGER_GAP is still the 5 cm placeholder, so the table height is a guess. '
                    'Fine for simulation. Measure it before using the real arm.')
        else:
            self.get_logger().error('move_group rejected the scene update')
        return ok


def main():
    rclpy.init()
    node = SceneBuilder()
    ok = node.run()
    node.destroy_node()
    rclpy.shutdown()
    raise SystemExit(0 if ok else 1)


if __name__ == '__main__':
    main()
