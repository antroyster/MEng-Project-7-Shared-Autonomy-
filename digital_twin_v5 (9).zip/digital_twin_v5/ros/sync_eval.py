#!/usr/bin/env python3
"""WP2 2.3.3: synchronisation evaluation of the twin against the real xArm (latency and pose accuracy).
Results are saved as CSV in ~/wp2_sync_results/ for the report.

  python3 sync_eval.py rate               10 s, never moves: joint-state rate, jitter and message age
  python3 sync_eval.py step --trials 10   (stop etee_hold.py first) moves joint 6 by 0.03 rad (1.7 deg) and back, 10 times:
                                          time from command to the first measured motion
  python3 sync_eval.py pose               you jog the arm to each test pose (etee_hold.py) and press Enter:
                                          twin fingertip vs the controller's own pose, and vs a hand
                                          measurement you type in (ruler / checkerboard corner), in mm

METRICS (definitions for the report)
  update rate      messages per second on /joint_states; jitter = standard deviation of the gap between them
  message age      receive time minus header stamp (same PC clock): delay inside ROS
  command latency  send time of a trajectory goal to the first /joint_states sample 0.002 rad away from the
                   start; also given with the planned ramp time removed (the arm cannot move faster than the
                   trajectory asks), which isolates the communication + controller delay
  model error      |twin TCP - controller TCP| in mm: does the twin's kinematic model (URDF, offsets) match the
                   controller's own forward kinematics
  physical error   |twin fingertip - measured fingertip| in mm: does the twin match the real world
                   (includes the 7 cm extension, base plate and table calibration)
"""
import argparse
import csv
import math
import os
import statistics as st
import time

import numpy as np
import rclpy
from control_msgs.action import FollowJointTrajectory
from rclpy.action import ActionClient, get_action_names_and_types
from rclpy.node import Node
from rclpy.time import Time
from sensor_msgs.msg import JointState
from tf2_ros import Buffer, TransformListener
from trajectory_msgs.msg import JointTrajectoryPoint
from builtin_interfaces.msg import Duration

import build_scene as bs

JOINTS = [f'joint{i}' for i in range(1, 7)]
TOPIC = '/joint_states'
OUT = os.path.expanduser('~/wp2_sync_results')
TEST_POSES = [
    ('P1 home', 'run go_home.py'),
    ('P2 front centre low', 'fingertips about x 0.35, y 0.00, z 0.05'),
    ('P3 front left low', 'about x 0.35, y +0.15, z 0.05'),
    ('P4 front right low', 'about x 0.35, y -0.15, z 0.05'),
    ('P5 far centre low', 'about x 0.55, y 0.00, z 0.05'),
    ('P6 near centre high', 'about x 0.25, y 0.00, z 0.30'),
    ('P7 touching the table', 'lower until the fingertips just touch paper on the table'),
]


def summary(name, values, unit):
    if not values:
        return f'{name}: no data'
    v = sorted(values)
    p95 = v[min(len(v) - 1, int(math.ceil(0.95 * len(v))) - 1)]
    return (f'{name}: mean {st.mean(v):.2f} {unit}, median {st.median(v):.2f}, p95 {p95:.2f}, '
            f'max {v[-1]:.2f}, n = {len(v)}')


def save(mode, header, rows):
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, f'{mode}_{time.strftime("%Y%m%d_%H%M%S")}.csv')
    with open(path, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)
    print(f'saved {path}')
    return path


def quat_matrix(q):
    x, y, z, w = q.x, q.y, q.z, q.w
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                     [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                     [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


class Eval(Node):
    def __init__(self):
        super().__init__('sync_eval')
        self.samples = []                      # (receive time, header stamp s, joint vector)
        self.rs = None
        self.tf = Buffer()
        TransformListener(self.tf, self)
        self.create_subscription(JointState, TOPIC, self.on_js, 200)

    def on_js(self, msg):
        pos = dict(zip(msg.name, msg.position))
        if not all(j in pos for j in JOINTS):
            return
        now = self.get_clock().now().nanoseconds * 1e-9
        stamp = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        self.samples.append((now, stamp, np.array([pos[j] for j in JOINTS])))

    def spin_for(self, seconds):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            rclpy.spin_once(self, timeout_sec=0.005)

    def attach_robot_states(self):
        for _ in range(10):
            rclpy.spin_once(self, timeout_sec=0.1)
        for name, types in self.get_topic_names_and_types():
            if 'xarm_msgs/msg/RobotMsg' in types:
                from rosidl_runtime_py.utilities import get_message
                self.create_subscription(get_message('xarm_msgs/msg/RobotMsg'), name,
                                         lambda m: setattr(self, 'rs', m), 10)
                return name
        return None

    def flange(self):
        t = self.tf.lookup_transform(bs.FRAME, 'link_eef', Time())
        p = t.transform.translation
        return np.array([p.x, p.y, p.z]), quat_matrix(t.transform.rotation)

    def controller(self):
        name = None
        for _ in range(30):
            rclpy.spin_once(self, timeout_sec=0.1)
            names = [n for n, ty in get_action_names_and_types(self)
                     if n.endswith('follow_joint_trajectory') and 'gripper' not in n]
            if names:
                name = sorted(names, key=lambda n: ('xarm6' not in n, len(n)))[0]
                break
        if name is None:
            raise SystemExit('no arm trajectory controller found (is start_real.sh running?)')
        client = ActionClient(self, FollowJointTrajectory, name)
        client.wait_for_server(timeout_sec=5.0)
        print(f'controller: {name}')
        return client


def mode_rate(node, seconds):
    print(f'Recording {TOPIC} for {seconds:.0f} s (the arm does not move) ...')
    node.samples.clear()
    node.spin_for(seconds)
    s = node.samples
    if len(s) < 3:
        raise SystemExit('fewer than 3 joint-state messages: is the driver running?')
    gaps = [(b[0] - a[0]) * 1000 for a, b in zip(s, s[1:])]
    ages = [(r - h) * 1000 for r, h, _ in s if h > 0]
    rate = (len(s) - 1) / (s[-1][0] - s[0][0])
    print(f'update rate: {rate:.1f} Hz, jitter (std of gaps) {st.pstdev(gaps):.2f} ms')
    print(summary('gap between messages', gaps, 'ms'))
    print(summary('message age', ages, 'ms'))
    save('rate', ['receive_s', 'stamp_s'] + JOINTS, [[r, h] + list(q) for r, h, q in s])


def mode_step(node, trials, amp, duration):
    print(f'This moves joint 6 (the wrist roll) by {amp:.3f} rad ({math.degrees(amp):.1f} deg) and back, {trials} times.')
    if input('Supervisor present, E-stop in reach, gripper clear? Type YES: ').strip() != 'YES':
        return
    client = node.controller()
    node.spin_for(0.5)
    if not node.samples:
        raise SystemExit('no /joint_states: is start_real.sh running?')
    thr = 0.002
    tau = np.linspace(0, 1, 10001)                    # time the planned ramp needs to reach the threshold
    ramp = duration * tau[np.argmax(amp * (3 * tau ** 2 - 2 * tau ** 3) >= thr)]
    rows, raw, net, accept = [], [], [], []
    for k in range(trials):
        for sign in (1.0, -1.0):
            q0 = node.samples[-1][2].copy()
            target = q0.copy()
            target[5] += sign * amp
            goal = FollowJointTrajectory.Goal()
            goal.trajectory.joint_names = JOINTS
            pt = JointTrajectoryPoint()
            pt.positions = [float(v) for v in target]
            pt.velocities = [0.0] * 6
            pt.time_from_start = Duration(sec=int(duration), nanosec=int((duration % 1) * 1e9))
            goal.trajectory.points = [pt]
            n0 = len(node.samples)
            t_send = node.get_clock().now().nanoseconds * 1e-9
            fut = client.send_goal_async(goal)
            t_acc = None
            t_move = None
            end = time.monotonic() + duration + 2.0
            while time.monotonic() < end:
                rclpy.spin_once(node, timeout_sec=0.002)
                if t_acc is None and fut.done():
                    t_acc = node.get_clock().now().nanoseconds * 1e-9
                if t_move is None:
                    for r, h, q in node.samples[n0:]:
                        if abs(q[5] - q0[5]) > thr:
                            t_move = r
                            break
            if t_move is None:
                print(f'  trial {k + 1}: no motion seen')
                continue
            lat = (t_move - t_send) * 1000
            raw.append(lat)
            net.append(lat - ramp * 1000)
            if t_acc:
                accept.append((t_acc - t_send) * 1000)
            rows.append([k + 1, sign, t_send, t_acc, t_move, lat, lat - ramp * 1000])
            print(f'  trial {k + 1} {"+" if sign > 0 else "-"}: command to motion {lat:.1f} ms '
                  f'({lat - ramp * 1000:.1f} ms without the {ramp * 1000:.0f} ms ramp)')
            node.spin_for(0.3)
    print(summary('command to first motion', raw, 'ms'))
    print(summary('same, ramp removed', net, 'ms'))
    print(summary('goal accepted', accept, 'ms'))
    save('step', ['trial', 'direction', 'send_s', 'accepted_s', 'motion_s', 'latency_ms', 'latency_no_ramp_ms'], rows)


def mode_pose(node, tcp):
    topic = node.attach_robot_states()
    print('controller pose from', topic or 'NOT AVAILABLE (only the hand measurement will be compared)')
    print('Jog to each test pose with etee_hold.py (in another window), then come back here.')
    rows, model_err, phys_err = [], [], []
    for name, hint in TEST_POSES:
        cmd = input(f'\n{name} ({hint}). Enter = record, s = skip, q = finish: ').strip().lower()
        if cmd == 'q':
            break
        if cmd == 's':
            continue
        node.spin_for(0.5)
        try:
            f, R = node.flange()
        except Exception as e:                           # noqa: BLE001
            print(f'  no TF: {e}')
            continue
        twin_tip = f + R[:, 2] * tcp
        row = [name] + [round(v * 1000, 2) for v in twin_tip]
        ctrl = [None] * 4
        if node.rs is not None and len(getattr(node.rs, 'pose', [])) >= 3:
            off = list(getattr(node.rs, 'offset', [0.0] * 6))[:3] or [0.0, 0.0, 0.0]
            twin_ctrl_tcp = f + R @ (np.array(off, dtype=float) / 1000.0)
            ctrl_tcp = np.array(node.rs.pose[:3], dtype=float) / 1000.0
            e = float(np.linalg.norm(twin_ctrl_tcp - ctrl_tcp)) * 1000
            model_err.append(e)
            ctrl = [round(v * 1000, 2) for v in ctrl_tcp] + [round(e, 2)]
            print(f'  twin vs controller TCP: {e:.2f} mm (controller TCP offset {off} mm)')
        row += ctrl
        meas = input('  measured fingertip x y z in mm, world frame (blank = skip): ').strip()
        if meas:
            try:
                m = np.array([float(v) for v in meas.replace(',', ' ').split()][:3]) / 1000.0
                e = float(np.linalg.norm(twin_tip - m)) * 1000
                phys_err.append(e)
                row += [round(v * 1000, 2) for v in m] + [round(e, 2)]
                print(f'  twin vs measured fingertip: {e:.2f} mm '
                      f'(dx {1000 * (twin_tip[0] - m[0]):+.1f}, dy {1000 * (twin_tip[1] - m[1]):+.1f}, '
                      f'dz {1000 * (twin_tip[2] - m[2]):+.1f})')
            except ValueError:
                print('  could not read three numbers; skipped')
        rows.append(row)
    print()
    print(summary('model error (twin vs controller)', model_err, 'mm'))
    print(summary('physical error (twin vs measured)', phys_err, 'mm'))
    save('pose', ['pose', 'twin_x_mm', 'twin_y_mm', 'twin_z_mm', 'ctrl_x_mm', 'ctrl_y_mm', 'ctrl_z_mm', 'model_err_mm',
                  'meas_x_mm', 'meas_y_mm', 'meas_z_mm', 'phys_err_mm'], rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('mode', choices=['rate', 'step', 'pose'])
    ap.add_argument('--topic', default='/joint_states', help='joint-state topic to measure (/xarm/joint_states = the driver)')
    ap.add_argument('--seconds', type=float, default=10.0)
    ap.add_argument('--trials', type=int, default=10)
    ap.add_argument('--amp', type=float, default=0.03, help='rad, joint 6 step (max 0.1)')
    ap.add_argument('--duration', type=float, default=0.5, help='s, planned time of each step')
    args = ap.parse_args()
    global TOPIC
    TOPIC = args.topic
    print(f'joint states from {TOPIC}')
    rclpy.init()
    node = Eval()
    node.spin_for(1.0)
    try:
        if args.mode == 'rate':
            mode_rate(node, args.seconds)
        elif args.mode == 'step':
            mode_step(node, args.trials, min(abs(args.amp), 0.1), max(0.2, args.duration))
        else:
            mode_pose(node, bs.TCP_OFFSET_Z)
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
