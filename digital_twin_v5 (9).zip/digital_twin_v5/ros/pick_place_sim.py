#!/usr/bin/env python3
"""Pick and place of the Jenga block with MoveIt. Run on FAKE hardware first!

Needs build_scene.py in the same folder and the scene already built:
  Terminal 1: ros2 launch xarm_moveit_config xarm6_moveit_fake.launch.py add_gripper:=true
  Terminal 2: python3 build_scene.py            (table, block, etc.)
  Terminal 3: python3 pick_place_sim.py         (this file)

The block position is read from MoveIt's planning scene, so if perception_bridge.py is running
the robot goes where the perception system says the block is. Each step waits for Enter so you
can watch RViz. Attaching the block is a planning-scene idea only: it does NOT prove that the
real gripper is holding it.
"""
import math
import sys
import time

import rclpy
from geometry_msgs.msg import Pose
from moveit_msgs.action import ExecuteTrajectory, MoveGroup
from moveit_msgs.msg import (AttachedCollisionObject, CollisionObject, Constraints,
                             JointConstraint, MotionPlanRequest, MoveItErrorCodes,
                             OrientationConstraint, PlanningScene, PlanningSceneComponents,
                             PositionConstraint)
from moveit_msgs.srv import ApplyPlanningScene, GetCartesianPath, GetPlanningScene
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.time import Time
from shape_msgs.msg import SolidPrimitive
from tf2_ros import Buffer, TransformListener

import build_scene as bs      # one source of truth for the block position, table height and frame

# ------------------------------------------------------------------ EDIT THESE
ARM_GROUP, GRIPPER_GROUP = 'xarm6', 'xarm_gripper'
TIP_LINK = 'link_eef'          # tip of the arm group (the flange)
ATTACH_LINK = 'link_tcp'       # link the block is attached to
GRIPPER_JOINT = 'drive_joint'
TCP_OFFSET_Z = bs.TCP_OFFSET_Z   # flange to gripper TCP (m); set it in build_scene.py
GRASP_YAW_DEG = 0.0            # 0 or 90: finger direction relative to the block. CHECK in RViz.

GRIP_OPEN = 0.0                # drive_joint value, open (from the xArm gripper SRDF)
GRIP_CLOSE = 0.85              # what held the 45 mm block on the real V1 gripper: command full close and let the block stall the fingers

USE_SCENE_BLOCK_POSE = True    # True: take the block position/yaw from MoveIt's scene (perception)
PLACE_XY = (0.26, -0.12)       # PLACEHOLDER: where the block goes (slot position). Use the WP1 drawing.
PLACE_YAW_DEG = None           # None = keep the block's orientation; or a yaw in degrees for the slot
ACCEL_SCALE = None             # acceleration scaling; None = same as SCALE. Lower = gentler starts and stops.
SCALE = 0.2                    # speed/acceleration scaling. Use 0.05 or lower for the real arm.
CLEARANCE = 0.10               # how far above the block/slot to hover (m)
GRASP_Z_OFFSET = 0.005         # raise the grasp this much above the block's mid-height (m)

GRIPPER_LINKS = ['xarm_gripper_base_link', 'left_outer_knuckle', 'left_inner_knuckle',
                 'left_finger', 'right_outer_knuckle', 'right_inner_knuckle', 'right_finger',
                 'link_tcp', 'link_eef']
# ----------------------------------------------------------------------------

JENGA_H = bs.JENGA[2]
BLOCK_X, BLOCK_Y = bs.JENGA_XY
PLACE_X, PLACE_Y = PLACE_XY
GRASP_Z = bs.Z_FLOOR + JENGA_H / 2.0 + GRASP_Z_OFFSET                  # TCP height when grasping
# Held block sits GRASP_Z_OFFSET below the TCP, so add it back; the block's underside ends 1 mm above the modelled table
PLACE_Z = bs.Z_FLOOR + JENGA_H / 2.0 + GRASP_Z_OFFSET + bs.Z_MARGIN + 0.001
HOVER_Z = GRASP_Z + CLEARANCE


def quat_mul(a, b):
    """Quaternions as (x, y, z, w)."""
    ax, ay, az, aw = a
    bx, by, bz, bw = b
    return (aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw,
            aw * bw - ax * bx - ay * by - az * bz)


def quat_rotate(q, v):
    x, y, z, w = q
    r = quat_mul(quat_mul(q, (v[0], v[1], v[2], 0.0)), (-x, -y, -z, w))
    return r[0], r[1], r[2]


def quat_yaw_deg(q):
    x, y, z, w = q
    return math.degrees(math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z)))


def quat_of(orientation):
    """(x, y, z, w) from a ROS quaternion; identity if it is all zeros."""
    q = (orientation.x, orientation.y, orientation.z, orientation.w)
    return q if sum(c * c for c in q) > 0.25 else (0.0, 0.0, 0.0, 1.0)


def quat_tool_down(yaw_deg):
    """Tool z axis pointing straight down. yaw_deg is the heading of the tool x axis in the world
    frame (counter-clockwise seen from above), so it matches the block's yaw directly. The minus
    sign is there because the tool is upside down: turning it about its own z turns it the other
    way round in the world."""
    h = -math.radians(yaw_deg) / 2.0
    return quat_mul((1.0, 0.0, 0.0, 0.0), (0.0, 0.0, math.sin(h), math.cos(h)))


def tip_pose(x, y, tcp_z, yaw_deg):
    """Pose of the flange that puts the gripper TCP at (x, y, tcp_z), tool pointing down."""
    p = Pose()
    p.position.x, p.position.y, p.position.z = x, y, tcp_z + TCP_OFFSET_Z
    p.orientation.x, p.orientation.y, p.orientation.z, p.orientation.w = quat_tool_down(yaw_deg)
    return p


def ensure_timing(traj):
    """If MoveIt returned a path with no timing, add simple timing (about 1 rad/s x SCALE)."""
    pts = traj.joint_trajectory.points
    if len(pts) < 2 or pts[-1].time_from_start.sec or pts[-1].time_from_start.nanosec:
        return
    t = 0.0
    for prev, cur in zip(pts, pts[1:]):
        step = max(abs(a - b) for a, b in zip(cur.positions, prev.positions))
        t += max(step / SCALE, 0.01)
        cur.time_from_start.sec = int(t)
        cur.time_from_start.nanosec = int((t - int(t)) * 1e9)
        cur.velocities, cur.accelerations = [], []


class PickPlace(Node):
    def __init__(self):
        super().__init__('pick_place_sim')
        self.yaw_deg = GRASP_YAW_DEG
        self.get_scene = self.create_client(GetPlanningScene, '/get_planning_scene')
        self.apply_scene = self.create_client(ApplyPlanningScene, '/apply_planning_scene')
        self.cart_srv = self.create_client(GetCartesianPath, '/compute_cartesian_path')
        self.move_ac = ActionClient(self, MoveGroup, '/move_action')
        self.exec_ac = ActionClient(self, ExecuteTrajectory, '/execute_trajectory')
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

    # ---- plumbing
    def call(self, client, request):
        while not client.wait_for_service(timeout_sec=2.0):
            self.get_logger().info(f'waiting for {client.srv_name} (is move_group up?)')
        future = client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
        return future.result()

    def send_goal(self, client, goal):
        while not client.wait_for_server(timeout_sec=2.0):
            self.get_logger().info('waiting for an action server (is move_group up?)')
        sent = client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, sent)
        handle = sent.result()
        if not handle.accepted:
            self.get_logger().error('goal rejected')
            return None
        done = handle.get_result_async()
        rclpy.spin_until_future_complete(self, done)
        return done.result().result

    def apply(self, scene):
        ok = self.call(self.apply_scene, ApplyPlanningScene.Request(scene=scene)).success
        if not ok:
            self.get_logger().error('move_group rejected the scene update')
        time.sleep(1.0)       # let the scene monitor catch up
        return ok

    # ---- reading the world
    def current_tip_pose(self):
        """Flange pose in the planning frame from TF (waits ~0.4 s so TF is fresh)."""
        for _ in range(8):
            rclpy.spin_once(self, timeout_sec=0.05)
        try:
            t = self.tf_buffer.lookup_transform(bs.FRAME, TIP_LINK, Time())
        except Exception as e:                        # noqa: BLE001
            self.get_logger().error(f'no TF {bs.FRAME} -> {TIP_LINK}: {e}')
            return None
        p = Pose()
        p.position.x = t.transform.translation.x
        p.position.y = t.transform.translation.y
        p.position.z = t.transform.translation.z
        p.orientation = t.transform.rotation
        return p

    def read_block_pose(self):
        """(x, y, yaw_deg) of 'jenga_block' as MoveIt currently has it, or None."""
        req = GetPlanningScene.Request()
        req.components.components = (PlanningSceneComponents.WORLD_OBJECT_NAMES |
                                     PlanningSceneComponents.WORLD_OBJECT_GEOMETRY)
        scene = self.call(self.get_scene, req).scene
        for obj in scene.world.collision_objects:
            if obj.id == 'jenga_block' and obj.primitive_poses:
                qo, qs = quat_of(obj.pose.orientation), quat_of(obj.primitive_poses[0].orientation)
                s = obj.primitive_poses[0].position
                vx, vy, _ = quat_rotate(qo, (s.x, s.y, s.z))
                return obj.pose.position.x + vx, obj.pose.position.y + vy, quat_yaw_deg(quat_mul(qo, qs))
        return None

    # ---- scene changes
    def allow_gripper_contact(self):
        """The fingers may touch the block (it sits between them). Nothing else changes."""
        req = GetPlanningScene.Request()
        req.components.components = PlanningSceneComponents.ALLOWED_COLLISION_MATRIX
        acm = self.call(self.get_scene, req).scene.allowed_collision_matrix
        scene = PlanningScene(is_diff=True)
        scene.allowed_collision_matrix = bs.set_acm_entries(acm, {'jenga_block': GRIPPER_LINKS})
        return self.apply(scene)

    def attach(self):
        aco = AttachedCollisionObject()
        aco.link_name = ATTACH_LINK
        aco.object = CollisionObject(id='jenga_block', operation=CollisionObject.ADD)
        aco.object.header.frame_id = ATTACH_LINK
        aco.touch_links = GRIPPER_LINKS
        scene = PlanningScene(is_diff=True)
        scene.robot_state.is_diff = True
        scene.robot_state.attached_collision_objects.append(aco)
        return self.apply(scene)

    def detach(self):
        aco = AttachedCollisionObject()
        aco.link_name = ATTACH_LINK
        aco.object = CollisionObject(id='jenga_block', operation=CollisionObject.REMOVE)
        scene = PlanningScene(is_diff=True)
        scene.robot_state.is_diff = True
        scene.robot_state.attached_collision_objects.append(aco)
        return self.apply(scene)

    # ---- motions
    def plan_and_execute(self, request):
        goal = MoveGroup.Goal()
        goal.request = request
        goal.planning_options.plan_only = False
        goal.planning_options.planning_scene_diff.is_diff = True
        goal.planning_options.planning_scene_diff.robot_state.is_diff = True
        result = self.send_goal(self.move_ac, goal)
        if result is None or result.error_code.val != MoveItErrorCodes.SUCCESS:
            code = None if result is None else result.error_code.val
            self.get_logger().error(f'plan/execute failed (MoveIt error code {code})')
            return False
        return True

    def base_request(self, group):
        req = MotionPlanRequest()
        req.group_name = group
        req.num_planning_attempts = 5
        req.allowed_planning_time = 5.0
        req.max_velocity_scaling_factor = SCALE
        req.max_acceleration_scaling_factor = ACCEL_SCALE if ACCEL_SCALE is not None else SCALE
        req.start_state.is_diff = True
        return req

    def gripper(self, value):
        req = self.base_request(GRIPPER_GROUP)
        c = Constraints()
        c.joint_constraints.append(JointConstraint(
            joint_name=GRIPPER_JOINT, position=float(value),
            tolerance_above=0.01, tolerance_below=0.01, weight=1.0))
        req.goal_constraints.append(c)
        return self.plan_and_execute(req)

    def move_to_pose(self, pose):
        """Free-space move (the planner chooses the path) to a flange pose."""
        req = self.base_request(ARM_GROUP)
        pc = PositionConstraint()
        pc.header.frame_id = bs.FRAME
        pc.link_name = TIP_LINK
        pc.constraint_region.primitives.append(
            SolidPrimitive(type=SolidPrimitive.SPHERE, dimensions=[0.003]))
        region_pose = Pose()
        region_pose.position = pose.position
        region_pose.orientation.w = 1.0
        pc.constraint_region.primitive_poses.append(region_pose)
        pc.weight = 1.0
        oc = OrientationConstraint()
        oc.header.frame_id = bs.FRAME
        oc.link_name = TIP_LINK
        oc.orientation = pose.orientation
        oc.absolute_x_axis_tolerance = oc.absolute_y_axis_tolerance = 0.05
        oc.absolute_z_axis_tolerance = 0.05
        oc.weight = 1.0
        c = Constraints()
        c.position_constraints.append(pc)
        c.orientation_constraints.append(oc)
        req.goal_constraints.append(c)
        return self.plan_and_execute(req)

    def cartesian_pose(self, pose):
        """Straight-line move to a flange pose (descending, lifting, small nudges)."""
        req = GetCartesianPath.Request()
        req.header.frame_id = bs.FRAME
        req.start_state.is_diff = True
        req.group_name = ARM_GROUP
        req.link_name = TIP_LINK
        req.waypoints = [pose]
        req.max_step = 0.005
        req.jump_threshold = 0.0
        req.avoid_collisions = True
        for name in ('max_velocity_scaling_factor', 'max_acceleration_scaling_factor'):
            if hasattr(req, name):
                setattr(req, name, ACCEL_SCALE if (name.startswith('max_acc') and ACCEL_SCALE is not None) else SCALE)
        res = self.call(self.cart_srv, req)
        if res.fraction < 0.99:
            self.get_logger().error(
                f'straight-line path only {res.fraction * 100:.0f}% possible: something is in the way '
                f'(table, block, limits).')
            return False
        ensure_timing(res.solution)
        result = self.send_goal(self.exec_ac, ExecuteTrajectory.Goal(trajectory=res.solution))
        if result is None or result.error_code.val != MoveItErrorCodes.SUCCESS:
            self.get_logger().error('executing the straight-line path failed')
            return False
        return True

    def move_to(self, x, y, tcp_z, yaw_deg=None):
        return self.move_to_pose(tip_pose(x, y, tcp_z, self.yaw_deg if yaw_deg is None else yaw_deg))

    def cartesian_to(self, x, y, tcp_z, yaw_deg=None):
        return self.cartesian_pose(tip_pose(x, y, tcp_z, self.yaw_deg if yaw_deg is None else yaw_deg))

    # ---- the sequence
    def run(self):
        bx, by, byaw = BLOCK_X, BLOCK_Y, 0.0
        if USE_SCENE_BLOCK_POSE:
            found = self.read_block_pose()
            if found:
                bx, by, byaw = found
                byaw = ((byaw + 90.0) % 180.0) - 90.0          # a block looks the same turned 180 deg
                print('Block pose read from the planning scene.')
            else:
                print('Block not found in the scene; using the numbers in build_scene.py.')
        pick_yaw = GRASP_YAW_DEG + byaw
        place_yaw = pick_yaw if PLACE_YAW_DEG is None else GRASP_YAW_DEG + PLACE_YAW_DEG
        print(f'\nBlock at ({bx:.3f}, {by:.3f}) yaw {byaw:.1f} deg, target ({PLACE_X:.3f}, {PLACE_Y:.3f}), '
              f'hover TCP z = {HOVER_Z:.3f}, grasp z = {GRASP_Z:.3f}, speed scaling = {SCALE}')
        print('This moves whatever MoveIt is connected to. Use the FAKE-hardware launch first.')
        if input('Type YES to continue: ').strip() != 'YES':
            return False
        if not self.allow_gripper_contact():
            return False
        steps = [
            ('open the gripper', lambda: self.gripper(GRIP_OPEN)),
            ('move above the block', lambda: self.move_to(bx, by, HOVER_Z, pick_yaw)),
            ('descend to the block', lambda: self.cartesian_to(bx, by, GRASP_Z, pick_yaw)),
            ('close the gripper', lambda: self.gripper(GRIP_CLOSE)),
            ('attach the block to the gripper', self.attach),
            ('lift the block', lambda: self.cartesian_to(bx, by, HOVER_Z, pick_yaw)),
            ('move above the target', lambda: self.move_to(PLACE_X, PLACE_Y, HOVER_Z, place_yaw)),
            ('lower the block', lambda: self.cartesian_to(PLACE_X, PLACE_Y, PLACE_Z, place_yaw)),
            ('open the gripper', lambda: self.gripper(GRIP_OPEN)),
            ('detach the block', self.detach),
            ('retreat upwards', lambda: self.cartesian_to(PLACE_X, PLACE_Y, HOVER_Z, place_yaw)),
        ]
        for i, (name, action) in enumerate(steps, 1):
            if input(f'[{i}/{len(steps)}] Press Enter to {name} (q then Enter to stop): ').strip().lower() == 'q':
                return False
            if not action():
                print('Step failed, stopping here.')
                return False
        print('Done.')
        return True


def main():
    rclpy.init()
    node = PickPlace()
    ok = node.run()
    node.destroy_node()
    rclpy.shutdown()
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
