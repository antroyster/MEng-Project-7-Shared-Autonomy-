"""Offline checks, no ROS or robot needed:  python3 test_offline.py"""
from types import SimpleNamespace as NS
import numpy as np
from etee_input import pad_command, speed_fraction, describe_direction
from xarm_kin import fk_tcp

def joy(a, b): return NS(axes=a, buttons=b)
def check(c, m):
    print(('PASS ' if c else 'FAIL ') + m); assert c

d, m = pad_command(joy([0, 0.9, 0, 0], [1, 0, 0, 0])); check(describe_direction(d) == 'FORWARD', 'left pad up = forward')
d, m = pad_command(joy([0.9, 0, 0, 0], [1, 0, 0, 0])); check(describe_direction(d) == 'RIGHT', 'left pad right = right')
d, m = pad_command(joy([0, 0, 0, -0.9], [0, 1, 0, 0])); check(describe_direction(d) == 'DOWN', 'right pad down = down')
d, m = pad_command(joy([0, 0, 0, -0.9], [0, 0, 0, 0])); check(d is None, 'untouched pad ignored')
d, m = pad_command(joy([0, 0.9, 0, -0.3], [1, 1, 0, 0])); check(d[2] == 0, 'weak other-pad noise ignored')
d, m = pad_command(joy([0, 0, 0, 0.9], [0, 1, 0, 0]), (1, 1, -1)); check(describe_direction(d) == 'DOWN', 'flip-z works')
check(speed_fraction(0.2) == 0.2 and speed_fraction(0.5) == 0.5 and speed_fraction(1.0) == 1.0, 'speed levels')
q = [-0.0086, -0.9809, -0.9284, 0.0141, 1.9111, -0.0140]
p, R = fk_tcp(q, 0.242)
print('home fingertip', np.round(p, 3))
check(abs(p[0] - 0.1665) < 0.01 and abs(p[2] - (-0.0)) < 0.5, 'FK home x ~0.1665')
check(abs((fk_tcp(q, 0.242)[0][2]) - (fk_tcp(q, 0.0)[0][2]) + 0.242) < 0.01, 'tool points down')
