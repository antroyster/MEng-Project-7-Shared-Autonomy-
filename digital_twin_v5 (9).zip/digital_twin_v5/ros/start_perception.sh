#!/usr/bin/env bash
# v4: perception into the twin in ONE window: table frame + WP3 scene bridge (+ mock blocks unless --live).
#   bash start_perception.sh            simulation: 3 fake (mock) blocks, clearly labelled as mock
#   bash start_perception.sh --wood     mock with the 45 mm wooden props
#   bash start_perception.sh --live     real WP3 node publishing /wp3_live/markers (no mock)
# Table frame: edit TABLE_XYZ / TABLE_YAW after the Step B fit (fit_table_tf.py prints the values).
cd "$(dirname "$0")"
# v6: the table frame comes from wp3_table_tf.yaml (written by fit_table_tf.py, Step B) when it exists.
#     TABLE_XYZ / TABLE_YAW still override it; without either, a nominal guess is used (fine for the mock only).
if [ -n "$TABLE_XYZ" ]; then
  TF_ARGS="--xyz $TABLE_XYZ --yaw ${TABLE_YAW:-0}"; TF_FROM="TABLE_XYZ=$TABLE_XYZ yaw ${TABLE_YAW:-0}"
elif [ -n "$TABLE_TF_FILE" ] && [ -f "$TABLE_TF_FILE" ]; then
  TF_ARGS="--file $TABLE_TF_FILE"; TF_FROM="$TABLE_TF_FILE (Step B calibration)"
elif [ -f wp3_table_tf.yaml ]; then
  TF_ARGS=""; TF_FROM="wp3_table_tf.yaml (Step B calibration)"
elif [ -f ~/twin_calibration/wp3_table_tf.yaml ]; then
  TF_ARGS="--file $HOME/twin_calibration/wp3_table_tf.yaml"; TF_FROM="~/twin_calibration/wp3_table_tf.yaml (Step B calibration)"
else
  TF_ARGS="--xyz 0.30 0.00 -0.008 --yaw 0"; TF_FROM="NOMINAL GUESS (no wp3_table_tf.yaml)"
  [[ "$1" == "--live" ]] && echo "WARNING: live perception without wp3_table_tf.yaml: blocks will be in the wrong place. Do Step B (fit_table_tf.py) first."
fi
echo "table frame from: $TF_FROM"
# the WP3 node uses a Fast DDS shared-memory profile; use the same one so the topics are seen (WP3_DIR overrides)
WP3_DIR="${WP3_DIR:-$HOME/WP3-Live-Implementation-v2-Three-View}"
PROFILE="$WP3_DIR/ros2_ws/src/wp3_live_perception/config/fastdds_shm_profile.xml"
if [[ "$1" == "--live" && -f "$PROFILE" ]]; then export FASTRTPS_DEFAULT_PROFILES_FILE="$PROFILE"; echo "Fast DDS profile: $PROFILE"; fi
pids=()
cleanup() { kill "${pids[@]}" 2>/dev/null; wait 2>/dev/null; echo "perception stopped"; }
trap cleanup EXIT INT TERM
python3 wp3_table_tf.py $TF_ARGS & pids+=($!)
sleep 1
python3 wp3_scene_bridge.py --remove-demo-block & pids+=($!)
if [[ "$1" != "--live" ]]; then
  sleep 2
  python3 mock_wp3_publisher.py "$@" & pids+=($!)
fi
echo "perception running (Ctrl+C stops all of it)"
wait
