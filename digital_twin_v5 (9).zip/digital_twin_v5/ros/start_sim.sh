#!/usr/bin/env bash
# SIMULATION, terminal 1. Fake arm + MoveIt + RViz, moved to the real home pose, then the scene.
#   bash start_sim.sh           Ctrl+C stops everything.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source /opt/ros/jazzy/setup.bash
source ~/xarm_ws/install/setup.bash

if ros2 node list 2>/dev/null | grep -q move_group; then
  echo "A MoveIt launch is already running. Stop it first."; exit 1
fi
ros2 launch xarm_moveit_config xarm6_moveit_fake.launch.py add_gripper:=true &
LAUNCH_PID=$!
trap 'kill $LAUNCH_PID 2>/dev/null; wait $LAUNCH_PID 2>/dev/null' EXIT INT TERM

echo "Waiting for MoveIt ..."
for i in $(seq 1 90); do
  ros2 service list 2>/dev/null | grep -q "^/get_planning_scene$" && ros2 topic list 2>/dev/null | grep -q "^/joint_states$" && break
  sleep 1
done
sleep 5
cd "$HERE"
echo YES | python3 go_home.py          # scene is still empty, so this move cannot collide
python3 build_scene.py
echo "Simulated arm at the real home pose with the scene built. Leave this running; Ctrl+C to stop."
wait $LAUNCH_PID
