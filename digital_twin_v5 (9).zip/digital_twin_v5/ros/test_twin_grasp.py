#!/usr/bin/env python3
"""Offline checks for twin_grasp.py (automatic grasp / release). No ROS needed:  python3 test_twin_grasp.py"""
import math
import twin_grasp as tg

FLOOR = -0.007                                   # modelled table top (build_scene Z_FLOOR + Z_MARGIN)
J = (0.075, 0.025, 0.015)                        # printed Jenga block
I = (0.0, 0.0, 0.0, 1.0)
fails = 0


def check(name, ok):
    global fails
    print(('PASS ' if ok else 'FAIL ') + name)
    fails += 0 if ok else 1


blk = ('wp3_blocks_1', J, (0.30, 0.00, FLOOR + J[2] / 2), I)
table = ('table', (1.4, 0.7, 0.8), (0.63, 0.0, FLOOR - 0.4), I)
check('grasps the block when the fingertips are around it', tg.find_graspable((0.30, 0.0, FLOOR + 0.004), [table, blk]) == 'wp3_blocks_1')
check('fingertips at the block top edge still count', tg.find_graspable((0.31, 0.0, FLOOR + J[2] + 0.004), [blk]) == 'wp3_blocks_1')
check('nothing when 5 cm above the block', tg.find_graspable((0.30, 0.0, FLOOR + 0.065), [blk]) is None)
check('nothing when beside the block', tg.find_graspable((0.30, 0.05, FLOOR + 0.005), [blk]) is None)
check('the table is never grasped', tg.find_graspable((0.60, 0.0, FLOOR - 0.001), [table]) is None)
rot = ('wp3_blocks_2', J, (0.40, 0.10, FLOOR + J[2] / 2), tg.yaw_quat(math.radians(90)))
check('rotated block: inside along its long axis (world y)', tg.find_graspable((0.40, 0.13, FLOOR + 0.005), [rot]) == 'wp3_blocks_2')
check('rotated block: outside across its short axis (world x)', tg.find_graspable((0.43, 0.10, FLOOR + 0.005), [rot]) is None)
wide = ('box_wide', (0.12, 0.10, 0.05), (0.3, 0.0, FLOOR + 0.025), I)
check('too wide for the gripper is refused', tg.find_graspable((0.3, 0.0, FLOOR + 0.01), [wide]) is None)
near = ('wp3_blocks_3', J, (0.305, 0.0, FLOOR + J[2] / 2), I)
check('closest of two candidates wins', tg.find_graspable((0.306, 0.0, FLOOR + 0.005), [blk, near]) == 'wp3_blocks_3')

xyz, q = tg.drop_pose((0.5, 0.1, 0.20), tg.yaw_quat(0.3), J, [table, blk], FLOOR, 'wp3_blocks_9')
check('released in the air: lands on the table', abs(xyz[2] - (FLOOR + J[2] / 2)) < 1e-9)
check('keeps its yaw', abs(tg.yaw_of(q) - 0.3) < 1e-9)
xyz, q = tg.drop_pose((0.30, 0.0, 0.20), I, J, [table, blk], FLOOR, 'wp3_blocks_9')
check('released above another block: stacks on it', abs(xyz[2] - (FLOOR + J[2] + J[2] / 2)) < 1e-9)
xyz, q = tg.drop_pose((0.30, 0.0, 0.20), I, J, [blk], FLOOR, 'wp3_blocks_1')
check('ignores itself as a support', abs(xyz[2] - (FLOOR + J[2] / 2)) < 1e-9)
pose = ((0.1, 0.2, 0.0), tg.yaw_quat(math.pi / 2))
w, wq = tg.compose(pose, ((0.1, 0.0, 0.05), I))
check('compose object pose + primitive pose', all(abs(a - b) < 1e-9 for a, b in zip(w, (0.1, 0.3, 0.05))))
print('all twin grasp checks passed' if not fails else f'{fails} FAILED')
raise SystemExit(1 if fails else 0)
