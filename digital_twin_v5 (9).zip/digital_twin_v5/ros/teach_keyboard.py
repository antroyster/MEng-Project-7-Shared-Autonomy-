#!/usr/bin/env python3
"""Keyboard teaching: nudge the arm with keys, save waypoints, replay them.

Use it to FIND a good pick-and-place path in simulation (approach height, finger direction,
how far the gripper closes), then replay the saved waypoints on the real arm.

  Teach:   python3 teach_keyboard.py                      (saves to waypoints.yaml)
  Replay:  python3 teach_keyboard.py --replay waypoints.yaml

Every key press is ONE small straight-line move that MoveIt checks against the scene (table,
walls, power box) and then stops. Keys pressed while the arm is moving are thrown away.
Start with the FAKE-hardware launch. For the real arm: supervisor present, E-stop in reach,
--scale 0.05 --step 0.005, and do not replay a path on the real arm that you have not run in
simulation first. Attach/detach only changes MoveIt's scene; it is not a grip check.
"""
import argparse
import copy
import math
import os
import select
import sys
import termios
import tty

import rclpy
import yaml
from geometry_msgs.msg import Pose

import build_scene as bs
import pick_place_sim as pp

MIN_CLEARANCE = 0.002          # m. Keyboard lowering stops this far above the table surface (fingertip height)

HELP = """
  w / s   forward / back  (+x / -x)       a / d   left / right (+y / -y)      r / f   up / down
  j / l   turn gripper left / right       [ / ]   smaller / larger step       , / .   grip closes less / more
  o  open gripper    c  close gripper     g  attach / detach the block (planning scene)
  , / .   adjust the grip by 0.02 and move it live if closed;  < / >  by 0.10;  1-9  jump to 0.1 ... 0.85
  p  save waypoint   v  show pose         h  help      q  quit
"""


class RawTerminal:
    """Read single key presses (Ctrl+C still works)."""
    def __enter__(self):
        self.fd = sys.stdin.fileno()
        self.old = termios.tcgetattr(self.fd)
        tty.setcbreak(self.fd)
        return self

    def __exit__(self, *exc):
        termios.tcsetattr(self.fd, termios.TCSADRAIN, self.old)

    def key(self, timeout=0.2):
        ready, _, _ = select.select([sys.stdin], [], [], timeout)
        return sys.stdin.read(1) if ready else None

    def flush(self):
        termios.tcflush(self.fd, termios.TCIFLUSH)


def pose_from_list(v):
    p = Pose()
    p.position.x, p.position.y, p.position.z = v[0], v[1], v[2]
    p.orientation.x, p.orientation.y, p.orientation.z, p.orientation.w = v[3], v[4], v[5], v[6]
    return p


class Teach(pp.PickPlace):
    def __init__(self, args):
        super().__init__()
        self.step = args.step
        self.file = args.file
        self.grip_close = pp.GRIP_CLOSE
        self.gripper_state = 'unknown'
        self.holding = False
        self.waypoints = []
        if os.path.exists(self.file):
            with open(self.file) as f:
                self.waypoints = (yaml.safe_load(f) or {}).get('waypoints', [])
            print(f'Loaded {len(self.waypoints)} existing waypoints from {self.file}; new ones are added.')

    # ---- helpers
    def show_pose(self):
        p = self.current_tip_pose()
        if p is None:
            return
        yaw = pp.quat_yaw_deg(pp.quat_of(p.orientation))
        print(f'  TCP x={p.position.x:.3f} y={p.position.y:.3f} z={p.position.z - pp.TCP_OFFSET_Z:.3f} m, '
              f'yaw {yaw:.0f} deg | step {self.step * 100:.1f} cm | grip close {self.grip_close:.2f} | '
              f'gripper {self.gripper_state} | holding {self.holding}')

    def nudge(self, dx=0.0, dy=0.0, dz=0.0, dyaw_deg=0.0):
        p = self.current_tip_pose()
        if p is None:
            return False
        new = copy.deepcopy(p)
        new.position.x += dx
        new.position.y += dy
        new.position.z += dz
        tcp_z = new.position.z - pp.TCP_OFFSET_Z            # real fingertip height (tool points straight down)
        lowest = bs.Z_FLOOR + MIN_CLEARANCE
        fx0, fx1, fy0, fy1 = bs.fence_limits()                # keep-in boundary round the table
        if not (fx0 <= new.position.x <= fx1 and fy0 <= new.position.y <= fy1) and (dx or dy):
            inside = fx0 <= p.position.x <= fx1 and fy0 <= p.position.y <= fy1
            if inside:                                        # already outside (e.g. after a replay): let it move back
                print(f'  refused: that would cross the table boundary (x {fx0:.2f}..{fx1:.2f}, y {fy0:.2f}..{fy1:.2f} m)')
                return False
        if dz < 0 and tcp_z < lowest:
            print(f'  refused: fingertips would go to z = {tcp_z:.3f} m, below the table limit {lowest:.3f} m')
            return False
        if dyaw_deg:
            h = math.radians(dyaw_deg) / 2.0
            q = pp.quat_mul((0.0, 0.0, math.sin(h), math.cos(h)), pp.quat_of(p.orientation))
            new.orientation.x, new.orientation.y, new.orientation.z, new.orientation.w = q
        return self.cartesian_pose(new)

    def save_waypoint(self):
        p = self.current_tip_pose()
        if p is None:
            return
        o = p.orientation
        wp = {'name': f'wp{len(self.waypoints) + 1}',
              'tip_pose': [round(v, 5) for v in (p.position.x, p.position.y, p.position.z, o.x, o.y, o.z, o.w)],
              'tcp_z': round(p.position.z - pp.TCP_OFFSET_Z, 4),
              'yaw_deg': round(pp.quat_yaw_deg(pp.quat_of(o)), 1),
              'gripper': self.gripper_state,
              'grip_close': round(self.grip_close, 3),
              'holding_block': self.holding}
        self.waypoints.append(wp)
        with open(self.file, 'w') as f:
            yaml.safe_dump({'frame': bs.FRAME, 'waypoints': self.waypoints}, f, sort_keys=False)
        print(f'  saved {wp["name"]} to {self.file}: TCP z {wp["tcp_z"]} m, yaw {wp["yaw_deg"]} deg, '
              f'gripper {wp["gripper"]}, holding {wp["holding_block"]}')

    # ---- teach mode
    def teach_loop(self):
        print('Fake hardware first. Real arm: supervisor present, E-stop in reach, --scale 0.05.')
        if input('Type YES to start: ').strip() != 'YES':
            return
        self.allow_gripper_contact()
        print(HELP)
        self.show_pose()
        moves = {'w': (1, 0, 0), 's': (-1, 0, 0), 'a': (0, 1, 0), 'd': (0, -1, 0), 'r': (0, 0, 1), 'f': (0, 0, -1)}
        with RawTerminal() as term:
            while rclpy.ok():
                k = term.key(0.2)
                if k is None:
                    rclpy.spin_once(self, timeout_sec=0.0)
                    continue
                k = k.lower()
                if k == 'q':
                    break
                elif k in moves:
                    d = moves[k]
                    if not self.nudge(d[0] * self.step, d[1] * self.step, d[2] * self.step):
                        print('  blocked or failed, not moved')
                elif k in ('j', 'l'):
                    self.nudge(dyaw_deg=10.0 if k == 'j' else -10.0)
                elif k == '[':
                    self.step = max(0.001, self.step / 2.0)
                elif k == ']':
                    self.step = min(0.05, self.step * 2.0)
                elif k in (',', '.', '<', '>') or k.isdigit() and k != '0':
                    if k.isdigit():
                        self.grip_close = min(0.85, int(k) / 10.0)
                    else:
                        delta = {',': -0.02, '.': 0.02, '<': -0.10, '>': 0.10}[k]
                        self.grip_close = min(0.85, max(0.0, self.grip_close + delta))
                    if self.gripper_state == 'closed':         # live: re-command the gripper to the new value
                        if not self.gripper(self.grip_close):
                            print('  gripper command failed')
                elif k == 'o':
                    if self.gripper(pp.GRIP_OPEN):
                        self.gripper_state = 'open'
                elif k == 'c':
                    if self.gripper(self.grip_close):
                        self.gripper_state = 'closed'
                elif k == 'g':
                    if not self.holding:
                        self.holding = self.attach()
                    elif self.detach():
                        self.holding = False
                elif k == 'p':
                    self.save_waypoint()
                    term.flush()
                    continue
                elif k == 'h':
                    print(HELP)
                elif k != 'v':
                    continue
                term.flush()                      # discard keys pressed during the move
                self.show_pose()

    # ---- replay mode
    def replay(self, path):
        with open(path) as f:
            wps = yaml.safe_load(f)['waypoints']
        print(f'{len(wps)} waypoints from {path}; speed scaling {pp.SCALE}.')
        print('Run a path in simulation before the real arm. Supervisor present, E-stop in reach.')
        if input('Type YES to run: ').strip() != 'YES':
            return False
        self.allow_gripper_contact()
        for i, wp in enumerate(wps):
            if input(f'[{i + 1}/{len(wps)}] Enter to go to {wp["name"]} (q then Enter to stop): ').strip().lower() == 'q':
                return False
            pose = pose_from_list(wp['tip_pose'])
            ok = self.move_to_pose(pose) if i == 0 else self.cartesian_pose(pose)
            if not ok and i > 0 and input('Straight line not possible. Free-space plan instead? (y/n): ').strip().lower() == 'y':
                ok = self.move_to_pose(pose)
            if not ok:
                print('Stopped.')
                return False
            if wp['gripper'] == 'open' and self.gripper_state != 'open':
                ok = self.gripper(pp.GRIP_OPEN)
                self.gripper_state = 'open'
            elif wp['gripper'] == 'closed' and self.gripper_state != 'closed':
                ok = self.gripper(wp.get('grip_close', pp.GRIP_CLOSE))
                self.gripper_state = 'closed'
            if not ok:
                print('Gripper move failed. Stopped.')
                return False
            if wp['holding_block'] and not self.holding:
                self.holding = self.attach()
            elif not wp['holding_block'] and self.holding:
                self.holding = not self.detach()
        print('Replay finished.')
        return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--file', default='waypoints.yaml')
    ap.add_argument('--replay', metavar='FILE')
    ap.add_argument('--scale', type=float, default=pp.SCALE, help='speed scaling 0-1 (0.05 for the real arm)')
    ap.add_argument('--step', type=float, default=0.01, help='jog step in metres')
    ap.add_argument('--accel', type=float, default=None, help='acceleration scaling 0-1 (default: same as --scale)')
    args = ap.parse_args()
    pp.SCALE = args.scale
    pp.ACCEL_SCALE = args.accel
    rclpy.init()
    node = Teach(args)
    try:
        if args.replay:
            node.replay(args.replay)
        else:
            node.teach_loop()
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
