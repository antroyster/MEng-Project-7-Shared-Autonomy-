#!/usr/bin/env python3
"""MOCK WP3 scene publisher (clearly fake data) for testing wp3_scene_bridge.py without cameras.

Publishes /wp3_live/markers (visualization_msgs/MarkerArray, frame jenga_table) with a few resolved blocks as CUBE
markers in namespace 'wp3_blocks', the same format WP3's live node uses. Needs the TF world -> jenga_table
(python3 wp3_table_tf.py --xyz 0.30 0.00 -0.008 --yaw 0).

  python3 mock_wp3_publisher.py                  3 printed Jenga blocks (75 x 25 x 15 mm) lying flat
  python3 mock_wp3_publisher.py --wood           45 x 45 x 38 mm wooden props instead
  python3 mock_wp3_publisher.py --move           block 1 slides slowly back and forth (tests update / re-planning)
  python3 mock_wp3_publisher.py --drop-after 10  block 3 stops being published after 10 s (tests the grey 'unseen' state)

v4: listens to /twin/object_events, so a block the twin picks up and drops is then reported at its new place.

Positions are in the jenga_table frame (origin = centre of the 8 x 6 checkerboard, z up, on the table surface).
"""
import argparse
import math
import time

import json

import rclpy
from rclpy.node import Node
from rclpy.time import Time
from std_msgs.msg import String
from tf2_ros import Buffer, TransformListener
from visualization_msgs.msg import Marker, MarkerArray


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--wood', action='store_true')
    ap.add_argument('--move', action='store_true')
    ap.add_argument('--drop-after', type=float, default=None)
    ap.add_argument('--rate', type=float, default=5.0)
    args = ap.parse_args()
    size = (0.045, 0.045, 0.038) if args.wood else (0.075, 0.025, 0.015)
    # (id, x, y, yaw deg) in jenga_table
    # [id, x, y, yaw deg, z of the bottom] in jenga_table; changed when the twin drops a block somewhere else
    blocks = [[1, -0.04, 0.03, 0.0, 0.0], [2, 0.03, -0.02, 30.0, 0.0], [3, 0.08, 0.05, -20.0, 0.0]]
    held = set()

    rclpy.init()
    node = Node('mock_wp3_publisher')
    pub = node.create_publisher(MarkerArray, '/wp3_live/markers', 5)
    tf_buffer = Buffer()
    TransformListener(tf_buffer, node)

    def on_event(msg):
        """v4: the twin grasped / released a block. Like a camera would, report it where it now is."""
        try:
            ev = json.loads(msg.data)
            bid = int(str(ev['id']).rsplit('_', 1)[1])
        except Exception:
            return
        if ev.get('event') == 'grasped':
            held.add(bid)
            return
        if ev.get('event') != 'released':
            return
        held.discard(bid)
        try:
            t = tf_buffer.lookup_transform('jenga_table', 'world', Time())
        except Exception as e:
            node.get_logger().warning(f'no TF jenga_table <- world, cannot move block {bid}: {e}')
            return
        q, tr = t.transform.rotation, t.transform.translation
        yaw_t = math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))
        x, y, z = ev['xyz']
        c, s_ = math.cos(yaw_t), math.sin(yaw_t)
        xt, yt = c * x - s_ * y + tr.x, s_ * x + c * y + tr.y
        zt = z + tr.z - size[2] / 2.0
        for b in blocks:
            if b[0] == bid:
                b[1], b[2], b[3], b[4] = xt, yt, math.degrees(ev.get('yaw', 0.0) + yaw_t), zt
                node.get_logger().info(f'block {bid} now at ({xt:.3f}, {yt:.3f}) in jenga_table')

    node.create_subscription(String, '/twin/object_events', on_event, 10)
    t0 = time.monotonic()

    def tick():
        t = time.monotonic() - t0
        arr = MarkerArray()
        clear = Marker()
        clear.action = Marker.DELETEALL          # WP3's node does this every tick; the bridge ignores it
        arr.markers.append(clear)
        for bid, x, y, yaw, z0 in blocks:
            if bid in held:
                continue                         # in the gripper: the twin moves it, not the camera
            if bid == 3 and args.drop_after is not None and t > args.drop_after:
                continue
            if bid == 1 and args.move:
                x += 0.03 * math.sin(0.3 * t)
            m = Marker()
            m.header.frame_id = 'jenga_table'
            m.header.stamp = node.get_clock().now().to_msg()
            m.ns, m.id, m.type, m.action = 'wp3_blocks', bid, Marker.CUBE, Marker.ADD
            m.pose.position.x, m.pose.position.y, m.pose.position.z = x, y, z0 + size[2] / 2.0
            a = math.radians(yaw) / 2.0
            m.pose.orientation.z, m.pose.orientation.w = math.sin(a), math.cos(a)
            m.scale.x, m.scale.y, m.scale.z = size
            m.color.r, m.color.g, m.color.b, m.color.a = 0.95, 0.55, 0.10, 0.9
            arr.markers.append(m)
        pub.publish(arr)

    node.create_timer(1.0 / args.rate, tick)
    node.get_logger().info(f'MOCK WP3 publisher: {len(blocks)} fake blocks {size} m on /wp3_live/markers (not real detections)')
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    if rclpy.ok():
        rclpy.shutdown()


if __name__ == '__main__':
    main()
