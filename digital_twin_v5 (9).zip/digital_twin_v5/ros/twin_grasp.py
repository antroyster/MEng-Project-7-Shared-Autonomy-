#!/usr/bin/env python3
"""Pure geometry for automatic grasping in the twin (no ROS imports, so it is tested offline by test_twin_grasp.py).

When the gripper closes, the twin looks for a scene object whose body sits between the fingers and attaches it.
When the gripper opens, the object is released and 'falls' straight down onto whatever is under it
(the table, or the top of another object), so the twin matches what the real block does.
"""
import math

import numpy as np

XY_MARGIN = 0.012      # m: the fingertip may be this far outside the object's footprint and still grasp it
Z_ABOVE_TOP = 0.006    # m: the fingertips may be this far above the object's top (fingers just touching the top edge)
Z_BELOW_BOTTOM = 0.015 # m: and this far below its bottom (only possible when it sits on something soft / modelled low)
MAX_GRIP_WIDTH = 0.085 # m: xArm gripper V1 full opening; wider objects cannot be grasped

# objects that are part of the cell, never grasped and never something a block lands on except the table itself
FIXED_PREFIXES = ('table', 'fence', 'base_plate', 'power_box', 'camera')


def quat_to_matrix(q):
    x, y, z, w = q
    n = math.sqrt(x * x + y * y + z * z + w * w) or 1.0
    x, y, z, w = x / n, y / n, z / n, w / n
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                     [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                     [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def matrix_to_quat(R):
    t = R[0, 0] + R[1, 1] + R[2, 2]
    if t > 0:
        s = 0.5 / math.sqrt(t + 1.0)
        return ((R[2, 1] - R[1, 2]) * s, (R[0, 2] - R[2, 0]) * s, (R[1, 0] - R[0, 1]) * s, 0.25 / s)
    i = int(np.argmax([R[0, 0], R[1, 1], R[2, 2]]))
    if i == 0:
        s = 2.0 * math.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2])
        return (0.25 * s, (R[0, 1] + R[1, 0]) / s, (R[0, 2] + R[2, 0]) / s, (R[2, 1] - R[1, 2]) / s)
    if i == 1:
        s = 2.0 * math.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2])
        return ((R[0, 1] + R[1, 0]) / s, 0.25 * s, (R[1, 2] + R[2, 1]) / s, (R[0, 2] - R[2, 0]) / s)
    s = 2.0 * math.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1])
    return ((R[0, 2] + R[2, 0]) / s, (R[1, 2] + R[2, 1]) / s, 0.25 * s, (R[1, 0] - R[0, 1]) / s)


def compose(pose, prim):
    """World pose of a primitive: object pose (xyz, quat) then the primitive's pose relative to it."""
    R1, R2 = quat_to_matrix(pose[1]), quat_to_matrix(prim[1])
    xyz = R1 @ np.asarray(prim[0], float) + np.asarray(pose[0], float)
    return tuple(float(v) for v in xyz), matrix_to_quat(R1 @ R2)


def yaw_of(q):
    R = quat_to_matrix(q)
    return math.atan2(R[1, 0], R[0, 0])


def yaw_quat(yaw):
    return (0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0))


def is_fixed(oid):
    return oid.startswith(FIXED_PREFIXES)


def find_graspable(tip, objects):
    """tip = fingertip position (world). objects = [(id, dims(3), xyz, quat)] boxes in world.
    Returns the id of the object between the fingers, or None. Closest centre wins if several qualify."""
    best, best_d = None, 1e9
    for oid, dims, xyz, quat in objects:
        if is_fixed(oid):
            continue
        R = quat_to_matrix(quat)
        local = R.T @ (np.asarray(tip, float) - np.asarray(xyz, float))      # tip in the object's own frame
        hx, hy, hz = dims[0] / 2.0, dims[1] / 2.0, dims[2] / 2.0
        if abs(local[0]) > hx + XY_MARGIN or abs(local[1]) > hy + XY_MARGIN:
            continue
        top = xyz[2] + hz
        bottom = xyz[2] - hz
        if not (bottom - Z_BELOW_BOTTOM <= tip[2] <= top + Z_ABOVE_TOP):
            continue
        if min(dims[0], dims[1]) > MAX_GRIP_WIDTH:
            continue
        d = math.hypot(local[0], local[1])
        if d < best_d:
            best, best_d = oid, d
    return best


def support_height(xy, footprint_r, objects, floor_z, exclude=()):
    """Height the released object lands on: the highest top of any other loose object under it, else the table."""
    z = floor_z
    for oid, dims, xyz, quat in objects:
        if oid in exclude or is_fixed(oid):
            continue
        R = quat_to_matrix(quat)
        local = R.T @ np.array([xy[0] - xyz[0], xy[1] - xyz[1], 0.0])
        if abs(local[0]) <= dims[0] / 2.0 + footprint_r * 0.5 and abs(local[1]) <= dims[1] / 2.0 + footprint_r * 0.5:
            z = max(z, xyz[2] + dims[2] / 2.0)
    return z


def drop_pose(xyz, quat, dims, objects, floor_z, oid):
    """Pose after release: same x, y and yaw, flat, resting on what is underneath."""
    yaw = yaw_of(quat)
    rest = support_height(xyz[:2], min(dims[0], dims[1]) / 2.0, objects, floor_z, exclude=(oid,))
    return (float(xyz[0]), float(xyz[1]), rest + dims[2] / 2.0), yaw_quat(yaw)
