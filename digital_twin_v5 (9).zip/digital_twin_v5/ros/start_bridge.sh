#!/usr/bin/env bash
# WSL, terminal 2: receives the Etee data from the Windows reader and publishes /etee/joy.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source /opt/ros/jazzy/setup.bash
source ~/xarm_ws/install/setup.bash
cd "$HERE" && python3 etee_bridge.py
