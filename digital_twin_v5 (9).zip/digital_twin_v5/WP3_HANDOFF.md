# WP3 perception → digital twin: handoff for Hazem

From Shadi (WP3), 20 Nov 2026. This links WP3's three-camera v2 live perception node (`WP3-Live-Implementation-v2-Three-View`) directly into your WP2 MoveIt digital twin.

All bridge files in `digital_twin/ros/` are **drop-in additions** alongside `perception_bridge.py`. In this packaged copy of `digital_twin/`, `BASE_PLATE` in `ros/build_scene.py` has also been updated from `5 mm` to the measured **`8 mm`** clamp plate thickness (`BASE_PLATE = (0.14, 0.18, 0.008)`). See [`../START_HERE.md`](../START_HERE.md) for the complete end-to-end runbook.

## 1. Architecture & New Files

```text
 Lab desktop (Ubuntu 24.04, ROS_DOMAIN_ID=67, Fast DDS SHM)            Twin (same machine in tmux)
 wrist D435i (243222076754) ─┐
 side  D435  (244222070837) ─┼─> wp3_live_node ──/wp3_live/markers────────────> RViz (MarkerArray: blocks + labels + ambiguous)
 third D435  (317222074678) ─┘   (jenga_table)   /wp3_live/scene_observation ─> wp3_scene_bridge.py ──> MoveIt planning scene
                                       ▲                                               ▲   (objects wp3_blocks_<id>, frame world)
                                       └── TF  world ──> jenga_table (wp3_table_tf.py) ┘
```

| File in `digital_twin/ros/` | Purpose |
|---|---|
| `fit_table_tf.py` | Fits the rigid transform `world → jenga_table` from 4 checkerboard inner corners (`0, 7, 40, 47`) touched with the fingertip using `teach_keyboard.py` (`v` readout). Requires **RMS < 3 mm** and **max residual < 5 mm**. Writes `wp3_table_tf.yaml`. |
| `wp3_table_tf.py` | Publishes the latched static transform `world → jenga_table` from `wp3_table_tf.yaml` (or `--xyz X Y Z --yaw DEG` for quick sim testing). |
| `wp3_scene_bridge.py` | Multi-block MoveIt bridge. Subscribes to `/wp3_live/markers` (filtering to `wp3_blocks` CUBE markers by default so `wp3_ambiguous` envelopes stay display-only in RViz) or `/wp3_live/scene_observation` (`--use-scene-json`). Adds/moves each block when it shifts > 3 mm or > 2° (with 180° symmetry), greys it out after 2 s unseen, and skips any block attached to the gripper. |
| `start_wp3.sh` | Sources ROS 2 Jazzy + `xarm_ws` + Fast DDS SHM profile (`ROS_DOMAIN_ID=67`), starts `wp3_table_tf.py`, and runs `wp3_scene_bridge.py` (or stops at `--tf-only` for Stage 1 RViz verification). |
| `wp3_link.py`, `test_wp3_offline.py` | ROS-free Kabsch transform math, `board_corner_table_xyz` (matching WP3's `register_board.py` 8×6 `UNIT_GRID`), and `BlockTracker` bookkeeping (39 offline unit checks). |

## 2. Checkerboard Frame Convention (Resolved — No Longer TBC)

WP3's `scripts/register_board.py` uses an **8 × 6 inner-corner checkerboard** (nominal pitch **20.0 mm**) with `jenga_table` origin at the **centre of the grid**:
- **`+X` axis:** along the 8-corner direction (`col = 0 .. 7`)
- **`+Y` axis:** up the 6-corner direction (`row = 0 .. 5`)
- **`+Z` axis:** normal to the table, pointing up toward the cameras
- **Formula:** `x = (col - 3.5) * pitch_m`, `y = (2.5 - row) * pitch_m`, `z = 0.0`

When `register_board.py` saves `wrist_board.png`, `tripod_board.png`, and `third_board.png`, it draws red index numbers on the four outer inner-corners:
- **Corner `0`** (`col=0, row=0`): `(-0.070, +0.050, 0.000)` m
- **Corner `7`** (`col=7, row=0`): `(+0.070, +0.050, 0.000)` m
- **Corner `40`** (`col=0, row=5`): `(-0.070, -0.050, 0.000)` m
- **Corner `47`** (`col=7, row=5`): `(+0.070, -0.050, 0.000)` m

`fit_table_tf.py` computes these coordinates automatically when you give it 4-column lines (`corner_idx, world_x, world_y, world_z`).

## 3. Step-by-Step Run Order

1. **Offline & Replay Check:**
   - Run `python3 test_wp3_offline.py` (39 checks) and `pytest -q` in `WP3-Live-Implementation-v2-Three-View` (19 tests + zero-MoveIt audit).
   - Replay `display_replay` into RViz or your simulated twin (`start_sim.sh` + `start_wp3.sh`).
2. **Camera-to-Board Calibration (Step A):**
   - Start cameras (`bash scripts/start_camera.sh wrist`, `tripod`, `third`).
   - Run `python3 scripts/register_board.py "$cal" ../calibration/2026-11-19_board_orientation_reference.json --pitch-mm 20`.
   - Check `*_board.png` to confirm Corner `0` is the same physical corner in all 3 views, then run `python3 scripts/publish_board_tf.py "$cal/current_board_tf.json"`.
3. **Board-to-Robot Calibration (Step B):**
   - Without moving the board, run `bash start_real.sh` and `python3 teach_keyboard.py`.
   - Touch corners `0, 7, 40, 47` with the fingertip (`v`), save `points.csv`, and run `python3 fit_table_tf.py points.csv --pitch-mm 20`. Confirm **RMS < 3 mm** and **max < 5 mm**.
4. **Live Three-Camera Run:**
   - Launch WP3 v2 with all 3 cameras:
     ```bash
     bash scripts/launch_live.sh --policy whole_partition_mv \
         --config ros2_ws/src/wp3_live_perception/config/printed_jenga_live.json \
         --third-ns /perception/third --save-dir "$cal/live_three_view"
     ```
   - In `digital_twin/ros`, run `bash start_wp3.sh --tf-only` (Stage 1 display check), then `bash start_wp3.sh --remove-demo-block` (Stage 2 MoveIt scene sync).

## 4. Interface Options for WP2 & WP5

- **Default (Marker mode):** `wp3_scene_bridge.py` reads `/wp3_live/markers` (`visualization_msgs/MarkerArray`), filters to `ns="wp3_blocks"`, and places each `MEASURED` / `DISPLACED` block into MoveIt while leaving `ns="wp3_ambiguous"` yellow boxes visible in RViz only.
- **Direct JSON Contract mode (`--use-scene-json`):** `python3 wp3_scene_bridge.py --use-scene-json` (optionally with `--commit-eligible-only`) reads `/wp3_live/scene_observation` (`wp3_scene_observation_v2.1` schema), giving direct access to `validity_mask` (`x, y, z, roll, pitch, yaw`), `snapshot_commit_eligible`, `target_side_fresh`, `identity_ambiguous`, and `slot_occupancies`.
