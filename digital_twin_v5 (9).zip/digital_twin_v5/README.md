# Digital twin and hold-to-move control (WP2)

MoveIt 2 / RViz digital twin of the xArm 6 work cell (table, base plate, power box, Jenga block, boundary walls)
and a hold-to-move jogging system that drives the simulated **or real** arm from either:

| Input | Folder | Windows side | Notes |
|---|---|---|---|
| **Keyboard** | [`keyboard/`](keyboard/README.md) | `keyboard_reader_windows.py` | hold `W A S D R F`, release to stop |
| **Etee trackpads** | [`etee/`](etee/README.md) | `etee_reader_windows.py` | left pad = left/right + forward/back, right pad = up/down, squeezes = gripper |

Both feed the **same** ROS side in [`ros/`](ros/), so they share the limits, the table boundary, the slow constant
speed, the instant stop and the safety watchdog.

```
Windows                         WSL (Ubuntu 24.04, ROS 2 Jazzy)
 keyboard_reader_windows.py ─┐
                             ├─ TCP :5005 ─> etee_bridge.py ─> /etee/joy (sensor_msgs/Joy) ─> etee_hold.py
 etee_reader_windows.py    ──┘                                                                  │ MoveIt GetCartesianPath (collision checked)
                                                                                                └─> arm trajectory controller
```
The bridge takes **one Windows sender at a time**. Run the keyboard reader *or* the Etee reader, not both.

## Requirements
- Ubuntu 24.04 (WSL is fine), ROS 2 Jazzy, the `xarm_ros2` Jazzy workspace built at `~/xarm_ws`
  (packages `xarm_api`, `xarm_description`, `xarm_moveit_config`).
- Real arm: wired Ethernet, laptop static IP `192.168.1.10 / 255.255.255.0` (no gateway), arm at `192.168.1.214`.
- Windows Python 3.12+. The keyboard reader needs nothing else. The Etee reader needs the official
  [etee-Python-API](https://github.com/eteeXR/etee-Python-API) (`python -m pip install -r requirements.txt` in that folder).

## One-time setup (Ubuntu)
```bash
cd <repo>/digital_twin/ros
python3 add_extension.py            # adds the 7 cm tool extension cylinder to the arm model (--undo reverts)
python3 add_camera.py               # then adds the bracket + wrist RealSense D435i (--undo reverts only the camera)
cd ~/xarm_ws && colcon build --packages-select xarm_description xarm_moveit_config && source install/setup.bash
```
Without this step RViz shows the fingertips 7 cm higher than the real arm; the software limits already assume 0.242 m
from the flange to the fingertips (`TCP_OFFSET_Z` in `build_scene.py`).

### Wrist camera (WP3)
`add_camera.py` puts the D435i bracket at the gripper end of the extension and the camera beside the gripper on the
`link_eef` +x side, lenses along the tool axis (pointing down at home), as in the CAD assembly
(`UFACTORY xArm 6 & RealSense D435i CAD Assembly.html`). The gripper does not move, so `TCP_OFFSET_Z` is unchanged.
- New links: `d435i_bracket`, `wrist_camera_link` (D435i body as a 90 x 25 x 25 mm collision box, so MoveIt now
  keeps the camera off the table, walls and arm). `wrist_camera_link` sits at **(67.5, -17.5, 90.7) mm in `link_eef`**.
- That pose is the **nominal CAD value, not measured**. When WP3 has a hand-eye result, rerun with it:
  `python3 add_camera.py --undo && python3 add_camera.py --xyz X Y Z --rpy R P Y` (bracket frame, metres/radians).
- Start the wrist camera with `camera_name:=wrist_camera` (or pass `--camera-name` to match the name you use), so the
  driver's optical frames hang off `wrist_camera_link`. Only `wrist_camera_link` is in the URDF; the driver publishes the rest.
- The camera sticks out about 80 mm from the tool axis, more than `GRIPPER_RADIUS` (0.05 m) in `build_scene.py`.
  The collision walls still stop it in planning, but raise `GRIPPER_RADIUS` to about 0.085 if you want the software limit to cover it.

## Run it (simulation first, always)
All Ubuntu windows: `cd <repo>/digital_twin/ros`, and `etee_hold.py` / `etee_check.py` need
`source /opt/ros/jazzy/setup.bash; source ~/xarm_ws/install/setup.bash` first.

1. **Window 1** `bash start_sim.sh` (fake arm + MoveIt + RViz, moved to the real home pose, scene built).
   Real arm instead: `bash start_real.sh` (checks the network, launches MoveIt with the gripper, builds the scene).
2. **Window 2** `bash start_bridge.sh`
3. **Window 3** `python3 etee_hold.py`, type `YES`, wait for `armed`
4. **Windows**: start the keyboard reader or the Etee reader (see the folder READMEs).

Check the controls without moving anything: `python3 etee_check.py` (prints FORWARD / UP / CLOSE ...).
Check planning without moving anything: `python3 plan_probe.py`.

## Safety and limits
- Supervisor present, E-stop in reach, simulation first. Real arm: keep the default 0.01 m/s.
- Nothing moves until the input has been at rest for 0.5 s (`armed`). Stale input stops the arm.
- Fingertip limits (`etee_hold.py` / `build_scene.py`): table top, reach x 0.12..0.55 m, ceiling z 0.40 m, and the
  **table boundary**: three faint red walls 4 cm inside the table edge (left, right, far; none on the robot's own edge)
  plus a software limit 5 cm further in. Tune `FENCE_MARGIN`, `FENCE_HEIGHT`, `GRIPPER_RADIUS` in `build_scene.py`.
- The arm stops itself within 4 mm of a limit (it reads the real fingertip position, not just the plan).
- Paths with an IK flip are refused. A watchdog holds the arm if it keeps moving after a stop.
- Moves go straight to the arm's trajectory controller (found automatically); MoveIt's execution layer queues
  goals and was the cause of a runaway during testing, so it is not used for jogging.

## Scene geometry (world frame, robot base at the origin, z up)
Base plate 0.14 x 0.18 x 0.005 m; table 1.40 x 0.70 m top (0.80 m high), robot clamped 0.07 m in from a short edge;
power box 0.29 x 0.14 x 0.11 m at (0.25, -0.26) **(placeholder, measure it)**; Jenga block 0.045 x 0.045 x 0.04 m at
(0.26, 0.0). Real home pose (rad): `[-0.0086, -0.9809, -0.9284, 0.0141, 1.9111, -0.0140]` (`go_home.py`).
Gripper: xArm Gripper V1, MoveIt group `xarm_gripper`, closed = 0.85 (the block stalls the fingers).

## For the perception module (WP5)
`perception_bridge.py` reads `/perception/block_pose` (`geometry_msgs/PoseStamped`, frame `world` or `link_base`)
and moves the `jenga_block` collision object in the MoveIt scene. Test without a camera:
`python3 perception_bridge.py --fake --x 0.26 --y 0.0 --yaw 0`. `pick_place_sim.py` has the pick/place routines and
the base class (`PickPlace`) other tools build on; it reads the block pose from the planning scene.

## Other tools in `ros/`
| File | Purpose |
|---|---|
| `teach_keyboard.py` | step-based keyboard teaching with MoveIt (`w s a d r f`, grip keys, save waypoints) |
| `plan_probe.py` | plans the six jog directions and says why any fail (never moves) |
| `joint_watch.py` | records `/joint_states` and shows whether joints really jump |
| `go_home.py` | moves the *simulated* arm to the real home pose |
| `add_camera.py` | adds the wrist D435i + bracket to the URDF/SRDF (run after `add_extension.py`) |
| `xarm_kin.py`, `etee_input.py` | kinematics and input mapping (no ROS), unit-tested by `test_offline.py` |

`python3 test_offline.py` runs the ROS-free checks.

## Known limitations
- MoveIt returns only a few waypoints per path (2 to 3 cm apart), so its collision check between them is coarse. Keep clear of obstacles.
- Power box position is a placeholder.
- The Etee tilt steering in `etee_reader_windows.py --tilt` is experimental and was not validated.
- Real-arm hold-to-move should be commissioned step by step with the supervisor (slowest speed first).

## Status (update when you test)
- [ ] Simulation: keyboard hold-to-move
- [ ] Simulation: Etee hold-to-move
- [ ] Real arm: keyboard, `--speed 0.005`
- [ ] Real arm: Etee, `--speed 0.005`
- [ ] Paper test: fingertip on the table reads z about -0.005 in `teach_keyboard.py` (`v`)
