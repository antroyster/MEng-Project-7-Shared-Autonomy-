#!/usr/bin/env python3
r"""WINDOWS. Shows what the Etee tilt sensor (IMU) reports, so the arm control can be built on real numbers.

  cd ~\etee-Python-API
  python etee_imu_probe.py

It prints the docs of the sensor functions once, then every half second the raw values for both hands.
Hold the controller flat, then tilt it forward, back, left, right, and twist it. Paste what it prints.
"""
import time

from etee import EteeController

e = EteeController()
e.connect()
e.start_data()
e.run()

for name in ('get_euler', 'get_quaternion', 'get_accel', 'get_gyro'):
    print(f'--- {name} ---')
    print(getattr(e, name).__doc__ or '(no docstring)')
print('absolute_imu_enabled =', getattr(e, 'absolute_imu_enabled', '?'))

t0 = time.time()
while time.time() - t0 < 10 and e.get_trackpad_x('left') is None and e.get_trackpad_x('right') is None:
    time.sleep(0.1)
print('\nTilt the controller now. Ctrl+C to stop.\n')
try:
    while True:
        for hand in ('left', 'right'):
            try:
                eu, q, ac, gy = e.get_euler(hand), e.get_quaternion(hand), e.get_accel(hand), e.get_gyro(hand)
            except Exception as ex:
                print(hand, 'error:', ex)
                continue
            print(f'{hand:5s} euler={eu}  quat={q}  accel={ac}  gyro={gy}')
        print()
        time.sleep(0.5)
except KeyboardInterrupt:
    pass
