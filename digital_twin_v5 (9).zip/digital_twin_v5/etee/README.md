# Etee trackpad control

| Input | Action |
|---|---|
| Left pad up / down | forward / back |
| Left pad left / right | left / right |
| Right pad up / down | up / down |
| Right trackpad press / left trackpad press | close / open gripper (`--grip-source squeeze` for the old squeeze buttons) |

No enable button on the pads. With `--tilt`: squeeze the right controller and tilt = forward/back/left/right; squeeze the left controller and tilt forward/back = up/down. Experimental.

## One-time setup (Windows)
```powershell
git clone https://github.com/eteeXR/etee-Python-API
cd etee-Python-API
python -m pip install -r requirements.txt        # run scripts from this folder; do not pip install the package
copy <repo>\digital_twin\etee\etee_reader_windows.py .
copy <repo>\digital_twin\etee\etee_imu_probe.py .
```
Controllers connect over USB (the library finds the COM port); check Device Manager > Ports if not.

## Steps
1. **Ubuntu**: `bash start_sim.sh` (window 1), `bash start_bridge.sh` (window 2), then window 3:
   `source /opt/ros/jazzy/setup.bash; source ~/xarm_ws/install/setup.bash; python3 etee_check.py`.
2. **PowerShell** in `etee-Python-API`: `python etee_reader_windows.py` (keyboard reader must be off).
   `--print` shows the raw readings; `--flip-y` / `--swap-grips` fix reversed pads / hands.
3. In `etee_check.py` check: left pad up prints FORWARD, right pad up prints UP, a resting thumb prints `nothing`. Ctrl+C.
4. Window 3: `python3 etee_hold.py`, type `YES`, release both pads until `armed`, then push.
   Feel: `--deadzone 0.45` / `--curve 2.0` for less sensitive, `--deadzone 0.2 --curve 1.2` for more.

`etee_imu_probe.py` prints the controllers' tilt sensor values (used to explore tilt steering, `--tilt`, experimental).

## 3D controller view in the GUI (v5)

Nothing extra to install: the normal reader now also sends each controller's orientation (from its own motion
sensor) and acceleration. In the GUI's Etee panel both controllers turn as you turn them, sway and leave a trail
when you move them, and their ring lights up while moving.

- Hold both controllers upright and press **Recentre** to set "upright" on screen.
- If the controllers turn the wrong way or look scrambled, run `python etee_imu_probe.py`, hold a controller level
  and look at `quat=`. If the number near 1 is first, the default is right; if it is last, start the reader with
  `--quat-order xyzw`.
- The status under the view says **Live: orientation + movement** when it works. **Tilt + movement** means the
  sensor sent no orientation, so only tilt from the accelerometer is shown (no twist).
- The view shows turning and movement, not where the controller is in the room: the sensor cannot measure position.
