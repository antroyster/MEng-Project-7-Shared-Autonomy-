#!/usr/bin/env bash
# v5: starts the GUI side: rosbridge (port 9090) + the GUI web server (port 8000). Ctrl+C stops both.
# Run it AFTER start_sim.sh (or start_real.sh) and etee_hold.py. Then open http://localhost:8000 in Windows.
source /opt/ros/jazzy/setup.bash
source ~/xarm_ws/install/setup.bash
export ROS_DOMAIN_ID=67 ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
cd "$(dirname "$0")"
if ! ros2 pkg prefix rosbridge_server >/dev/null 2>&1; then
  echo "rosbridge is not installed: sudo apt install -y ros-jazzy-rosbridge-suite"; exit 1
fi
ros2 launch rosbridge_server rosbridge_websocket_launch.xml > /tmp/rosbridge.log 2>&1 &
BRIDGE=$!
trap 'kill $BRIDGE 2>/dev/null; echo "GUI stopped"' EXIT INT TERM
sleep 2
echo "rosbridge running (log: /tmp/rosbridge.log)"
python3 twin_gui_server.py "$@"
