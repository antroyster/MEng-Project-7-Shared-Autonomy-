# Digital twin GUI (v5)

A browser app for the xArm digital twin: a live 3D view of the robot and its environment, a Keyboard mode
(on-screen keycaps, hold to move) and an Etee mode (live view of both controllers), plus status, limits and events.

## Start
One command, from the digital_twin_v5 folder (no setup lines needed, no RViz):
```
bash twin.sh              # simulation with 3 mock blocks, top speed 50 mm/s
bash twin.sh --real       # the real arm (asks YES), top speed 30 mm/s
bash twin.sh --help       # all options (--speed, --wp3, --no-mock, --rviz)
```
It opens http://localhost:8000 in Windows. For Etee mode, also start the Etee reader in Windows.
Logs are in ~/twin_logs/. Ctrl+C stops everything.

## How it works
```
Browser (index.html, app.js, scene3d.js)
  |-- HTTP  :8000  twin_gui_server.py  -> /robot.urdf, robot meshes (/pkg/...), /scene.json (MoveIt scene as boxes)
  '-- WebSocket :9090  rosbridge       -> /joint_states, /twin/state, /etee/joy, /twin/object_events  (read)
                                        -> /twin/cmd_vel, /twin/gripper_cmd                           (Keyboard mode only)
ROS 2: etee_hold.py is still the only node that moves the arm; every GUI command passes its limits,
collision checks, watchdog and lift-before-close.
```
- 3D: three.js draws the robot from its URDF (urdf-loader) and sets its joints from /joint_states; the table,
  fence, power box and blocks come from MoveIt's planning scene, so the GUI shows exactly what the planner uses.
- Keyboard mode publishes a velocity 20 times a second while the page has focus. If the page, browser or network
  stops, the hold node stops the arm 0.3 s later: safety does not depend on the GUI.
- Etee mode only displays /etee/joy; the controllers drive the arm through etee_bridge.py as before.
- The 3D libraries (three.js, urdf-loader, roslib) load from the internet (jsdelivr). Without internet the
  controls and status still work, without the 3D view.
