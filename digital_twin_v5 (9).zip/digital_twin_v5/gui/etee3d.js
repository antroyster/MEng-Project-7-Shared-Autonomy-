// Live 3D view of the two Etee controllers, like controllers shown in a VR headset, but on the screen.
// Needs only the Etee dongle: no SteamVR, no headset, no base stations.
//  - Orientation (/etee/orientation): each controller's own motion sensor gives its full 3D orientation, so the
//    model turns exactly as you turn your hand (relative to how you held it at Recentre).
//  - Movement (/etee/accel): the extra acceleration beyond gravity makes the model sway in the direction you
//    move, lights its ring and draws a short trail from its tip. The sensor cannot give absolute position
//    (that would drift within seconds), so the sway springs back to the middle when you stop.
//  - If a controller sends no orientation, its tilt comes from the accelerometer instead (no twist).
import * as THREE from 'three';

const FRESH_MS = 500;
const MOVE_ACC = 0.06;            // g of extra acceleration above which a controller counts as moving
const MOVE_TURN = 0.8;            // rad/s of turning above which it counts as moving
const SWAY = 0.08;                // metres of on-screen sway per g of movement
const TRAIL = 40;
// controller axes -> view axes: the controller's z points up the screen, its y points away from you
const AXES = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), -Math.PI / 2);
const AXES_INV = AXES.clone().invert();

function controllerModel(colour) {
  // Upright handle (like the Etee): trackpad on top, finger bands around the grip, coloured ring at the base.
  const g = new THREE.Group();
  const dark = new THREE.MeshStandardMaterial({ color: 0x2a323d, roughness: 0.55, metalness: 0.15 });
  g.add(new THREE.Mesh(new THREE.CapsuleGeometry(0.024, 0.11, 8, 24), dark));
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.03, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2), dark);
  head.position.y = 0.075;
  g.add(head);
  const pad = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.004, 32),
    new THREE.MeshStandardMaterial({ color: 0x0d1218, roughness: 0.3 }));
  pad.position.set(0, 0.098, 0);
  g.add(pad);
  for (let k = 0; k < 4; k++) {                    // finger sensors
    const band = new THREE.Mesh(new THREE.TorusGeometry(0.0255, 0.0025, 8, 32, Math.PI),
      new THREE.MeshStandardMaterial({ color: 0x46505c, roughness: 0.4 }));
    band.rotation.set(Math.PI / 2, 0, Math.PI);
    band.position.y = 0.035 - k * 0.022;
    g.add(band);
  }
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.026, 0.004, 12, 48),
    new THREE.MeshStandardMaterial({ color: colour, emissive: colour, emissiveIntensity: 0.15 }));
  ring.rotation.x = Math.PI / 2;
  ring.position.y = -0.075;
  g.add(ring);
  const tip = new THREE.Object3D();                // the trail is drawn from here
  tip.position.y = 0.1;
  g.add(tip);
  g.userData = { ring, tip };
  return g;
}

export class EteeMotion {
  constructor(container, onMode) {
    this.container = container;
    this.onMode = onMode || (() => {});
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(this.renderer.domElement);
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(38, 1, 0.01, 20);
    this.camera.position.set(0, 0.2, 0.75);
    this.camera.lookAt(0, 0.0, 0);
    this.scene.add(new THREE.HemisphereLight(0xdde8ff, 0x10151c, 1.1));
    const key = new THREE.DirectionalLight(0xffffff, 1.3);
    key.position.set(0.5, 1, 0.8);
    this.scene.add(key);
    const grid = new THREE.GridHelper(1.2, 12, 0x2a3a4d, 0x18212c);
    grid.position.y = -0.16;
    this.scene.add(grid);

    this.hands = {};
    for (const [hand, colour, x] of [['left', 0x3ea6ff, -0.13], ['right', 0xf0883e, 0.13]]) {
      const model = controllerModel(colour);
      model.position.set(x, 0, 0);
      this.scene.add(model);
      const shadow = new THREE.Mesh(new THREE.CircleGeometry(0.035, 32),
        new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.35 }));
      shadow.rotation.x = -Math.PI / 2;
      shadow.position.set(x, -0.159, 0);
      this.scene.add(shadow);
      const trailGeo = new THREE.BufferGeometry();
      trailGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(TRAIL * 3), 3));
      trailGeo.setDrawRange(0, 0);
      const trail = new THREE.Line(trailGeo, new THREE.LineBasicMaterial({ color: colour, transparent: true, opacity: 0.7 }));
      this.scene.add(trail);
      this.hands[hand] = { model, shadow, trail, home: x, pts: [],
        q: null, q0: null, qT: 0, turn: 0,
        acc: null, accT: 0, low: null, g0: null, hp: new THREE.Vector3(), dyn: 0,
        sway: new THREE.Vector3(), moving: false };
    }
    window.addEventListener('resize', () => this.resize());
    this.resize();
    this.mode = '';
    this.lastT = performance.now();
    const tick = () => { requestAnimationFrame(tick); if (this.container.offsetParent) this.update(); };
    tick();
  }

  resize() {
    const w = this.container.clientWidth || 300, h = this.container.clientHeight || 180;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  setOrientation(data) {                            // [lx, ly, lz, lw, rx, ry, rz, rw, left ok, right ok]
    const now = performance.now();
    [['left', 0, 8], ['right', 4, 9]].forEach(([hand, i, ok]) => {
      if (!data[ok]) return;
      const s = this.hands[hand];
      const q = new THREE.Quaternion(data[i], data[i + 1], data[i + 2], data[i + 3]).normalize();
      if (s.q && s.qT) {                             // turning speed, for the "moving" light
        const dt = Math.max((now - s.qT) / 1000, 1e-3);
        s.turn = s.turn * 0.7 + (s.q.angleTo(q) / dt) * 0.3;
      }
      s.q = q; s.qT = now;
      if (!s.q0) s.q0 = q.clone();
    });
  }

  setAccel(data) {                                  // [lx, ly, lz, rx, ry, rz, left ok, right ok] in g
    const now = performance.now();
    [['left', 0, 6], ['right', 3, 7]].forEach(([hand, i, ok]) => {
      if (!data[ok]) return;
      const s = this.hands[hand];
      const a = new THREE.Vector3(data[i], data[i + 2], -data[i + 1]);   // controller axes -> view axes
      s.low = s.low ? s.low.lerp(a, 0.12) : a.clone();                   // slow part = gravity
      s.hp = a.clone().sub(s.low);                                       // fast part = your movement
      s.dyn = s.dyn * 0.8 + s.hp.length() * 0.2;
      if (!s.g0) s.g0 = s.low.clone();
      s.acc = a; s.accT = now;
    });
  }

  recentre() {                                      // "the way I hold them now is upright"
    Object.values(this.hands).forEach((s) => {
      s.q0 = s.q ? s.q.clone() : null;
      s.g0 = s.low ? s.low.clone() : null;
      s.pts = [];
    });
  }

  update() {
    const now = performance.now();
    const dt = Math.min((now - this.lastT) / 1000, 0.1);
    this.lastT = now;
    let mode = 'none';
    for (const s of Object.values(this.hands)) {
      const oriented = s.q && now - s.qT < FRESH_MS;
      const accel = s.acc && now - s.accT < FRESH_MS;
      // ---- orientation
      let target = new THREE.Quaternion();
      if (oriented) {
        mode = 'orientation';
        const rel = s.q.clone().multiply(s.q0.clone().invert());          // turn since Recentre
        target = AXES.clone().multiply(rel).multiply(AXES_INV);
      } else if (accel) {
        if (mode === 'none') mode = 'tilt';
        target = new THREE.Quaternion().setFromUnitVectors(s.low.clone().normalize(), s.g0.clone().normalize());
      }
      s.model.quaternion.slerp(target, oriented ? 0.45 : 0.25);
      // ---- movement: sway in the direction of the push, spring back when it stops
      const push = accel ? s.hp.clone().clampLength(0, 0.8).multiplyScalar(SWAY) : new THREE.Vector3();
      s.sway.lerp(push, Math.min(1, dt * 12));
      s.model.position.set(s.home + s.sway.x, s.sway.y, s.sway.z);
      s.shadow.position.x = s.model.position.x;
      s.shadow.position.z = s.model.position.z;
      s.moving = !!((accel && s.dyn > MOVE_ACC) || (oriented && s.turn > MOVE_TURN));
      // ---- ring light and trail from the tip
      const ring = s.model.userData.ring.material;
      ring.emissiveIntensity += ((s.moving ? 1.8 : (oriented || accel ? 0.35 : 0.05)) - ring.emissiveIntensity) * 0.2;
      if (s.moving) {
        s.model.updateMatrixWorld();
        s.pts.push(s.model.userData.tip.getWorldPosition(new THREE.Vector3()));
        if (s.pts.length > TRAIL) s.pts.shift();
      } else if (s.pts.length) s.pts.shift();
      const arr = s.trail.geometry.attributes.position;
      s.pts.forEach((v, k) => arr.setXYZ(k, v.x, v.y, v.z));
      arr.needsUpdate = true;
      s.trail.geometry.setDrawRange(0, s.pts.length);
    }
    if (mode !== this.mode) { this.mode = mode; this.onMode(mode); }
    this.renderer.render(this.scene, this.camera);
  }

  moving(hand) { return !!(this.hands[hand] && this.hands[hand].moving); }
}
