// 3D view of the twin: the xArm from its URDF, the planning-scene objects, and the fingertip marker.
// ROS uses z-up metres; three.js uses y-up. Everything ROS-side lives in `ros`, a group turned -90 deg about x.
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import URDFLoader from 'urdf-loader';

const COLOURS = {
  table: 0x2b3440, base_plate: 0x8a96a6, power_box: 0x3a3f46, fence: 0xf85149,
  block: 0xf0883e, held: 0x3fb950, unseen: 0x8b98a8, other: 0x6e7781,
};

export class TwinScene {
  constructor(container, onStatus) {
    this.container = container;
    this.onStatus = onStatus || (() => {});
    this.objects = new Map();          // scene object id -> mesh
    this.robot = null;
    this.pendingJoints = null;
    this.jointTarget = {};             // v6: joints glide to the latest reading instead of jumping 10 times a second
    this.clock = new THREE.Clock();

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0d1117);
    this.scene.fog = new THREE.Fog(0x0d1117, 4, 9);

    this.camera = new THREE.PerspectiveCamera(45, 1, 0.01, 50);
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.resetView();

    // lights
    this.scene.add(new THREE.HemisphereLight(0xdde8ff, 0x1a1f26, 0.9));
    const sun = new THREE.DirectionalLight(0xffffff, 1.6);
    sun.position.set(1.5, 3, 2);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    Object.assign(sun.shadow.camera, { left: -1.5, right: 1.5, top: 1.5, bottom: -1.5, near: 0.5, far: 8 });
    this.scene.add(sun);

    // floor grid far below the table, for depth
    const grid = new THREE.GridHelper(8, 32, 0x223040, 0x161d26);
    grid.position.y = -0.808;
    this.scene.add(grid);

    // everything in ROS coordinates goes in here
    this.ros = new THREE.Group();
    this.ros.rotation.x = -Math.PI / 2;
    this.scene.add(this.ros);

    // fingertip marker: a glowing dot and a dashed drop line to the table
    this.tip = new THREE.Mesh(new THREE.SphereGeometry(0.008, 24, 16),
      new THREE.MeshBasicMaterial({ color: 0x3ea6ff }));
    this.tip.visible = false;
    this.ros.add(this.tip);
    const lineGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
    this.drop = new THREE.Line(lineGeo, new THREE.LineDashedMaterial({ color: 0x3ea6ff, dashSize: 0.01, gapSize: 0.008 }));
    this.drop.visible = false;
    this.ros.add(this.drop);
    this.ring = new THREE.Mesh(new THREE.RingGeometry(0.012, 0.016, 32),
      new THREE.MeshBasicMaterial({ color: 0x3ea6ff, transparent: true, opacity: 0.8, side: THREE.DoubleSide }));
    this.ring.visible = false;
    this.ros.add(this.ring);
    this.tableTop = -0.008;

    window.addEventListener('resize', () => this.resize());
    this.resize();
    this.renderer.setAnimationLoop(() => {
      const dt = Math.min(this.clock.getDelta(), 0.1);
      this.stepJoints(dt);
      this.stepObjects(dt);
      this.controls.update();
      this.renderer.render(this.scene, this.camera);
    });
  }

  resetView() {
    // look at the work area from the front-right, a little above (three.js coordinates: x fwd, y up, z = -left)
    this.camera.position.set(1.25, 0.75, 0.95);
    this.controls.target.set(0.35, 0.05, 0);
    this.controls.update();
  }

  resize() {
    const w = this.container.clientWidth, h = this.container.clientHeight;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / Math.max(h, 1);
    this.camera.updateProjectionMatrix();
  }

  async loadRobot(url) {
    this.onStatus('loading robot model…');
    const text = await (await fetch(url, { cache: 'no-store' })).text();
    if (!text.trim().startsWith('<')) throw new Error(text);
    const manager = new THREE.LoadingManager();
    const loader = new URDFLoader(manager);
    loader.packages = (pkg) => `${location.origin}/pkg/${pkg}`;
    const robot = loader.parse(text);
    manager.onLoad = () => {
      this.meshesLoaded = true;
      const metal = new THREE.MeshStandardMaterial({ color: 0xd7dde5, metalness: 0.35, roughness: 0.45 });
      const dark = new THREE.MeshStandardMaterial({ color: 0x30363d, metalness: 0.2, roughness: 0.6 });
      robot.traverse(o => {
        if (o.isMesh) {
          const n = (o.parent && o.parent.name || '').toLowerCase() + (o.name || '').toLowerCase();
          o.material = /finger|knuckle|gripper/.test(n) ? dark : metal;
          o.castShadow = true;
          o.receiveShadow = true;
        }
      });
      this.onStatus('');
    };
    this.robot = robot;
    this.ros.add(robot);
    if (this.pendingJoints) this.setJoints(...this.pendingJoints);
    return robot;
  }

  setJoints(names, positions) {
    if (!this.robot) { this.pendingJoints = [names, positions]; return; }
    for (let i = 0; i < names.length; i++) {
      const j = this.robot.joints[names[i]];
      if (!j) continue;
      if (!(names[i] in this.jointTarget)) j.setJointValue(positions[i]);   // first reading: no glide
      this.jointTarget[names[i]] = positions[i];
    }
  }

  stepJoints(dt) {
    // glide each joint toward its latest reading (time constant ~70 ms: smooth, hardly any lag)
    if (!this.robot) return;
    const k = 1 - Math.exp(-dt / 0.07);
    for (const [name, target] of Object.entries(this.jointTarget)) {
      const j = this.robot.joints[name];
      if (!j) continue;
      const now = j.angle !== undefined ? Number(j.angle) : target;
      const next = Math.abs(target - now) < 1e-5 ? target : now + (target - now) * k;
      j.setJointValue(next);
    }
  }

  stepObjects(dt) {
    // v6: animate blocks between scene snapshots: a fall with gravity (and a small settle) when dropped,
    // a quick glide otherwise
    const now = performance.now() / 1000;
    for (const m of this.objects.values()) {
      const a = m.userData.anim;
      if (!a) continue;
      const t = Math.min(1, (now - a.t0) / a.dur);
      let e;
      if (a.fall) {                                  // gravity: distance grows with t^2, then a small bounce
        const tf = 0.82;
        e = t < tf ? (t / tf) ** 2 : 1 + 0.06 * Math.sin(((t - tf) / (1 - tf)) * Math.PI) * -1;
      } else {
        e = 1 - (1 - t) ** 3;                        // ease out
      }
      m.position.lerpVectors(a.p0, a.p1, e);
      m.quaternion.slerpQuaternions(a.q0, a.q1, Math.min(1, t * 1.4));
      if (t >= 1) { m.position.copy(a.p1); m.quaternion.copy(a.q1); m.userData.anim = null; }
    }
  }

  animateTo(m, pos, quat, fall) {
    const p1 = new THREE.Vector3(...pos), q1 = new THREE.Quaternion(...quat);
    const a = m.userData.anim;
    if (a && a.p1.distanceTo(p1) < 0.0005) return;              // already heading there
    if (!a && m.position.distanceTo(p1) < 0.0005 && m.quaternion.angleTo(q1) < 0.002) return;
    const h = Math.max(0, m.position.z - p1.z);                 // ros frame: z up
    const dur = fall ? Math.max(0.28, Math.sqrt((2 * h) / 9.81) * 1.6 + 0.12) : 0.22;
    m.userData.anim = { p0: m.position.clone(), p1, q0: m.quaternion.clone(), q1,
                        t0: performance.now() / 1000, dur, fall };
  }

  setFingertip(p) {
    const show = Array.isArray(p);
    this.tip.visible = this.drop.visible = this.ring.visible = show;
    if (!show) return;
    this.tip.position.set(p[0], p[1], p[2]);
    const pos = this.drop.geometry.attributes.position;
    pos.setXYZ(0, p[0], p[1], p[2]);
    pos.setXYZ(1, p[0], p[1], this.tableTop + 0.0005);
    pos.needsUpdate = true;
    this.drop.computeLineDistances();
    this.ring.position.set(p[0], p[1], this.tableTop + 0.0008);
  }

  colourFor(o) {
    if (o.held) return { c: COLOURS.held, a: 0.95 };
    const id = o.id;
    if (id === 'table') return { c: COLOURS.table, a: 1 };
    if (id.startsWith('fence')) return { c: COLOURS.fence, a: 0.16 };
    if (id === 'base_plate') return { c: COLOURS.base_plate, a: 1 };
    if (id === 'power_box') return { c: COLOURS.power_box, a: 1 };
    if (o.colour && o.colour[0] < 0.7 && Math.abs(o.colour[0] - o.colour[1]) < 0.05) return { c: COLOURS.unseen, a: 0.5 };
    if (id.startsWith('wp3') || id.includes('block')) return { c: COLOURS.block, a: 0.95 };
    return { c: COLOURS.other, a: 1 };
  }

  setObjects(list) {
    const seen = new Set();
    for (const o of list) {
      const key = o.id;
      seen.add(key);
      let m = this.objects.get(key);
      const { c, a } = this.colourFor(o);
      const fresh = !m;
      if (!m) {
        m = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1),
          new THREE.MeshStandardMaterial({ roughness: 0.7, metalness: 0.05, transparent: a < 1 }));
        m.castShadow = !o.id.startsWith('fence');
        m.receiveShadow = true;
        if (o.id === 'table') {
          const edges = new THREE.LineSegments(new THREE.EdgesGeometry(m.geometry),
            new THREE.LineBasicMaterial({ color: 0x3ea6ff, transparent: true, opacity: 0.25 }));
          m.add(edges);
        }
        this.ros.add(m);
        this.objects.set(key, m);
      }
      m.material.color.setHex(c);
      m.material.opacity = a;
      m.material.transparent = a < 1;
      m.material.depthWrite = a >= 0.5;
      m.scale.set(o.size[0], o.size[1], o.size[2]);
      if (o.id === 'table') this.tableTop = o.pos[2] + o.size[2] / 2;

      const link = o.held && o.link && this.robot && this.robot.links ? this.robot.links[o.link] : null;
      if (link) {
        // held: fixed to the gripper link, so it moves with the drawn robot every frame
        if (m.parent !== link) {
          link.attach(m);                            // keep where it is drawn now, then glide into the grip
          m.userData.anim = null;
          m.scale.set(o.size[0], o.size[1], o.size[2]);
        }
        this.animateTo(m, o.local_pos, o.local_quat, false);
        continue;
      }
      if (m.parent !== this.ros) {                   // just released: back into the world from where it was
        this.ros.attach(m);
        m.userData.releasedAt = performance.now();
        m.userData.anim = null;
        m.scale.set(o.size[0], o.size[1], o.size[2]);
      }
      if (fresh) {
        m.position.set(o.pos[0], o.pos[1], o.pos[2]);
        m.quaternion.set(o.quat[0], o.quat[1], o.quat[2], o.quat[3]);
      } else {
        // released in the last 2 s and the new pose is lower: it falls (the scene may show it first where it was
        // let go and only then where it lands, so the window matters)
        const recent = m.userData.releasedAt && performance.now() - m.userData.releasedAt < 2000;
        this.animateTo(m, o.pos, o.quat, recent && m.position.z - o.pos[2] > 0.0005);
      }
    }
    for (const [key, m] of this.objects) {
      if (!seen.has(key)) {
        if (m.parent) m.parent.remove(m);
        m.geometry.dispose(); m.material.dispose(); this.objects.delete(key);
      }
    }
  }
}
